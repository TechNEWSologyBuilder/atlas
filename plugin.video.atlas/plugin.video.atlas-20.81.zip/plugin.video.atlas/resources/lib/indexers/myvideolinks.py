# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
MYVIDEOLINKS = 'https://ina.myvideolinks.net/'


def Myvideolinks_menu():
    addDir('[B][COLOR white]2024 -[COLOR tomato] Myvideolinks[/COLOR][/B]', MYVIDEOLINKS + 'category/movies/2024/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]All -[COLOR tomato] Myvideolinks[/COLOR][/B]', MYVIDEOLINKS + 'category/movies/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]4K Ταινίες (2160p)-[COLOR tomato] Myvideolinks[/COLOR][/B]', MYVIDEOLINKS + 'category/movies/4k-2160p/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR white]Older -[COLOR tomato] Myvideolinks[/COLOR][/B]', MYVIDEOLINKS + 'category/movies/older-movies/', 102, ART + 'myvideolinks.png', FANART, '')

def myvideolinks(url): #102
    hdrs = {'Referer': MYVIDEOLINKS,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    if 'tv-shows' not in url:
    #    try:
        m = re.compile('<h2 class="entry-title" itemprop="headline" ><a href="(.+?)">(.+?)</a></h2>.+?<img src="(.+?)".+?<b>Plot</b> :(.+?)</p>', re.DOTALL).findall(p)
        for url, name, icon, plot in m:
            name = clear_Title(name)
            plot = clear_Title(plot)
            fanart = icon
            addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 103, icon , fanart, plot)
    else:
        m = re.compile('<h2 class="entry-title" itemprop="headline" ><a href="(.+?)">(.+?)</a></h2>.+?<img src="(.+?)".+?<p>(.+?)</p>\s+</div>', re.DOTALL).findall(p)
        for url, name, icon, plot in m:
            name = clear_Title(name)
            plot = clear_Title(plot)
            fanart = icon
            addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 103, icon , fanart, plot)
    try:
        m = re.compile('<a class="nextpostslink" rel="next" aria-label="Next Page" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 102, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #103
    hdrs = {'Referer': MYVIDEOLINKS,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<li><a href="(.+?)" class="autohyperlink" target="_blank">(.+?)/.+?').findall(p)
        t = re.compile('<h1>(.+?)</h1>').findall(p)
        for url, link in m:
            link = ' - ' + link
            link = link.replace('.com', '').replace('.net', '').replace('.download', '').replace('.site', '').replace('.xyz', '').replace('.online', '')
            for name in t:
                name = name.replace(' &#8211; Myvideolinks','')
                name = clear_Title(name)
                name = name + link
                if not ('WATCH' in name or 'clicknupload' in link or 'dailyuploads' in link or 'down.fast-down' in link or 'filerice' in link or 'turbobit' in link):
                    addDir(name, url, 100, iconimage, FANART, str(description))


def get_links_series(name, url, iconimage, description): #1040
    hdrs = {'Referer': MYVIDEOLINKS,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<li><a href="(.+?)" class="autohyperlink">').findall(p)
        t =  re.compile('<title>(.+?)</title>').findall(p)
        link_list = ['mixdrop', 'userload', 'tubeload']
        for url in m:
            for name in t:
                if any(x in url for x in link_list):
                    name = name.replace(' &#8211; Myvideolinks','')
                    name = clear_Title(name)
                    if 'mixdrop' in url:
                        link = ' | mixdrop'
                        name = name + link
                        addDir(name, url, 100, iconimage, FANART, str(description))
                    elif 'tubeload' in url:
                        link = ' | tubeload'
                        name = name + link
                        addDir(name, url, 100, iconimage, FANART, str(description))
                    elif 'userload' in url:
                        link = ' | userload'
                        name = name + link
                        addDir(name, url, 100, iconimage, FANART, str(description))

def search(url): #101
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = MYVIDEOLINKS + '?s=' + search
        myvideolinks(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
