import xbmc, xbmcgui
TAINIOMANIA = 'https://tainio-mania.online/'


def tainiomania():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)

    call = xbmcgui.Dialog().select('[B][COLOR=coral]                                            Tainio-mania [/COLOR][/B]', 
['[B][COLOR white]                              2023 -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR white]                              2022 -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR white]                              Έτος -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR white]                        Κατηγορίες -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR white]                              2022 -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR white]                              2022 -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR white]                              2022 -[COLOR coral] Tainio-mania[/COLOR][/B]',
 '[B][COLOR=white]                                            Χριστουγεννιάτικες[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=89&amp;url=TAINIOMANIA + 'load/tainies-2023-online/')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/western/)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/anime/)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/animemovies/)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/bollywood/)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/collection/)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/tainiesonline/)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&amp;mode=44&amp;url=https://xrysoi.pro/category/x-mas/)')
