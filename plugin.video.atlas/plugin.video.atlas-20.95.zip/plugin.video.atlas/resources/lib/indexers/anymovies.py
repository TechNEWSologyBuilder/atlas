# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_anymovies = ART + 'anymovies.png'
ANYMOVIES = 'https://www.downloads-anymovies.co'


def Anymovies_menu(): #95
    addDir('[B][COLOR orange]2024[/COLOR][/B]', 'https://www.downloads-anymovies.co/movies/search.php?zoom_query=2024', 94, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR orange]2023[/COLOR][/B]', 'https://www.downloads-anymovies.co/movies/search.php?zoom_query=2023', 94, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR orange]Έτος[/COLOR][/B]', '', 91, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR orange]Κατηγορίες[/COLOR][/B]', '', 92, ART + 'anymovies.png', FANART, '')


def menu_year(): #91
    addDir('[B][COLOR orange]2024[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2024', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2023[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2023', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2022[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2022', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2021[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2021', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2020[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2020', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2019[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2019', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2018[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2018', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2017[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2017', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2016[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2016', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2015[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2015', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2014[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2014', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2013[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2013', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2012[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2012', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2011[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2011', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2010[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2010', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2009[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2009', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2008[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2008', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2007[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2007', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2006[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2006', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2005[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2005', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2004[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2004', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2003[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2003', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2002[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2002', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2001[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2001', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]2000[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=2000', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1999[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1999', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1998[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1998', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1997[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1997', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1996[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1996', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1995[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1995', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1994[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1994', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1993[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1993', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1992[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1992', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1991[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1991', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1990[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1990', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1989[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1989', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1988[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1988', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1987[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1987', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1986[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1986', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1985[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1985', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1984[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1984', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1983[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1983', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1982[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1982', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1981[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1981', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1980[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1980', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1979[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1979', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1978[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1978', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1977[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1977', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1976[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1976', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1975[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1975', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1974[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1974', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1973[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1973', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1972[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1972', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1971[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1971', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1970[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1970', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1969[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1969', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1968[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1968', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1967[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1967', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1966[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1966', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1965[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1965', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1964[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1964', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1963[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1963', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]1962[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=1962', 94, icon_anymovies, FANART, '')


def menu_genre(): #92
    addDir('[B][COLOR orange]Action[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Action', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Adventure[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Adventure', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Sport[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Sport', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Sci-Fi[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Sci-Fi', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Horror[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Horror', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Thriller[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Thriller', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Comedy[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Comedy', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Crime[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Crime', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Western[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Western', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Animation[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Animation', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Documentary[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Documentary', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Romance[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Romance', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]War[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=War', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Drama[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Drama', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Family[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Family', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Fantasy[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Fantasy', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]History[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=History', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Biography[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Biography', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Mystery[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Mystery', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Music[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Music', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Musical[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Musical', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Biography[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Biography', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]Mystery[/COLOR][/B]', ANYMOVIES + '/movies/movies.php?zoom_query=Mystery', 94, icon_anymovies, FANART, '')
    addDir('[B][COLOR orange]18+[/COLOR][/B]', ANYMOVIES + '/movies/search.php?zoom_query=Watch+Erotic+Movies', 94, icon_anymovies, FANART, '')


def anymovies(url): #94
    hdrs = {'Referer': ANYMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="result_image"><a href="(.+?)"><img src="(.+?)".+?/>.+?<a href=.+?>(.+?)</a></div>', re.DOTALL).findall(p)
    for url, icon, name in m:
        name = name.replace(')',')').replace('Watch ','').replace(' Full Movie Online Free','').replace('&#39;s','').replace('&#39;','').replace('&#38;','').replace('Free','').replace('Online .','').replace('Movie Online','').replace('Online','').replace('Full .','').replace('Full','')
        fanart = icon
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 93, icon, fanart, '')
    try:
        m = re.compile('<a href="(.+?)">Next &gt;&gt;</a> </div>.+?</div>').findall(p)[0]
        m = m.replace('amp;','')
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (ANYMOVIES+m), 94, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #93
    hdrs = {'Referer': ANYMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<span class="text"><a href="(.+?)" target="_blank"><b><.+?><.+?>(.+?)<br soft>').findall(p)
    t = re.compile('alt="(.+?)"></td>').findall(p)
    for url, link in m:
        for name in t:
            link = link.replace('Click Here To Watch ', '').replace('Click Here To Download ', '')
            link = ' | ' + link
            addDir((name+link), url, 100, iconimage, FANART, str(description))


def search(url): #90
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://www.downloads-anymovies.co/search.php?zoom_query=' + search
        anymovies(url)
