# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_watchseries = ART + 'watchseries.png'
WATCHSERIES = 'https://watchseriess.io/'


def watchseries(url): #133
    hdrs = {'Referer': WATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="home_video_title">.+?<a href="(.+?)" class="view_more"></a>\s+<img src="(.+?)" alt="" class="imgHome" title="" alt="(.+?)" />.+?<div class="video_likes icon-tag"> (.+?)</div>', re.DOTALL).findall(p)
    for url, icon, name, info in m:
        if 'Episode' in info:
            info = info.replace('Episode', 'Επεισόδιο')
            info = '[COLOR lime] - %s[/COLOR]'% info
        else:
            info = ''
        if not 'https:' in icon:
            fanart = 'https:' + icon
            addDir(('[B][COLOR=white]%s[/COLOR][/B]' % name + info), (WATCHSERIES + url), 132, ('https:' + icon), fanart, '')
        else:
            fanart = icon
            addDir(('[B][COLOR=white]%s[/COLOR][/B]' % name + info), (WATCHSERIES + url), 132, icon, fanart, '')
    try:
        m = re.compile('</a></li><li class=.+?><a href=.+? data-page=(.+?)>Next Page »</a></li></ul>  ').findall(p)[0]
        m = m.replace("'", "")
        if not 'series' in url:
            addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', ('https://watchseriess.net/anime?page='+m), 133, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
        else:
            addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', ('https://watchseriess.net/movies?page='+m), 133, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #132
    hdrs = {'Referer': WATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="#" rel=.+? data-video="(.+?)"><div class=.+?>(.+?)</div>').findall(p)
    t = re.compile('<div class="page_title">(.+?)</div>').findall(p)
    for url, link in m:
        for name in t:
            if not '20' in name:
                name = name + ' (2022)'
                link = ' | ' + link
                addDir((name+link), url, 100, iconimage, FANART, str(description))
            else:
                link = ' | ' + link
                addDir((name+link), url, 100, iconimage, FANART, str(description))

