import os, re, sys, six, json, time, requests, xbmcvfs
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, webbrowser

try:
    from sqlite3 import dbapi2 as database
except BaseException:
    from pysqlite2 import dbapi2 as database
from urllib.parse import unquote_plus
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import control
from resources.lib.modules import init
from resources.lib.modules import views
from resources.lib.modules import domparser as dom
from resources.lib.modules.control import addDir
from resources.lib.modules import utils
from resources.lib.modules.params import p
from resources.lib.modules import yt_playlists
from resources.lib.modules.parser import Parser
from six.moves.urllib_parse import urlparse, urlencode, urljoin, unquote, unquote_plus, quote, quote_plus, parse_qsl

ADDON = xbmcaddon.Addon()
ADDON_DATA = ADDON.getAddonInfo('profile')
ADDON_PATH = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART = ADDON.getAddonInfo('fanart')
ICON = ADDON.getAddonInfo('icon')
ID = ADDON.getAddonInfo('id')
NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')
Lang = control.lang#ADDON.getLocalizedString
Dialog = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_fmovies = ART + 'fmovies.png'
categ_no = "[COLOR orange]Σε περίπτωση μη αναπαραγωγής του βίντεο:[/COLOR]"
Dialog_no = "[COLOR white]Πατώντας Εντάξει θα ανοίξει ο browser της συσκευής μας το site [COLOR coral]Coverapi[COLOR white].[CR]Τσεκάρουμε το τετραγωνάκι ( I'm not a robot ) και έπειτα πατάμε Send.[CR]Επιστρέφουμε πίσω και αναπαράγουμε ξανά το βίντεο.[/COLOR]"

BASEURL = 'https://tenies-online1.gr/genre/kids/'
GAMATO = 'https://gamatotv.info' #'https://el.gamatotv.info/'
Teniesonline = control.setting('tenies.domain') or 'https://tenies-online1.gr/'
XRYSOI = control.setting('xrysoi.domain') or 'https://xrysoi.pro/'
GAMATOMOVIES = control.setting('gamatomovies.domain') or 'https://gamatomovies1.gr/'
ANYMOVIES = control.setting('anymovies.domain') or 'https://www.downloads-anymovies.co/'
TAINIOMANIA = 'https://tainio-mania.online/'
MYVIDEOLINKS = 'https://myvid.one/'
COOLMOVIEZONE = control.setting('coolmoviezone') or 'https://coolmoviezone.help/'
WATCHSERIES = 'https://watchseriess.io/'
FMOVIES = control.setting('fmovies') or 'https://fmovies.vision/'
DOOMOVIES = 'https://doomovies.net/'
COUCHTUNER = 'https://www.couchtuner.show/'
GOOJARA = 'https://goojara.club/'
GREEKMOVIES = 'https://greek-movies.com/'
GOWATCHSERIES = 'https://www5.gowatchseries.tv/'
MVTVLOOK = 'https://mvtvlook.club/'
AN1ME = 'https://an1me.to/'
Subs4Free = 'https://www.subs4free.club'


addon_id = xbmcaddon.Addon().getAddonInfo('id')
translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo = addon.getAddonInfo
addon_version = addoninfo('version')
addon_name = addoninfo('name')
addon_icon = addoninfo("icon")
addon_fanart = addoninfo("fanart")
addon_profile = translatePath(addoninfo('profile'))
addon_path = translatePath(addoninfo('path'))
setting = addon.getSetting
setting_set = addon.setSetting
local_string = addon.getLocalizedString
home = translatePath('special://home/')
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
addons_path = os.path.join(home, 'addons/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
packages = os.path.join(addons_path, 'packages/')
resources = os.path.join(addon_path, 'resources/')
xml_folder = os.path.join(resources, 'xml/')
yt_xml = xml_folder + 'main.json'
yt1_xml = xml_folder + 'kids.json'
yt2_xml = xml_folder + 'doc.json'
yt3_xml = xml_folder + 'greek.json'
yt4_xml = xml_folder + 'omades.json'
yt5_xml = xml_folder + 'fishing.json'
yt6_xml = xml_folder + 'asian.json'

user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
headers = {'User-Agent': user_agent}
handle = int(sys.argv[1])
addDir2 = utils.addDir

xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)


def Main_addDir():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Ταινίες[/COLOR][/B]', '', 10, 'http://i.imgur.com/cTv0fXe.png', FANART, '')
    addDir('[B][COLOR white]Ξένες Σειρές[/COLOR][/B]', '', 11, 'http://i.imgur.com/ypLPk5x.png', FANART, '')
    addDir('[B][COLOR white]Παλιές Σειρές[/COLOR][/B]', '', 12, 'http://i.imgur.com/ypLPk5x.png', FANART, '')
    addDir('[B][COLOR white]Παιδική Χαρά[/COLOR][/B]', '', 80, 'http://i.imgur.com/T8NlaOf.png', FANART, '')
    addDir('[B][COLOR white]Ελληνικές Ταινίες[/COLOR][/B]', '', 13, 'http://i.imgur.com/QGC87GD.png', FANART, '')
    addDir('[B][COLOR white]Ασιατικές Ταινίες[/COLOR][/B]', '', 66, 'http://i.imgur.com/cTv0fXe.png', FANART, '')
    addDir('[B][COLOR white]Ασπρόμαυρες Ταινίες[/COLOR][/B]', '', 104, 'http://i.imgur.com/cTv0fXe.png', FANART, '')
    addDir('[B][COLOR white]Αθλητικά - DaddyLive[/COLOR][/B]', '', 8, 'http://i.imgur.com/edOpGQt.png', FANART, '')
    addDir('[B][COLOR white]Ντοκιμαντέρ[/COLOR][/B]', '', 81, 'http://i.imgur.com/jTaJF0B.png', FANART, '')
    addDir('[B][COLOR white]Θέατρο[/COLOR][/B]', '', 196, ART + 'greek-movies.png', FANART, '')
    addDir('[B][COLOR white]Ψάρεμα[/COLOR][/B]', '', 65, 'https://i.imgur.com/9SvI277.png', FANART, '')
    downloads = True if control.setting('downloads') == 'true' and (
            len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or
            len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
    if downloads:
        addDir('[B][COLOR white]Downloads[/COLOR][/B]', '', 40, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32020) + '[/COLOR][/B]', '', 17, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32021) + '[/COLOR][/B]', '', 9, 'https://i.imgur.com/2cPUPkf.png', FANART, '')
    addDir('[B][COLOR white]' + Lang(32019) + ': [COLOR lime]%s[/COLOR][/B]' % vers, '', 'bug', ICON, FANART, '')
    addDir('[B][COLOR lime]Δωρεά [COLOR white]&[COLOR lime] Υποστήριξη[/COLOR][/B]', '', 83, ICON, FANART, '')


def Movies_maim(): #10
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR steelblue]Subs[COLOR red]4[COLOR orange]F[/COLOR][/B]', Subs4Free, 262, ART + 's4f.png', FANART, '')
    addDir('[B][COLOR gray]Gamato[/COLOR][/B]', '', 16, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR coral]Tainio-mania[/COLOR][/B]', '', 84, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR gold]Xrysoi[/COLOR][/B]', '', 48, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR deeppink]GamatoMovies[/COLOR][/B]', '', 131, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR steelblue]Greek-Movies[/COLOR][/B]', '', 180, ART + 'greekmovies.png', FANART, '')
    addDir('[B][COLOR slateblue]An1me[/COLOR][/B]', '', 255, ART + 'an1me.png', FANART, '')
#    addDir('[B][COLOR yellow]Doo[COLOR gray]movies[/COLOR][/B]', '', 155, ART + 'doomovies.png', FANART, '')
#    addDir('[B][COLOR orange]Anymovies[/COLOR][/B]', '', 95, ART + 'anymovies.png', FANART, '')
    addDir('[B][COLOR tomato]Myvideolinks[/COLOR][/B]', '', 96, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR orange]Goojara[/COLOR][/B]', '', 170, ART + 'goojara.png', FANART, '')
#    addDir('[B][COLOR orangered]Gowatch[COLOR white]series[/COLOR][/B]', GOWATCHSERIES + 'movies', 212, ART + 'thewatchseries.png', FANART, '')

#    addDir('[B][COLOR white]Mvtv[COLOR orange]Look[/COLOR][/B]', '', 230, ART + 'mvtvlook.png', FANART, '')
#    addDir('[B][COLOR blue]Fmovies[/COLOR][/B]', '', 140, ART + 'fmovies.png', FANART, '')
#    addDir('[B][COLOR gray] Watch[COLOR red]series[/COLOR][/B]', WATCHSERIES + 'movies', 133, ART + 'watchseries.png', FANART, '')
#    addDir('[B][COLOR green]Tainiesonline[/COLOR][/B]', '', 31, ART + 'tainiesonline.png', FANART, '')
#    addDir('[B][COLOR white]2022 -[COLOR cyan] Coolmoviezone[/COLOR][/B]', 'https://coolmoviezone.news/tag/browse-year-2022', 114, ART + 'coolmoviezone.png', FANART, '')
#    addDir('[B][COLOR white]Έτος -[COLOR cyan] Coolmoviezone[/COLOR][/B]', '', 107, ART + 'coolmoviezone.png', FANART, '')
#    addDir('[B][COLOR white]Κατηγορίες -[COLOR cyan] Coolmoviezone[/COLOR][/B]', '', 108, ART + 'coolmoviezone.png', FANART, '')
#    addDir('[B][COLOR white]Έτος -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/release/2020/', 97, ART + 'oipeirates.png', FANART, '')
#    addDir('[B][COLOR white]Κατηγορίες -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/release/2020/', 98, ART + 'oipeirates.png', FANART, '')


def Series_maim(): #11
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    p = client.request(url = GAMATO)
    m = re.compile('<a href="(.+?)">Σειρές</a></li>').findall(p)
    for url in m:
        addDir('[B][COLOR gray]Gamato[/COLOR][/B]', url, 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%be%ce%ad%ce%bd%ce%b5%cf%82-%cf%83%ce%b5%ce%b9%cf%81%ce%ad%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
#    addDir('[B][COLOR coral]Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR deeppink]GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/tv-series/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR blue]CouchTuner[/COLOR][/B]', 'https://www.couchtuner.show/', 164, ART + 'couchtuner.png', FANART, '')
#    addDir('[B][COLOR orangered]Gowatch[COLOR white]series[/COLOR][/B]', GOWATCHSERIES + 'movies', 211, ART + 'thewatchseries.png', FANART, '')
#    addDir('[B][COLOR coral]Myvideolinks[/COLOR][/B]', MYVIDEOLINKS + 'category/tv-shows/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR coral]Myvideolinks - [COLOR white](Complete Seasons)[/COLOR][/B]', MYVIDEOLINKS + 'category/tv-shows/complete-season/', 102, ART + 'myvideolinks.png', FANART, '')
    addDir('[B][COLOR slateblue]An1me[/COLOR][/B]', '', 255, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR white]Anime -[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/anime/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR orange]Goojara[/COLOR][/B]', '', 170, ART + 'goojara.png', FANART, '')

#    addDir('[B][COLOR white]Mvtv[COLOR orange]Look[/COLOR][/B]', '', 229, ART + 'mvtvlook.png', FANART, '')
#    addDir('[B][COLOR white]Anime -[COLOR gray] Watch[COLOR red]series[/COLOR][/B]', WATCHSERIES + 'anime', 133, ART + 'watchseries.png', FANART, '')
#    addDir('[B][COLOR white]Ξένες Σειρές -[COLOR cyan] Coolmoviezone[/COLOR][/B]', 'https://coolmoviezone.watch/category/tv-series/', 114, ART + 'coolmoviezone.png', FANART, '')
#    addDir('[B][COLOR white]Anime Σειρές -[COLOR gray] Gamato[/COLOR][/B]', GAMATO + 'genre/anime/', 21, ART + 'gamato.png', FANART, '')
#    addDir('[B][COLOR white]Anime Σειρές -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club//genre/anime/', 96, ART + 'oipeirates.png', FANART, '')


def Old_maim(): #12
    addDir('[B][COLOR white]Ο Ιησούς από τη Ναζαρέτ - Jesus of Nazareth (1977) [/COLOR][/B]', 'https://tenies-online.best/load/2-1-0-3942', 88, 'https://tenies-online.best/uploads/mini/postertenies/e4/f350add7754496202a177cdfc41282.jpg', 'https://tenies-online.best/uploads/mini/postertenies/e4/f350add7754496202a177cdfc41282.jpg', '')
    addDir('[B][COLOR white]Shogun (1980) [/COLOR][/B]', 'https://tainio-mania.online/load/seir/shogun-1980/21-1-0-23655', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/4f/565b8cb1526a365657c9f2c8c8ad8d.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/4f/565b8cb1526a365657c9f2c8c8ad8d.jpg', '')
    addDir('[B][COLOR white]Miami Vice (1984)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/miami_vice_1984_1990/21-1-0-10289', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/02/adc211bf16ac553a5fdeb235597ce0.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/02/adc211bf16ac553a5fdeb235597ce0.jpg', '')
    addDir('[B][COLOR white]Police Squad (1982)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/police_squad_1982/21-1-0-10406', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/dd/77b2d9600000a1bb0a107aaf99e18e.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/dd/77b2d9600000a1bb0a107aaf99e18e.jpg', '')
    addDir('[B][COLOR white]Battlestar Galactica (1978)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/battlestar-galactica-1978/21-1-0-20913', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/8f/862aa2cb4c6c37bb268c99f29dbfe2.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/8f/862aa2cb4c6c37bb268c99f29dbfe2.jpg', '')
    addDir('[B][COLOR white]Τα πουλιά πεθαίνουν τραγουδώντας - The Thorn Birds (1983)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/ta_poyli_petha_noyn_tragoyd_nta_the_thorn_birds_1983_tv_mini_series/21-1-0-19759', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/34/a512c6fc61e519d280287756f9221f.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/34/a512c6fc61e519d280287756f9221f.jpg', '')
    addDir('[B][COLOR white]Voyagers - Ταξιδιώτες Μέσα Στο Χρόνο (1982–1983)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/voyagers_taxidi_te_m_sa_sto_chr_no_1982_1983_tv_series/21-1-0-9915', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/b4/02480cbf9c6fcf8442c1af185bc223.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/b4/02480cbf9c6fcf8442c1af185bc223.jpg', '')
    addDir('[B][COLOR white]Επιστροφή στην Εδέμ - Return to Eden (1983)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/return-to-eden-1983/21-1-0-10569', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/05/51b98fcf0febf95f8b423f725d8f54.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/05/51b98fcf0febf95f8b423f725d8f54.jpg', '')
    addDir('[B][COLOR white]Επιστροφή στην Εδέμ - Return to Eden (1986)[/COLOR][/B]', 'https://tainio-mania.online/load/seir/-return-to-eden-1986/21-1-0-30318', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/31/d6a235cf43dd1271439926b8bc6a27.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/31/d6a235cf43dd1271439926b8bc6a27.jpg', '')
    addDir('[B][COLOR white]Κάντυ Κάντυ / Candy Candy (1976-1979)[/COLOR][/B]', 'https://tainio-mania.online/load/kino_mena_sch_dia/k_nty_k_nty_candy_candy_1976_1979/5-1-0-10057', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/1b/87e4c135ca4f649c46bd5fefe1abea.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/1b/87e4c135ca4f649c46bd5fefe1abea.jpg', '')
    addDir('[B][COLOR white]Kabamaru Igano (1983-1984)[/COLOR][/B]', 'https://tainio-mania.online/load/kino_mena_sch_dia/kabamaru_igano_1983_1984/5-1-0-10409', 88, 'https://tainio-mania.online/uploads/mini/posterentrypage/6f/fd3ec5c57b370947583e2fe84fd71f.jpg', 'https://tainio-mania.online/uploads/mini/posterentrypage/6f/fd3ec5c57b370947583e2fe84fd71f.jpg', '')
    views.selectView('movies', 'movie-view')


def kids_menu():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR white]Greek-Movies[/COLOR][/B]', '', 203, ART + 'greekmovies.png', FANART, '')
    p = client.request(url = GAMATO)
    m = re.compile('<a href="(.+?)">Παιδικά</a></li>').findall(p)
    for url in m:
        addDir('[B][COLOR white]Μεταγλωτισμένα[COLOR gray] Gamato[/COLOR][/B]', url, 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR gray] Gamato[/COLOR][/B]', GAMATO + 'animation/', 21, ART + 'gamato.png', FANART, '')
#    addDir('[B][COLOR white]Μεταγλωτισμένα[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
#    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR white]Μεταγλωτισμένα[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%ba%ce%b9%ce%bd-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%ba%ce%b9%ce%bd-%cf%83%cf%87%ce%ad%ce%b4%ce%b9%ce%b1-subs/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/animation/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Ταινίες-Σειρές [COLOR slateblue]An1me[/COLOR][/B]', '', 255, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR white]Ταινίες Anime [COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/animemovies/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Σειρές Anime [COLOR gold]Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/category/anime/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR white]Παιδικά You[COLOR red]Tube[/COLOR][/B]', '', 61, ART + 'youtube.png', FANART, '')

#    addDir('[B][COLOR white]Ταινίες Anime [COLOR gray] Gamato[/COLOR][/B]', GAMATO + 'category/animation/', 21, ART + 'gamato.png', FANART, '')
#    addDir('[B][COLOR white]Anime [COLOR gray] Gamato[/COLOR][/B]', GAMATO + 'category/anime/', 21, ART + 'gamato.png', FANART, '')
#    addDir('[B][COLOR white]Σειρές Anime [COLOR gray] Watch[COLOR red]series[/COLOR][/B]', WATCHSERIES + 'anime', 133, ART + 'watchseries.png', FANART, '')
#    addDir('[B][COLOR white]Κινούμενα Σχέδια[COLOR white] Mvtv[COLOR orange]Look[/COLOR][/B]', MVTVLOOK + 'category/kids/', 235, ART + 'mvtvlook.png', FANART, '')
#    addDir('[B][COLOR white]Παιδικά μεταγλωτισμένα[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/kids/', 34, ART + 'tainiesonline.png', FANART, '')
#    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/κινούμενα-σχέδια/', 34, ART + 'tainiesonline.png', FANART, '')
#    addDir('[B][COLOR white]Κινούμενα σχέδια[COLOR blue] Fmovies[/COLOR][/B]', FMOVIES + '/animation/', 139, icon_fmovies, FANART, '')
#    addDir('[B][COLOR white]Παιδικά μεταγλωτισμένα[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/kin-sxedia/', 96, ART + 'oipeirates.png', FANART, '')
#    addDir('[B][COLOR white]Παιδικά με υπότιτλους[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/kin-sxedia-subs/', 96, ART + 'oipeirates.png', FANART, '')


def Greek_maim():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR steelblue]Greek-Movies[/COLOR][/B]', '', 180, ART + 'greekmovies.png', FANART, '')
    addDir('[B][COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%b5%ce%bb%ce%bb-%cf%84%ce%b1%ce%b9%ce%bd%ce%af%ce%b5%cf%82/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/elliniki-tainia/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]Ελλ. Ταινίες You[COLOR red]Tube[/COLOR][/B]', '', 63, ART + 'youtube.png', FANART, '')

#    addDir('[B][COLOR white]Mvtv[COLOR orange]Look[/COLOR][/B]', MVTVLOOK + 'country/greece/', 235, ART + 'mvtvlook.png', FANART, '')
#    addDir('[B][COLOR white]Ελληνικές Ταινίες -[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/ell-tainies/', 96, ART + 'oipeirates.png', FANART, '')
#    addDir('[B][COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/ellinikes/', 34, ART + 'tainiesonline.png', FANART, '')


def documentary_menu():
    addDir('[B][COLOR white]' + Lang(32002) + ' ...[/COLOR][/B]', '', 6, ART + 'search.png', FANART, '')
    addDir('[B][COLOR red] Ntokimanter[/COLOR][/B]', '', 117, ART + 'ntokimanter.png', FANART, '')
    addDir('[B][COLOR coral] Tainio-mania[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR gold] Xrysoi[/COLOR][/B]', 'https://xrysoi.pro/category/%ce%bd%cf%84%ce%bf%ce%ba%ce%b9%ce%bc%ce%b1%ce%bd%cf%84%ce%ad%cf%81/', 44, ART + 'xrysoi.png', FANART, '')
    addDir('[B][COLOR gray] Gamato[/COLOR][/B]', GAMATO + 'documentary/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR deeppink] GamatoMovies[/COLOR][/B]', GAMATOMOVIES + 'tainies/documentary/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR white]You[COLOR red]Tube[/COLOR][/B]', '', 62, ART + 'youtube.png', FANART, '')
#    addDir('[B][COLOR yellow] Doo[COLOR gray]movies[/COLOR][/B]', DOOMOVIES + '/genre/documentary/', 154, ART + 'doomovies.png', FANART, '')
#    addDir('[B][COLOR orange] Anymovies[/COLOR][/B]', 'https://www.downloads-anymovies.co/movies/search.php?zoom_query=Documentary', 94, ART + 'anymovies.png', FANART, '')

    addDir('[B][COLOR orange]Goojara[/COLOR][/B]', GOOJARA + 'genre/documentary-movies/', 172, ART + 'goojara.png', FANART, '')
#    addDir('[B][COLOR white] Mvtv[COLOR orange]Look[/COLOR][/B]', MVTVLOOK + 'category/documentary/', 235, ART + 'mvtvlook.png', FANART, '')
#    addDir('[B][COLOR blue] Fmovies[/COLOR][/B]', FMOVIES + 'documentary/', 139, icon_fmovies, FANART, '')
#    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR green] Tainiesonline[/COLOR][/B]', 'https://tenies-online1.gr/genre/ntokimanter/', 34, ART + 'tainiesonline.png', FANART, '')
#    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR cyan] Coolmoviezone[/COLOR][/B]', COOLMOVIEZONE + 'category/documentary/', 114, ART + 'coolmoviezone.png', FANART, '')
#    addDir('[B][COLOR white]Ντοκιμαντέρ[COLOR red] OiPeirates[/COLOR][/B]', 'https://oipeirates.club/genre/documentary/', 96, ART + 'oipeirates.png', FANART, '')


def Sports_nemu(): #8
    addDir('[B][COLOR white]DaddyLive - [COLOR lime]Ζωντανά...[/COLOR][/B]', '', 240, ART + 'daddylive.png', FANART, '')
    addDir('[B][COLOR white]Greek-[COLOR deepskyblue]Movies[/COLOR][/B]', '', 201, ART + 'greekmovies.png', FANART, '')
    addDir('[B][COLOR white]Ομάδες [COLOR red]YouTube[/COLOR][/B]', '', 64, ART + 'youtube.png', FANART, '')


def Gamato_menu():
    p = client.request(url = GAMATO)
    m = re.compile('<a href="(.+?)">Κατηγορίες</a></li>').findall(p)
    for url2 in m:
        p = client.request(url2)

    m24 = re.compile('<a href="(.+?)">2024</a></li>').findall(p)
    m23 = re.compile('<a href="(.+?)">.+?</a>').findall(p)
    m22 = re.compile('<a href="(.+?)">Ταινίες</a></li>').findall(p)

#    addDir('[B][COLOR gray]2025[/COLOR][/B]', (GAMATO + '/?s=2025'), 21, ART + 'gamato.png', FANART, '')

    for url in m22:
        addDir('[B][COLOR gray]Τελευταίες Προσθήκες[/COLOR][/B]', url, 21, ART + 'gamato.png', FANART, '')
    for r in m24:
        if '2024' in r:
            addDir('[B][COLOR gray]2024[/COLOR][/B]', r, 21, ART + 'gamato.png', FANART, '')
    for r in m23:
        if '2023' in r:
            addDir('[B][COLOR gray]2023[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')

    addDir('[B][COLOR gray]Έτος[/COLOR][/B]', '', 22, ART + 'gamato.png', FANART, '')
#    addDir('[B][COLOR gray]Συλλογές[/COLOR][/B]', '', 15, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Κατηγορίες[/COLOR][/B]', GAMATO + 'movies/', 23, ART + 'gamato.png', FANART, '')


def Gamato_collections():
    addDir('[B][COLOR gray]Ip Man[/COLOR][/B]', GAMATO + '/tag/ip-man/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Harry Potter[/COLOR][/B]', GAMATO + 't/ag/harry-potter/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Rocky[/COLOR][/B]', GAMATO + '/tag/rocky/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Rambo[/COLOR][/B]', GAMATO + '/tag/rambo/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]The Lord of the Rings[/COLOR][/B]', GAMATO + '/tag/the-lord-of-the-rings/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]The Hobbit[/COLOR][/B]', GAMATO + '/tag/the-hobbit/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Transformers[/COLOR][/B]', GAMATO + '/tag/transformers/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Twilight Saga[/COLOR][/B]', GAMATO + '/tag/twilight-saga/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Underworld[/COLOR][/B]', GAMATO + '/tag/underworld/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Blade[/COLOR][/B]', GAMATO + '/tag/blade/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]X-Men[/COLOR][/B]', GAMATO + '/tag/x-men/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Narnia[/COLOR][/B]', GAMATO + '/tag/narnia/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Jason Bourne[/COLOR][/B]', GAMATO + '/tag/jason-bourne/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Pirates Of The Caribbean[/COLOR][/B]', GAMATO + '/tag/pirates-of-the-caribbean/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Fast and Furious[/COLOR][/B]', GAMATO + '/tag/fast-and-furious/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Thor[/COLOR][/B]', GAMATO + '/tag/thor/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Matrix[/COLOR][/B]', GAMATO + '/tag/matrix/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Iron Man[/COLOR][/B]', GAMATO + '/tag/iron-man/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Avengers[/COLOR][/B]', GAMATO + '/tag/avengers/', 21, ART + 'gamato.png', FANART, '')
    addDir('[B][COLOR gray]Indiana Jones[/COLOR][/B]', GAMATO + '/tag/indiana-jones/', 21, ART + 'gamato.png', FANART, '')


def gamato_genre():
    p = client.request(url = GAMATO)
    m = re.compile('<a href="(.+?)">Κατηγορίες</a></li>').findall(p)
    for url2 in m:
        p = client.request(url2)
    mg = re.compile('<.+? href="(.+?)">(.+?)</a>').findall(p)
    for r, g in mg:
        if 'Western' in g:
            addDir('[B][COLOR gray]Western[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Αστυνομική' in g:
            addDir('[B][COLOR gray]Αστυνομική[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Έγκλημα' in g:
            addDir('[B][COLOR gray]Έγκλημα[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Βιογραφία' in g:
            addDir('[B][COLOR gray]Βιογραφία[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Δράμα' in g:
            addDir('[B][COLOR gray]Δράμα[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Δράση' in g:
            addDir('[B][COLOR gray]Δράση[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Sci-fi' in g:
            addDir('[B][COLOR gray]Sci-fi[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Θρίλερ' in g:
            addDir('[B][COLOR gray]Θρίλερ[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Ιστορική' in g:
            addDir('[B][COLOR gray]Ιστορική[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Κινούμενα Σχέδια' in g:
            addDir('[B][COLOR gray]Κινούμενα Σχέδια[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Κωμωδία' in g:
            addDir('[B][COLOR gray]Κωμωδία[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Μεταγλωτισμένα' in g:
            addDir('[B][COLOR gray]Μεταγλωτισμένα[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Μουσική' in g:
            addDir('[B][COLOR gray]Μουσική[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Μυστηρίου' in g:
            addDir('[B][COLOR gray]Μυστηρίου[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Ντοκυμαντέρ' in g:
            addDir('[B][COLOR gray]Ντοκυμαντέρ[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Οικογενειακή' in g:
            addDir('[B][COLOR gray]Οικογενειακή[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Περιπέτεια' in g:
            addDir('[B][COLOR gray]Περιπέτεια[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Πολεμική' in g:
            addDir('[B][COLOR gray]Πολεμική[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Ρομαντική' in g:
            addDir('[B][COLOR gray]Ρομαντική[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Τρόμου' in g:
            addDir('[B][COLOR gray]Τρόμου[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Φαντασίας' in g:
            addDir('[B][COLOR gray]Φαντασίας[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Film-Noir' in g:
            addDir('[B][COLOR gray]Film-Noir[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Netflix' in g:
            addDir('[B][COLOR gray]Netflix[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Χριστουγεννιάτικες' in g:
            addDir('[B][COLOR gray]Χριστουγεννιάτικες[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')
        elif 'Top 250' in g:
            addDir('[B][COLOR gray]Top 250[/COLOR][/B]', (GAMATO + r), 21, ART + 'gamato.png', FANART, '')

###################YOUTUBE###################

def MainYoutube(_xml):
    xml = Parser(_xml)
    items = xml.get_list()
    video_ids = []
    for item in json.loads(items)['items']:
        link = item.get('link')
        if 'video/' in link or 'youtu.be/' in link:
            video_ids.append(link.split('/')[-1])
        elif link.endswith('.json'):
            if link.startswith('http'):
                addDir2(item.get('title','Unknown'), item.get('link',''), 56, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
            else:
                addDir2(item.get('title','Unknown'),xml_folder+item.get('link',''), 56, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
        else:
            addDir2(item.get('title','Unknown'),item.get('link',''), 59, item.get('icon', addon_icon), item.get('fanart', addon_fanart), item.get('summary','Playlists from Youtube'))
    video_list = yt_playlists.get_videos(video_ids)
    try:
        for title, video_id, icon, description, duration, date in video_list:
            yt_playlists.addDir2(title, 'plugin://plugin.video.youtube/play/?video_id=%s'%video_id,57,icon, icon, description, duration=duration, date='Date Published: '+str(date)+'\n', isFolder=False)
    except:
        pass

def yt_playlist(link): #59
    if link.startswith('http'):
        if 'list=' in link:
            link = link.split('list=')[-1]
    elif link.startswith('plugin'):
        link = link.split('playlist/')[-1].replace('/','')
    yt_playlists.get_playlist_items(link)

def yt_channel(_id): #58
    yt_playlists.ch_playlists(_id)

def play_video(title, link, iconimage): #57
    video = unquote_plus(link)
    liz = xbmcgui.ListItem(title)
    liz.setInfo('video', {'Title': title})
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    xbmc.Player().play(video,liz)

##############################################


def gamato_years(): # Thanks to bugatsinho for the brevity #
    years = []
    for i in range(1919, 2024):
        i += 1
        title = '[B][COLOR gray]{}[/COLOR][/B]'.format(str(i))
        link = GAMATO + '/tag/{}'.format(str(i))
        years.append((title, link))
    for title, link in sorted(years, reverse=True):
    #    if '2022' in link:
    #        link = GAMATO + 'tag/22/'
    #    elif '2023' in link:
    #        link = GAMATO + 'tag/23/'
    #    elif '2024' in link:
    #        link = GAMATO + 'tag/2024/'
        addDir(title, link, 21, ART + 'gamato.png', FANART, '')


def gamato_search(url): #19
#    hdrs = {'Referer': GAMATO,
#            'User-Agent': client.agent()}
#    p = requests.get(url, headers=hdrs).text
    p = client.request(url)
    m = re.compile('.+?<img src="(.+?)" alt="(.+?)" class="thumbnail" /></a>.+?<h1 class="post-title entry-title"><a href="(.+?)".+?\s+<div class="entry-summary">\s+<p>(.+?)</p>', re.DOTALL).findall(p)
    for icon, name, url, desc in m:
        desc = clear_Title(desc)
        desc = desc.replace('LINk1', '').replace('LINk2', '').replace('LINK1', '').replace('LINK2', '').replace('LInk1', '').replace('Link1', '')
        desc = desc.replace(' Trailer', '').replace(':', '').replace('ΔΕΙΤΕ ΤΗΝ ΣΕΙΡΑ ΕΔΩ', '').replace('Gamato  Ταινία', '')
        name = name.replace('- )', ')').replace('-)', ')')
        name = clear_Title(name)
        fanart = icon
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 20, icon , fanart, desc)
    try:
        m = re.compile('<a class="next page-numbers" href="(.+?)">').findall(p)[0]
        m = clear_Title(m)
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (GAMATO+m), 19, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def gamato(url): #21
#    hdrs = {'Referer': GAMATO,
#            'User-Agent': client.agent()}
#    p = requests.get(url, headers=hdrs).text
    p = client.request(url)
    m = re.compile('.+?<img src="(.+?)" alt="(.+?)" class="thumbnail" /></a> \s+<h1 class="post-title entry-title"> <a href="(.+?)".+?\s+<div class="entry-summary">\s+<p>(.+?)</p>', re.DOTALL).findall(p)
    for icon, name, url, desc in m:
        desc = clear_Title(desc)
        desc = desc.replace('LINk1', '').replace('LINk2', '').replace('LINK1', '').replace('LINK2', '').replace('LInk1', '').replace('Link1', '').replace('LΙnΚ1', '')
        desc = desc.replace(' Trailer', '').replace(':', '').replace('ΔΕΙΤΕ ΤΗΝ ΣΕΙΡΑ ΕΔΩ', '').replace('Gamato  Ταινία', '')
        name = name.replace('- )', ')').replace('-)', ')')
        name = clear_Title(name)
        fanart = icon
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 20, icon , fanart, desc)
    try:
        m = re.compile('<a class="next page-numbers" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 21, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def gamato_links(name, url, iconimage, description): #20
#    hdrs = {'Referer': GAMATO,
#            'User-Agent': client.agent()}
#    p = requests.get(url, headers=hdrs).text
    p = client.request(url)
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        try:
            m = re.compile('<a href="(.+?)">(.+?)</a>').findall(p)
            for url, link in m:
                if 'gmtcloud.best' in url:
                    link = link.replace('target="_blank" rel="noopener">', '').replace('rel="noopener" target="_blank">', '').replace('<strong>', 'Σεζόν 2 Επ ')
                    link = link.replace('>>', '').replace('Μετάβαση στο', '').replace('LINk', 'Πηγή ').replace('LInk', 'Πηγή ').replace('LINK', 'Πηγή ').replace('Link', 'Πηγή ').replace('LinK', 'Πηγή ').replace('LiNK', 'Πηγή ')
                    link = ' |[COLOR lime] %s[/COLOR]' % link
                    name = clear_Title(name)
                    addDir((name+link), url, 100, iconimage, FANART, str(description))
        except BaseException:
            pass


def search_menu(): # 6
    addDir(' Νέα αναζήτηση...', 'new', 4, ART + 'search.png', FANART, '')

    dbcon = database.connect(control.searchFile)
    dbcur = dbcon.cursor()

    try:
        dbcur.execute("""CREATE TABLE IF NOT EXISTS Search (url text, search text)""")
    except BaseException:
        pass

    dbcur.execute("SELECT * FROM Search ORDER BY search")

    lst = []

    delete_option = False
    for (url, search) in dbcur.fetchall():
        search = six.ensure_str(search, errors='replace')
        if 'tainio-mania' in url:
            _url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction={}'.format(quote_plus(search))
            domain = '[COLOR coral]TAINIO-MANIA[/COLOR]'

        elif 'subs4free' in url:
            _url = Subs4Free + '/search_report.php?search={}'.format(search)
            domain = '[COLOR steelblue]SUBS[COLOR red]4[COLOR orange]F[/COLOR]'

        elif 'xrysoi' in url:
            _url = XRYSOI + "?s={}".format(quote_plus(search))
            domain = '[COLOR gold]XRYSOI[/COLOR]'

        elif 'gamatomovies' in url:
            _url = GAMATOMOVIES + "?s={}".format(quote_plus(search))
            domain = '[COLOR deeppink]GAMATOMOVIES[/COLOR]'

        elif 'gamato' in url:
            _url = GAMATO + "?s={}".format(quote_plus(search))
            domain = '[COLOR grey]GAMATO[/COLOR]'

    #    elif 'gowatchseries' in url:
    #        _url = 'https://www5.gowatchseries.tv/search.html?keyword={}'.format(quote_plus(search))
    #        domain = '[COLOR orangered]GOWATCHSERIES[/COLOR]'

    #    elif 'coolmoviezone' in url:
    #        _url = COOLMOVIEZONE + "?s={}".format(quote_plus(search))
    #        domain = '[COLOR cyan]COOLMOVIEZONE[/COLOR]'

    #    elif 'doomovies' in url:
    #        _url = "https://doomovies.net/?s={}".format(quote_plus(search))
    #        domain = '[COLOR yellow]DOO[COLOR grey]MOVIES[/COLOR]'

        elif 'goojara' in url:
            _url = GOOJARA + "?s={}".format(quote_plus(search))
            domain = '[COLOR orange]GOOJARA[/COLOR]'

        elif 'myvid' in url:
            _url = MYVIDEOLINKS + "?s={}".format(quote_plus(search))
            domain = '[COLOR tomato]MYVIDEOLINKS[/COLOR]'

    #    elif 'anymovies' in url:
    #        _url = ANYMOVIES + "search.php?zoom_query={}".format(quote_plus(search))
    #        domain = '[COLOR orange]ANYMOVIES[/COLOR]'

        else:
            _url = Teniesonline + "?s={}".format(quote_plus(search))
            domain = '[COLOR blue]-[/COLOR]'
        title = '[B]%s[/B] - [COLOR gold][B]%s[/COLOR][/B]' % (search, domain)
        delete_option = True
        addDir(title, _url, 4, ART + 'search.png', FANART, '')
        lst += [(search)]
    dbcur.close()

    if delete_option:
        addDir(Lang(32039), '', 29, ICON, FANART, '')
  #  views.selectView('movies', 'movie-view')


def Search(url):  # 4
    if url == 'new':
        keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
        keyb.doModal()
        if keyb.isConfirmed():
            search = quote_plus(keyb.getText())
            if six.PY2:
                term = unquote_plus(search).decode('utf-8')
            else:
                term = unquote_plus(search)
            dbcon = database.connect(control.searchFile)
            dbcur = dbcon.cursor()
            dp = xbmcgui.Dialog()

            select = dp.select('Επιλογή Ιστότοπου:',
            #                  ['[COLOR white][B]Mvtv[COLOR orange]Look[/COLOR][/B]',
                              ['[B][COLOR steelblue]Subs[COLOR red]4[COLOR orange]F[/COLOR][/B]',
                               '[COLOR coral][B]Tainio-mania[/COLOR][/B]',
                               '[COLOR grey][B]Gamato[/COLOR][/B]',
                               '[COLOR gold][B]Xrysoi [/COLOR][/B]',
                               '[COLOR deeppink][B]GamatoMovies[/COLOR][/B]',
            #                   '[COLOR yellow][B]Doo[COLOR grey][B]movies[/COLOR][/B]',
                               '[COLOR orange][B]Goojara[/COLOR][/B]',
            #                   '[COLOR orangered][B]Gowatchseries[/COLOR][/B]',
                               '[COLOR tomato][B]Myvideolinks[/COLOR][/B]'])
            #                   '[COLOR orange][B]Anymovies[/COLOR][/B]'])
            #                   '[COLOR blue][B]Tenies-Online[/COLOR][/B]'])

        #    if select == 0:
        #        from resources.lib.indexers import mvtvlook
        #        url = MVTVLOOK + "?s={}".format(search)
        #        dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
        #        dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
        #        dbcon.commit()
        #        dbcur.close()
        #        mvtvlook.mvtvlook(url)

            if select == 0:
                from resources.lib.indexers import coverapi
                url = Subs4Free + '/search_report.php?search={}'.format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                coverapi.coverapi_search(url)

            elif select == 1:
                from resources.lib.indexers import tainiomania
                url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction=search'.format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                tainiomania.tainiomania(url)

            elif select == 2:
                url = GAMATO + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                gamato_search(url)

            elif select == 3:
                from resources.lib.indexers import xrysoi
                url = XRYSOI + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                xrysoi.xrysoimovies(url)

            elif select == 4:
                from resources.lib.indexers import gamatomovies
                url = GAMATOMOVIES + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                gamatomovies.gamatomovies(url)

        #    elif select == 5:
        #        from resources.lib.indexers import doomovies
        #        url = DOOMOVIES + '?s={}'.format(search)
        #        dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
        #        dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
        #        dbcon.commit()
        #        dbcur.close()
        #        doomovies.doomovies_s(url)

            elif select == 5:
                from resources.lib.indexers import goojara
                url = GOOJARA + "?s={}".format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                goojara.goojara(url)

        #    elif select == 6:
        #        from resources.lib.indexers import gowatchseries
        #        url = 'https://www5.gowatchseries.tv/search.html?keyword={}'.format(search)
        #        dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
        #        dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
        #        dbcon.commit()
        #        dbcur.close()
        #        gowatchseries.gowatchseries_s(url)

            elif select == 6:
                from resources.lib.indexers import myvideolinks
                url = MYVIDEOLINKS + '?s={}'.format(search)
                dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
                dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
                dbcon.commit()
                dbcur.close()
                myvideolinks.myvideolinks(url)

        #    elif select == 9:
        #        from resources.lib.indexers import anymovies
        #        url = ANYMOVIES + "search.php?zoom_query={}".format(search)
        #        dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
        #        dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
        #        dbcon.commit()
        #        dbcur.close()
        #        anymovies.anymovies(url)

        #    elif select == 9:
        #        from resources.lib.indexers import teniesonline
        #        url = Teniesonline + "?s={}".format(search)
        #        dbcur.execute("DELETE FROM Search WHERE url = ?", (url,))
        #        dbcur.execute("INSERT INTO Search VALUES (?,?)", (url, term))
        #        dbcon.commit()
        #        dbcur.close()
        #        teniesonline.search(url)

            else:
                return
        else:
            return

    else:
        if 'tainiomania' in url:
            from resources.lib.indexers import tainiomania
            tainiomania.search(url)

        elif 'subs4free' in url:
            from resources.lib.indexers import coverapi
            coverapi.coverapi_search(url)

    #    elif 'doomovies' in url:
    #        from resources.lib.indexers import doomovies
    #        doomovies.doomovies_s(url)

        elif 'gamato' in url:
            gamato_search(url)

        elif 'xrysoi' in url:
            from resources.lib.indexers import xrysoi
            xrysoi.xrysoimovies(url)

        elif 'gamatomovies' in url:
            from resources.lib.indexers import gamatomovies
            gamatomovies.gamatomovies(url)

        elif 'myvideolinks' in url:
            from resources.lib.indexers import myvideolinks
            myvideolinks.myvideolinks(url)

    #    elif 'anymovies' in url:
    #        from resources.lib.indexers import anymovies
    #        anymovies.search(url)

    #    elif 'teniesonline' in url:
    #        from resources.lib.indexers import teniesonline
    #        teniesonline.search(url)
#    views.selectView('menu', 'menu-view')


def Del_search(url):
    control.busy()
    search = url.split('s=')[1].decode('utf-8')

    dbcon = database.connect(control.searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE FROM Search WHERE search = ?", (search,))
    dbcon.commit()
    dbcur.close()
    xbmc.executebuiltin('Container.Refresh')
    control.idle()


def download(name, iconimage, url):
    from resources.lib.modules import control
    control.busy()
    import json
    if url is None:
        control.idle()
        return

    try:

        url = evaluate(url)
        # xbmc.log('URL-EVALUATE: %s' % url)
    except Exception:
        control.idle()
        xbmcgui.Dialog().ok(NAME, 'Download failed', 'Your service can\'t resolve this hoster', 'or Link is down')
        return
    try:
        headers = dict(parse_qsl(url.rsplit('|', 1)[1]))
    except BaseException:
        headers = dict('')
    control.idle()
    title = re.sub('\[.+?\]', '', name)
    content = re.compile('(.+?)\s+[\.|\(|\[]S(\d+)E\d+[\.|\)|\]]', re.I).findall(title)
    transname = title.translate(None, '\/:*?"<>|').strip('.')
    transname = re.sub('\[.+?\]', '', transname)
    levels = ['../../../..', '../../..', '../..', '..']
    if len(content) == 0:
        dest = control.setting('movie.download.path')
        dest = control.transPath(dest)
        for level in levels:
            try:
                control.makeFile(os.path.abspath(os.path.join(dest, level)))
            except:
                pass
        control.makeFile(dest)
        dest = os.path.join(dest, transname)
        control.makeFile(dest)
    else:
        dest = control.setting('tv.download.path')
        dest = control.transPath(dest)
        for level in levels:
            try:
                control.makeFile(os.path.abspath(os.path.join(dest, level)))
            except:
                pass
        control.makeFile(dest)
        tvtitle = re.sub('\[.+?\]', '', content[0])
        transtvshowtitle = tvtitle.translate(None, '\/:*?"<>|').strip('.')
        dest = os.path.join(dest, transtvshowtitle)
        control.makeFile(dest)
        dest = os.path.join(dest, 'Season %01d' % int(content[0][1]))
        control.makeFile(dest)
    control.idle()
    # ext = os.path.splitext(urlparse(url).path)[1]

    ext = os.path.splitext(urlparse(url).path)[1][1:]
    # xbmc.log('URL-EXT: %s' % ext)
    if not ext in ['mp4', 'mkv', 'flv', 'avi', 'mpg']: ext = 'mp4'
    dest = os.path.join(dest, transname + '.' + ext)
    headers = quote_plus(json.dumps(headers))
    # xbmc.log('URL-HEADERS: %s' % headers)

    from resources.lib.modules import downloader
    control.idle()
    downloader.doDownload(url, dest, name, iconimage, headers)


def downloads_root():
    movie_downloads = control.setting('movie.download.path')
    tv_downloads = control.setting('tv.download.path')
    cm = [(control.lang(32007),
           'RunPlugin(plugin://plugin.video.atlas/?mode=17)'),
          (control.lang(32008), 'RunPlugin(plugin://plugin.video.atlas/?mode=9)')]
    if len(control.listDir(movie_downloads)[0]) > 0:
        item = control.item(label='Movies')
        item.addContextMenuItems(cm)
        item.setArt({'icon': ART + 'movies.jpg', 'fanart': FANART})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), movie_downloads, item, True)

    if len(control.listDir(tv_downloads)[0]) > 0:
        item = control.item(label='Tv Shows')
        item.addContextMenuItems(cm)
        item.setArt({'icon': ART + 'tvshows.jpg', 'fanart': FANART})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), tv_downloads, item, True)

    control.content(int(sys.argv[1]), 'videos')
    control.directory(int(sys.argv[1]))
#    views.selectView('menu', 'menu-view')


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt


def Open_settings():
    control.openSettings()


def cache_clear():
    cache.clear(withyes=False)


def search_clear():
    cache.delete(control.searchFile, withyes=False)
    control.refresh()
    control.idle()


def resolve(name, url, iconimage, description, return_url=False):
    liz = xbmcgui.ListItem(name)
    host = url
    if '/links/' in host:
        try:
            frame = client.request(host)
            host = client.parseDOM(frame, 'a', {'id': 'link'}, ret='href')[0]

        except BaseException:
            host = requests.get(host, allow_redirects=False).headers['Location']

    elif 'gosafedomain' in host:
        host = requests.get(host, allow_redirects=False).headers['Location']

    elif 'vidzstore.com' in host:
        html = requests.get(host).text
        host = re.findall(r'''file\s*:\s*['"](.+?)['"]''', html, re.DOTALL)[0]

    elif ('gmtv1' in host or 'gmtdb' in host or 'gmtbase' in host or 'gmtcloud' in host or 'gmtvm' in host or '.best' in host):
        html = requests.get(host).text
        try:
            host = client.parseDOM(html, 'source', ret='src', attrs={'type': '"video/mp4"'})[0]
            host = host.replace('?id=0', '')
        except IndexError:
            host = client.parseDOM(html, 'iframe', ret='src')[0]

    else:
        host = host

    # try resolveurl first:
    stream_url = evaluate(host)
    if not stream_url:
        if 'gamato' in host:
            html = requests.get(host).text
            host = client.parseDOM(html, 'source', ret='src')[0]
        else:
            pass
        if host.split('|')[0].endswith('.mp4?id=0') and 'clou' in host or 'gmtdb' in host or 'gmtcloud' in host:
            stream_url = host + '||User-Agent=iPad&Referer={}'.format(GAMATO)
            name = name
        elif host.endswith('.mp4') and 'vidce.net' in host:
            stream_url = host + '|User-Agent={}'.format(quote_plus(client.agent()))
        elif host.endswith('.mp4'):
            stream_url = host + '|User-Agent=%s&Referer=%s' % (quote_plus(client.agent(), ':/'), GAMATO)
        # stream_url = requests.get(host, headers=hdr).url
        elif host.endswith('.m3u8'):
            stream_url = host + '|User-Agent={}'.format(quote_plus(client.agent()))
        elif '/aparat.' in host:
            try:
                from resources.lib.resolvers import aparat
                stream_url = aparat.get_video(host)
                stream_url, sub = stream_url.split('|')
                liz.setSubtitles([sub])
            except BaseException:
                stream_url = evaluate(host)
        elif 'wetransfer.com' in host:
            stream_url = host + '|User-Agent={}'.format(quote_plus(client.agent()))

        # elif '/clipwatching.' in host:
        #     xbmc.log('HOST: {}'.format(host))
        #     # try:
        #     data = requests.get(host).text
        #     xbmc.log('DATA: {}'.format(data))
        #     try:
        #         sub = client.parseDOM(data, 'track', ret='src', attrs={'label': 'Greek'})[0]
        #         xbmc.log('SUBS: {}'.format(sub))
        #         liz.setSubtitles([sub])
        #     except IndexError:
        #         pass
        #
        #     stream_url = re.findall(r'''sources:\s*\[\{src:\s*['"](.+?)['"]\,''', data, re.DOTALL)[0]
        #     xbmc.log('HOST111: {}'.format(stream_url))
        #
        #
        #     # except BaseException:
        #     #     stream_url = evaluate(stream_url)

        elif 'coverapi' in host:   # Thanks to bugatsinho for the solution #
            html = client.request(host)
            xbmc.log('ΠΟΣΤ_html: {}'.format(html))
            news_id = re.findall(r'''['"]players['"], news_id: ['"](\d+)['"]}''', html, re.DOTALL)[0]

            xbmc.log('ΠΟΣΤ_html: {}'.format(news_id))
            # postdata = {'mod': 'players',
            #             'news_id': news_id}
            postdata = 'mod=players&news_id={}'.format(news_id)
            post_url = 'https://coverapi.store/engine/ajax/controller.php'
            post_html = client.request(post_url, post=postdata.encode('utf-8')).replace('\\', '')

            # xbmc.log('ΠΟΣΤ_ΔΑΤΑ: {}'.format(post_html))
            stream_url = re.findall(r'''file\s*:\s*['"](.+?)['"]''', post_html, re.DOTALL)[0]
            # xbmc.log('ΠΟΣΤ_URL: {}'.format(stream_url))
            if 'http' in stream_url:
                stream_url = stream_url + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')
            else:
                playlist_url = 'https://coverapi.store/' + stream_url
                data = requests.get(playlist_url).json()
                # xbmc.log('ΠΟΣΤ_ΔΑΤΑ: {}'.format(data))
                comments = []
                streams = []

                data = data['playlist']
                for dat in data:
                    com = dat['comment']
                    url = dat['file']

                    com = com.replace('Episode', 'Επεισόδιο').replace('GR Audio', '- [COLOR white][B]Μεταγλωττισμένο (Ελληνικά)[/B][/COLOR]')
                    com = com.replace('GR Subtitles', '- [COLOR white][B]Υπότιτλοι (Ελληνικά)[/B][/COLOR]')
                    com = com.replace('ENG SUB', '- [COLOR white][B]Υπότιτλοι (Αγγλικά)[/B][/COLOR]')
                    com = com.replace('Season', '[COLOR orange][B]* Τα επεισόδια δεν είναι διαθέσιμα στο πρόσθετο * - [COLOR white][B]Σεζόν[/B][/COLOR]')
                    comments.append(com)
                    streams.append(url)

                if len(comments) > 1:
                    dialog = xbmcgui.Dialog()
                    ret = dialog.select('[COLOR orange][B]Επιλογή:[/B][/COLOR]', comments)
                    if ret == -1:
                        return
                    elif ret > -1:
                        host = streams[ret]
                    # xbmc.log('@#@HDPRO:{}'.format(host))User-Agent=iPad&verifypeer=false
                        stream_url = host + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')
                    else:
                        return

                else:
                    host = streams[0]
                    stream_url = host + '|User-Agent=iPad&Referer={}&verifypeer=false'.format('https://coverapi.store/')

    else:
        name = name.split(' [B]|')[0]
    if return_url:
        return stream_url

    try:
        liz.setArt({"icon": iconimage, "thumb": iconimage, "fanart": fanart})
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("IsPlayable", "true")
        liz.setPath(str(stream_url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except BaseException:
        control.infoDialog(Lang(32012), NAME)
    if setting('Υπότιτλοι') == 'true':
        if not (stream_url in host or 'coverapi' in host or 'youtube' in host or 'gmtbase' in host or 'gamato' in host or 'gmtbase' in url):
            xbmc.sleep(40000)
            xbmc.executebuiltin('ActivateWindow(SubtitleSearch)')


def evaluate(host):
    import resolveurl
    try:
        url = None
    #    if 'openload' in host:
    #        try:
    #            from resources.lib.resolvers import openload
    #            oplink = openload.get_video_openload(host)
    #            url = resolveurl.resolve(oplink) if oplink == '' else oplink
    #        except BaseException:
    #            url = resolveurl.resolve(host)

        if resolveurl.HostedMediaFile(host):
            url = resolveurl.resolve(host)

        return url
    except BaseException:
        return


def change():
    addon = xbmcaddon.Addon()
    rootDir = translatePath(addon.getAddonInfo('path'))
    changelog = translatePath(os.path.join(rootDir, 'changelog.txt'))
    version = addon.getAddonInfo('version')

    if addon.getSetting('changelog_version') == version or not os.path.isfile(changelog):
        return
    addon.setSetting('changelog_version', version)
    heading = '[B][COLOR orange]*** ΑΤΛΑΣ ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

            
        announce += line
    f.close()
    utils.textBox(heading, announce)


def site_streamzz():
    if xbmc.getCondVisibility('system.platform.android'): opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://streamzz.to/x5f333dd3f45ecd88de33d3d1a24da533' ) )
    else: opensite = webbrowser . open('https://streamzz.to/x5f333dd3f45ecd88de33d3d1a24da533')

def donate():
    if xbmc.getCondVisibility('system.platform.android'): opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.paypal.com/donate/?hosted_button_id=9BYB23J5H5XSY' ) )
    else: opensite = webbrowser . open('https://www.paypal.com/donate/?hosted_button_id=9BYB23J5H5XSY')

icon = p.get_icon()
params = init.params
mode = params.get('mode')
name = params.get('name')
iconimage = params.get('iconimage')
fanart = params.get('fanart')
description = params.get('description')
url = params.get('url')

try:
    url = unquote_plus(params["url"])
except BaseException:
    pass
try:
    name = unquote_plus(params["name"])
except BaseException:
    pass
try:
    iconimage = unquote_plus(params["iconimage"])
except BaseException:
    pass
try:
    mode = int(params["mode"])
except BaseException:
    pass
try:
    fanart = unquote_plus(params["fanart"])
except BaseException:
    pass
try:
    description = unquote_plus(params["description"])
except BaseException:
    pass

xbmc.log('{}: {}'.format(str(ID), str(VERSION)))
xbmc.log('{}: {}'.format('Mode', str(mode)))
xbmc.log('{}: {}'.format('URL', str(url)))
xbmc.log('{}: {}'.format('Name', str(name)))
xbmc.log('{}: {}'.format('ICON', str(iconimage)))


#####################*ATLAS*#####################

if mode is None:
    Main_addDir()

#elif mode == 1:

#elif mode == 2:

#elif mode == 3:

elif mode == 4:
    Search(url)

#elif mode == 5:

elif mode == 6:
    search_menu()

#elif mode == 7:

elif mode == 8:
    Sports_nemu()

elif mode == 9:
    cache_clear()

elif mode == 10:
    Movies_maim()

elif mode == 11:
    Series_maim()

elif mode == 12:
    Old_maim()

elif mode == 13:
    Greek_maim()

elif mode == 14:
    Series()

###############GAMATO##########################

elif mode == 15:
    Gamato_collections()

elif mode == 16:
    Gamato_menu()

elif mode == 17:
    Open_settings()

elif mode == 18:
    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        url = GAMATO + "?s={}".format(search)
        gamato_search(url)
    else:
        pass

elif mode == 19:
    gamato_search(url)

elif mode == 20:
    gamato_links(name, url, iconimage, description)

elif mode == 21:
    gamato(url)

elif mode == 22:
    gamato_years()

elif mode == 23:
    gamato_genre()

################################################

elif mode == 28:
    Del_search(url)

elif mode == 29:
    search_clear()

###############TAINIESONLINE##################

elif mode == 30:
    from resources.lib.indexers import teniesonline
    teniesonline.menu()

elif mode == 31:
    from resources.lib.indexers import teniesonline
    teniesonline.Tainiesonline_menu()

elif mode == 33:
    from resources.lib.indexers import teniesonline
    teniesonline.get_links(name, url, iconimage, description)

elif mode == 34:
    from resources.lib.indexers import teniesonline
    teniesonline.metaglotismeno(url)

elif mode == 35:
    from resources.lib.indexers import teniesonline

    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = quote_plus(keyb.getText())
        url = Teniesonline + "?s={}".format(search)
        teniesonline.search(url)
    else:
        pass

elif mode == 36:
    from resources.lib.indexers import TainiesOnline_year
    TainiesOnline_year.tainiesonline_year()
    
elif mode == 37:
    from resources.lib.indexers import TainiesOnline_genre
    TainiesOnline_genre.tainiesonline_genre()

##############################################

elif mode == 40:
    downloads_root()

elif mode == 41:
    download(name, iconimage, url)

#######################XRYSOI#################

elif mode == 42:
    from resources.lib.indexers import xrysoi
    xrysoi.menu()

elif mode == 43:
    from resources.lib.indexers import xrysoi
    xrysoi.get_links(name, url, iconimage, description)

elif mode == 44:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies(url)

elif mode == 45:
    from resources.lib.indexers import xrysoi
    xrysoi.search(url)

elif mode == 46:
    from resources.lib.indexers import Xrysoi_year
    Xrysoi_year.xrysoi_year()

elif mode == 47:
    from resources.lib.indexers import Xrysoi_genre
    Xrysoi_genre.xrysoi_genre()

elif mode == 48:
    from resources.lib.indexers import xrysoi
    xrysoi.Xrysoi_menu()

elif mode == 49:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoiseries(url)

elif mode == 50:
    from resources.lib.indexers import xrysoi
    xrysoi.search_series()

elif mode == 51:
    from resources.lib.indexers import xrysoi
    xrysoi.menu_genre()

elif mode == 52:
    from resources.lib.indexers import xrysoi
    xrysoi.menu_year()

elif mode == 53:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies_search(url)

elif mode == 54:
    from resources.lib.indexers import xrysoi
    xrysoi.get_links_series(name, url, iconimage, description)

elif mode == 55:
    from resources.lib.indexers import xrysoi
    xrysoi.xrysoimovies_search_series(url)

####################YOUTUBE###################

elif mode == 56:
    MainYoutube(url)

elif mode == 57:
    play_video(name, url, icon)

elif mode == 58:
    yt_channel(url)

elif mode == 59:
    yt_playlist(url)

elif mode == 60:
    MainYoutube(yt_xml)

elif mode == 61:
    MainYoutube(yt1_xml)

elif mode == 62:
    MainYoutube(yt2_xml)

elif mode == 63:
    MainYoutube(yt3_xml)

elif mode == 64:
    MainYoutube(yt4_xml)

elif mode == 65:
    MainYoutube(yt5_xml)

elif mode == 66:
    MainYoutube(yt6_xml)

###################################################

elif mode == 80:
    kids_menu()

elif mode == 81:
    documentary_menu()

elif mode == 82:
    site_streamzz()

elif mode == 83:
    donate()

###################TAINIOMANIA######################

elif mode == 84:
    from resources.lib.indexers import tainiomania
    tainiomania.Tainiomania_menu()

elif mode == 85:
    from resources.lib.indexers import tainiomania
    tainiomania.search(url)

elif mode == 86:
    from resources.lib.indexers import tainiomania
    tainiomania.menu_year()

elif mode == 87:
    from resources.lib.indexers import tainiomania
    tainiomania.menu_genre()

elif mode == 88:
    from resources.lib.indexers import tainiomania
    tainiomania.get_links(name, url, iconimage, description)

elif mode == 89:
    from resources.lib.indexers import tainiomania
    tainiomania.tainiomania(url)

###################ANYMOVIES######################

elif mode == 90:
    from resources.lib.indexers import anymovies
    anymovies.search(url)

elif mode == 91:
    from resources.lib.indexers import anymovies
    anymovies.menu_year()

elif mode == 92:
    from resources.lib.indexers import anymovies
    anymovies.menu_genre()

elif mode == 93:
    from resources.lib.indexers import anymovies
    anymovies.get_links(name, url, iconimage, description)

elif mode == 94:
    from resources.lib.indexers import anymovies
    anymovies.anymovies(url)

elif mode == 95:
    from resources.lib.indexers import anymovies
    anymovies.Anymovies_menu()


###################OIPEIRATES#####################

#elif mode == 95:
#    from resources.lib.indexers import oipeirates
#    oipeirates.search(url)

#elif mode == 96:
#    from resources.lib.indexers import oipeirates
#    oipeirates.oipeirates(url)

#elif mode == 97:
#    from resources.lib.indexers import oipeirates
#    oipeirates.menu_year()

#elif mode == 98:
#    from resources.lib.indexers import oipeirates
#    oipeirates.menu_genre()

#elif mode == 99:
#    from resources.lib.indexers import oipeirates
#    oipeirates.get_links(name, url, iconimage, description)

#elif mode == 111:
#    from resources.lib.indexers import oipeirates
#    oipeirates.get_links_series(name, url, iconimage, description)

#elif mode == 112:
#    from resources.lib.indexers import oipeirates
#    oipeirates.oipeirates_series(url)

######################RESOLVE#######################

elif mode == 100:
    resolve(name, url, iconimage, description)


####################MYVIDEOLINKS###################

elif mode == 96:
    from resources.lib.indexers import myvideolinks
    myvideolinks.Myvideolinks_menu()

elif mode == 101:
    from resources.lib.indexers import myvideolinks
    myvideolinks.search(url)

elif mode == 102:
    from resources.lib.indexers import myvideolinks
    myvideolinks.myvideolinks(url)

elif mode == 103:
    from resources.lib.indexers import myvideolinks
    myvideolinks.get_links(name, url, iconimage, description)

elif mode == 1040:
    from resources.lib.indexers import myvideolinks
    myvideolinks.get_links_series(name, url, iconimage, description)


####################BNWMOVIES###################

elif mode == 104:
    from resources.lib.indexers import bnwmovies
    bnwmovies.menu_genre()

elif mode == 105:
    from resources.lib.indexers import bnwmovies
    bnwmovies.bnwmovies(url)

elif mode == 106:
    from resources.lib.indexers import bnwmovies
    bnwmovies.get_links(name, url, iconimage, description)

################COOLMOVIEZONE###################

elif mode == 107:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.menu_year()

elif mode == 108:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.menu_genre()

elif mode == 109:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.coolmoviezone(url)

elif mode == 110:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.get_links(name, url, iconimage, description)

elif mode == 113:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.search(url)

elif mode == 114:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.coolmoviezone_2(url)

elif mode == 115:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.get_links_search(name, url, iconimage, description)

elif mode == 116:
    from resources.lib.indexers import coolmoviezone
    coolmoviezone.coolmoviezone_search(url)

###################NTOKIMANTER.GR###################

elif mode == 117:
    from resources.lib.indexers import ntokimanter
    ntokimanter.menu_genre()

elif mode == 118:
    from resources.lib.indexers import ntokimanter
    ntokimanter.ntokimanter(url)

elif mode == 119:
    from resources.lib.indexers import ntokimanter
    ntokimanter.get_links(name, url, iconimage, description)

#elif mode == 120:


###################GAMATOMOVIES###################

elif mode == 121:
    from resources.lib.indexers import gamatomovies
    gamatomovies.search(url)

elif mode == 122:
    from resources.lib.indexers import gamatomovies
    gamatomovies.gamatomovies(url)

elif mode == 123:
    from resources.lib.indexers import gamatomovies
    gamatomovies.get_links(name, url, iconimage, description)

elif mode == 124:
    from resources.lib.indexers import gamatomovies
    gamatomovies.menu_year()

elif mode == 125:
    from resources.lib.indexers import gamatomovies
    gamatomovies.menu_genre()

elif mode == 126:
    from resources.lib.indexers import gamatomovies
    gamatomovies.gamatomoviestv(url)

elif mode == 127:
    from resources.lib.indexers import gamatomovies
    gamatomovies.season_tv(url)

elif mode == 129:
    from resources.lib.indexers import gamatomovies
    gamatomovies.epi_tv(name, url, iconimage, description)

elif mode == 130:
    from resources.lib.indexers import gamatomovies
    gamatomovies.get_links_tv(name, url, iconimage, description)

elif mode == 131:
    from resources.lib.indexers import gamatomovies
    gamatomovies.GamatoMovies_menu()

###################WATCHSERIES######################

elif mode == 132:
    from resources.lib.indexers import watchseries
    watchseries.get_links(name, url, iconimage, description)

elif mode == 133:
    from resources.lib.indexers import watchseries
    watchseries.watchseries(url)

###################FMOVIES######################

elif mode == 134:
    from resources.lib.indexers import fmovies
    fmovies.search(url)

elif mode == 135:
    from resources.lib.indexers import fmovies
    fmovies.menu_year()

elif mode == 136:
    from resources.lib.indexers import fmovies
    fmovies.menu_genre()

elif mode == 137:
    from resources.lib.indexers import fmovies
    fmovies.get_links(name, url, iconimage, description)

elif mode == 138:
    from resources.lib.indexers import fmovies
    fmovies.get_links_s(name, url, iconimage, description)

elif mode == 139:
    from resources.lib.indexers import fmovies
    fmovies.fmovies(url)

elif mode == 140:
    from resources.lib.indexers import fmovies
    fmovies.Fmovies_menu()

elif mode == 141:
    from resources.lib.indexers import fmovies
    fmovies.menu_country()


###################DOOMOVIES######################

elif mode == 149:
    from resources.lib.indexers import doomovies
    doomovies.doomovies_search(url)

elif mode == 150:
    from resources.lib.indexers import doomovies
    doomovies.search(url)

elif mode == 151:
    from resources.lib.indexers import doomovies
    doomovies.menu_year()

elif mode == 152:
    from resources.lib.indexers import doomovies
    doomovies.menu_genre()

elif mode == 153:
    from resources.lib.indexers import doomovies
    doomovies.get_links(name, url, iconimage, description)

elif mode == 154:
    from resources.lib.indexers import doomovies
    doomovies.doomovies(url)

elif mode == 155:
    from resources.lib.indexers import doomovies
    doomovies.Doomovies_menu()

elif mode == 156:
    from resources.lib.indexers import doomovies
    doomovies.doomovies_s(url)


####################COUCHTUNER###################


elif mode == 161:
    from resources.lib.indexers import couchtuner
    couchtuner.couchtuner_2(url)

elif mode == 162:
    from resources.lib.indexers import couchtuner
    couchtuner.get_links_2(name, url, iconimage, description)

elif mode == 163:
    from resources.lib.indexers import couchtuner
    couchtuner.search(url)

elif mode == 164:
    from resources.lib.indexers import couchtuner
    couchtuner.couchtuner(url)

elif mode == 165:
    from resources.lib.indexers import couchtuner
    couchtuner.get_links(name, url, iconimage, description)

###################GOOJARA###################

elif mode == 170:
    from resources.lib.indexers import goojara
    goojara.Goojara_menu()

elif mode == 171:
    from resources.lib.indexers import goojara
    goojara.search(url)

elif mode == 172:
    from resources.lib.indexers import goojara
    goojara.goojara(url)

elif mode == 173:
    from resources.lib.indexers import goojara
    goojara.get_links(name, url, iconimage, description)

elif mode == 174:
    from resources.lib.indexers import goojara
    goojara.menu_year()

elif mode == 175:
    from resources.lib.indexers import goojara
    goojara.menu_genre()

elif mode == 176:
    from resources.lib.indexers import goojara
    goojara.get_links2(name, url, iconimage, description)

###################GREEKMOVIES######################

elif mode == 177:
    from resources.lib.indexers import greekmovies
    greekmovies.Sports()

elif mode == 178:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_menu()

elif mode == 179:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_Series_menu()

elif mode == 180:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_Movie_menu()

elif mode == 181:
    from resources.lib.indexers import greekmovies
    greekmovies.greekmovies_search(url)

elif mode == 182:
    from resources.lib.indexers import greekmovies
    greekmovies.search(url)

elif mode == 183:
    from resources.lib.indexers import greekmovies
    greekmovies.movie_menu_year_grek()

elif mode == 184:
    from resources.lib.indexers import greekmovies
    greekmovies.menu_genre()

elif mode == 185:
    from resources.lib.indexers import greekmovies
    greekmovies.get_links(name, url, iconimage, description)

elif mode == 186:
    from resources.lib.indexers import greekmovies
    greekmovies.greekmovies(url)

elif mode == 187:
    from resources.lib.indexers import greekmovies
    greekmovies.get_links2(name, url, iconimage, description)

elif mode == 188:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_greek()

elif mode == 189:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_small()

elif mode == 190:
    from resources.lib.indexers import greekmovies
    greekmovies.movie_menu_year_small()

elif mode == 191:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_series_greek()

elif mode == 192:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_series_small()

elif mode == 193:
    from resources.lib.indexers import greekmovies
    greekmovies.greekmovies_series(url)

elif mode == 194:
    from resources.lib.indexers import greekmovies
    greekmovies.get_links_s(name, url, iconimage, description)

elif mode == 195:
    from resources.lib.indexers import greekmovies
    greekmovies.get_links_s2(name, url, iconimage, description)

elif mode == 196:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_theater()

elif mode == 197:
    from resources.lib.indexers import greekmovies
    greekmovies.menu_year_theater()

elif mode == 198:
    from resources.lib.indexers import greekmovies
    greekmovies.greekmovies_spors(url)

elif mode == 199:
    from resources.lib.indexers import greekmovies
    greekmovies.get_links_sports(name, url, iconimage, description)

elif mode == 200:
    from resources.lib.indexers import greekmovies
    greekmovies.get_links_sports2(name, url, iconimage, description)

elif mode == 201:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_sports()

elif mode == 202:
    from resources.lib.indexers import greekmovies
    greekmovies.menu_year_sports()

elif mode == 203:
    from resources.lib.indexers import greekmovies
    greekmovies.Greekmovies_year_kids()


###################GOWATCHSERIES###################

elif mode == 210:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries_menu_a()

elif mode == 211:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries_menu_tv()

elif mode == 212:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries_menu()

elif mode == 213: 
    from resources.lib.indexers import gowatchseries
    gowatchseries.search(url)

elif mode == 214:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries(url)

elif mode == 215:
    from resources.lib.indexers import gowatchseries
    gowatchseries.get_links(name, url, iconimage, description)

elif mode == 216:
    from resources.lib.indexers import gowatchseries
    gowatchseries.menu_year()

elif mode == 217:
    from resources.lib.indexers import gowatchseries
    gowatchseries.menu_genre()

elif mode == 218:
    from resources.lib.indexers import gowatchseries
    gowatchseries.get_links_s(name, url, iconimage, description)

elif mode == 219:
    from resources.lib.indexers import gowatchseries
    gowatchseries.menu_year_tv()

elif mode == 220:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries_s(url)

elif mode == 221:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries_m(url)

elif mode == 222:
    from resources.lib.indexers import gowatchseries
    gowatchseries.get_links_ss(name, url, iconimage, description)

elif mode == 223:
    from resources.lib.indexers import gowatchseries
    gowatchseries.get_links_type2(name, url, iconimage, description)

elif mode == 224:
    from resources.lib.indexers import gowatchseries
    gowatchseries.gowatchseries_type2(url)

###################MVTVLOOK######################

elif mode == 229:
    from resources.lib.indexers import mvtvlook
    mvtvlook.mvtvlook_menu_tv()

elif mode == 230:
    from resources.lib.indexers import mvtvlook
    mvtvlook.mvtvlook_menu()

elif mode == 231:
    from resources.lib.indexers import mvtvlook
    mvtvlook.search(url)

elif mode == 232:
    from resources.lib.indexers import mvtvlook
    mvtvlook.menu_year()

elif mode == 233:
    from resources.lib.indexers import mvtvlook
    mvtvlook.menu_genre()

elif mode == 234:
    from resources.lib.indexers import mvtvlook
    mvtvlook.get_links(name, url, iconimage, description)

elif mode == 235:
    from resources.lib.indexers import mvtvlook
    mvtvlook.mvtvlook(url)

elif mode == 236:
    from resources.lib.indexers import mvtvlook
    mvtvlook.get_links_tv(name, url, iconimage, description)

elif mode == 237:
    from resources.lib.indexers import mvtvlook
    mvtvlook.menu_coundry()

elif mode == 238:
    from resources.lib.indexers import mvtvlook
    mvtvlook.mvtvlook_23(url)


###################AN1ME######################

elif mode == 250:
    from resources.lib.indexers import an1me
    an1me.search(url)

elif mode == 251:
    from resources.lib.indexers import an1me
    an1me.menu_alphabet()

elif mode == 252:
    from resources.lib.indexers import an1me
    an1me.menu_genre()

elif mode == 253:
    from resources.lib.indexers import an1me
    an1me.get_links(name, url, iconimage, description)

elif mode == 254:
    from resources.lib.indexers import an1me
    an1me.an1me(url)

elif mode == 255:
    from resources.lib.indexers import an1me
    an1me.An1me_menu()

elif mode == 256:
    from resources.lib.indexers import an1me
    an1me.get_links2(name, url, iconimage, description)

elif mode == 257:
    from resources.lib.indexers import an1me
    an1me.an1me_alphabet(url)

elif mode == 258:
    from resources.lib.indexers import an1me
    an1me.get_alphabet(name, url, iconimage, description)

elif mode == 259:
    from resources.lib.indexers import an1me
    an1me.an1me_genre(name, url, iconimage, description)


###################SUBS4FREE######################

elif mode == 261:
    from resources.lib.indexers import coverapi
    coverapi.coverapi_menu()

elif mode == 262:
    from resources.lib.indexers import coverapi
    coverapi.coverapi(url)

elif mode == 263:
    from resources.lib.indexers import coverapi
    coverapi.get_links(name, url, iconimage, description)

elif mode == 264:
    from resources.lib.indexers import coverapi
    coverapi.search(url)

elif mode == 265:
    from resources.lib.indexers import coverapi
    coverapi.coverapi_search(url)

###################DADDYLIVE######################

elif mode == 240:
    from resources.lib.indexers import daddylive
    daddylive.Main_Menu()
else:
    from resources.lib.indexers import daddylive
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            daddylive.Menu_Trans()
        if servType == 'schedGR':
            daddylive.Menu_TransGR()
        if servType == 'live_tv':
            daddylive.list_gen()
        if servType=='live_tv_gr':
            daddylive.list_gen_gr()

    if mode == 'showChannels':
        transType = params.get('trType')
        channels = daddylive.getTransData(transType)
        daddylive.ShowChannels(transType, channels)

    if mode == 'showChannelsGR':
        transType = params.get('trType')
        channels = daddylive.getTransDataGR(transType)
        daddylive.ShowChannels(transType, channels)

    if mode == 'trList':
        transType = params.get('trType')
        channels = json.loads(params.get('channels'))
        daddylive.TransList(transType, channels)

    if mode == 'trLinks':
        trData = params.get('trData')
        daddylive.getSource(trData)

    if mode == 'play':
        link = params.get('url')
        daddylive.PlayStream(link)


xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    change()
    sys.exit()
