# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_an1me = ART + 'an1me.png'
AN1ME = 'https://an1me.to/'


def An1me_menu(): #255
    addDir('[B][COLOR slateblue]Ταινίες[/COLOR][/B]', AN1ME + 'anime-type/movie/', 254, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]Σειρές[/COLOR][/B]', AN1ME + 'anime-type/tv/', 257, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]Είδος[/COLOR][/B]', '', 252, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]SUB[/COLOR][/B]', AN1ME + 'anime_attribute/sub/', 257, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]DUB[/COLOR][/B]', AN1ME + 'anime_attribute/dub/', 257, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]A-Z[/COLOR][/B]', AN1ME + 'az-list/', 251, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]ONA[/COLOR][/B]', AN1ME + 'anime-type/ona/', 257, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]OVA[/COLOR][/B]', AN1ME + 'anime-type/ova/', 257, ART + 'an1me.png', FANART, '')
    addDir('[B][COLOR slateblue]Σπέσιαλ[/COLOR][/B]', AN1ME + 'anime-type/special/', 257, ART + 'an1me.png', FANART, '')



def menu_alphabet(): #251
    addDir('[B][COLOR slateblue]ALL[/COLOR][/B]', AN1ME + 'az-list/?letter=A', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]#[/COLOR][/B]', AN1ME + 'az-list/?letter=other', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]0-9[/COLOR][/B]', AN1ME + 'az-list/?letter=0-9', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]A[/COLOR][/B]', AN1ME + 'az-list/?letter=A', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]B[/COLOR][/B]', AN1ME + 'az-list/?letter=B', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]C[/COLOR][/B]', AN1ME + 'az-list/?letter=C', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]D[/COLOR][/B]', AN1ME + 'az-list/?letter=D', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]E[/COLOR][/B]', AN1ME + 'az-list/?letter=E', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]F[/COLOR][/B]', AN1ME + 'az-list/?letter=F', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]G[/COLOR][/B]', AN1ME + 'az-list/?letter=G', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]H[/COLOR][/B]', AN1ME + 'az-list/?letter=H', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]I[/COLOR][/B]', AN1ME + 'az-list/?letter=I', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]J[/COLOR][/B]', AN1ME + 'az-list/?letter=J', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]K[/COLOR][/B]', AN1ME + 'az-list/?letter=K', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]L[/COLOR][/B]', AN1ME + 'az-list/?letter=L', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]M[/COLOR][/B]', AN1ME + 'az-list/?letter=M', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]N[/COLOR][/B]', AN1ME + 'az-list/?letter=N', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]O[/COLOR][/B]', AN1ME + 'az-list/?letter=O', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]P[/COLOR][/B]', AN1ME + 'az-list/?letter=P', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Q[/COLOR][/B]', AN1ME + 'az-list/?letter=Q', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]R[/COLOR][/B]', AN1ME + 'az-list/?letter=R', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]S[/COLOR][/B]', AN1ME + 'az-list/?letter=S', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]T[/COLOR][/B]', AN1ME + 'az-list/?letter=T', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]U[/COLOR][/B]', AN1ME + 'az-list/?letter=U', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]V[/COLOR][/B]', AN1ME + 'az-list/?letter=V', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]W[/COLOR][/B]', AN1ME + 'az-list/?letter=W', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]X[/COLOR][/B]', AN1ME + 'az-list/?letter=X', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Y[/COLOR][/B]', AN1ME + 'az-list/?letter=Y', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Z[/COLOR][/B]', AN1ME + 'az-list/?letter=Z', 257, icon_an1me, FANART, '')


def menu_genre(): #252
    addDir('[B][COLOR slateblue]Action[/COLOR][/B]', AN1ME + 'genre/action/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Adventure[/COLOR][/B]', AN1ME + 'genre/adventure/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Animation[/COLOR][/B]', AN1ME + 'genre/animation/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Avant Garde[/COLOR][/B]', AN1ME + 'genre/avant-garde/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Cars[/COLOR][/B]', AN1ME + 'genre/cars/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Comedy[/COLOR][/B]', AN1ME + 'genre/comedy/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Dementia[/COLOR][/B]', AN1ME + 'genre/dementia/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Demons[/COLOR][/B]', AN1ME + 'genre/demons/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Drama[/COLOR][/B]', AN1ME + 'genre/drama/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Ecchi[/COLOR][/B]', AN1ME + 'genre/ecchi/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Fantasy[/COLOR][/B]', AN1ME + 'genre/fantasy/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Gore[/COLOR][/B]', AN1ME + 'genre/gore/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Harem[/COLOR][/B]', AN1ME + 'genre/harem/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Historical[/COLOR][/B]', AN1ME + 'genre/historical/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Horror[/COLOR][/B]', AN1ME + 'genre/horror/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Josei[/COLOR][/B]', AN1ME + 'genre/josei/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Kids[/COLOR][/B]', AN1ME + 'genre/kids/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Magic[/COLOR][/B]', AN1ME + 'genre/magic/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Martial Arts[/COLOR][/B]', AN1ME + 'genre/martial-arts/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Isekai[/COLOR][/B]', AN1ME + 'genre/isekai/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Mecha[/COLOR][/B]', AN1ME + 'genre/mecha/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Military[/COLOR][/B]', AN1ME + 'genre/military/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Music[/COLOR][/B]', AN1ME + 'genre/music/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Mystery[/COLOR][/B]', AN1ME + 'genre/mystery/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Parody[/COLOR][/B]', AN1ME + 'genre/parody/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Police[/COLOR][/B]', AN1ME + 'genre/police/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Mythology[/COLOR][/B]', AN1ME + 'genre/mythology/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Psychological[/COLOR][/B]', AN1ME + 'genre/psychological/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Romance[/COLOR][/B]', AN1ME + 'genre/romance/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Samurai[/COLOR][/B]', AN1ME + 'genre/samurai/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]School[/COLOR][/B]', AN1ME + 'genre/school/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Sci-Fi[/COLOR][/B]', AN1ME + 'genre/sci-fi/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Seinen[/COLOR][/B]', AN1ME + 'genre/seinen/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Shoujo[/COLOR][/B]', AN1ME + 'genre/shoujo/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Shoujo Ai[/COLOR][/B]', AN1ME + 'genre/shoujo-ai/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Shounen[/COLOR][/B]', AN1ME + 'genre/shounen/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Slice of Life[/COLOR][/B]', AN1ME + 'genre/slice-of-life/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Space[/COLOR][/B]', AN1ME + 'genre/space/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Sports[/COLOR][/B]', AN1ME + 'genre/sports/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Super Power[/COLOR][/B]', AN1ME + 'genre/super-power/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Supernatural[/COLOR][/B]', AN1ME + 'genre/supernatural/', 257, icon_an1me, FANART, '')
#    addDir('[B][COLOR slateblue]Thriller[/COLOR][/B]', AN1ME + 'genre/thriller/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Survival[/COLOR][/B]', AN1ME + 'genre/survival/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Suspense[/COLOR][/B]', AN1ME + 'genre/suspense/', 257, icon_an1me, FANART, '')
    addDir('[B][COLOR slateblue]Vampire[/COLOR][/B]', AN1ME + 'genre/vampire/', 257, icon_an1me, FANART, '')


def an1me(url): #254
    hdrs = {'Referer': AN1ME,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<img src='(.+?)' class='absolute inset-0 object-cover w-full h-full rounded shadow' alt='(.+?)'  decoding='async'>.+?data-tippy-trigger data-tippy-content-to=.+?  href="(.+?)"''', re.DOTALL).findall(p)
    for icon, name, url in m:
        name = name.replace(' thumbnail', '')
        name = clear_Title(name)
        url = url.replace('anime', 'watch')
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 258, icon, '', '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 254, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')

def get_alphabet(name, url, iconimage, description): #258
    hdrs = {'Referer': AN1ME,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
#    if not 'movie' in url or 'ona' in url or 'ova' in url or 'special' in url:
    m = re.compile('''<iframe src='(.+?)' style=.+?''').findall(p)
    for url in m:
        addDir(name, url, 256, iconimage, '', '')

def get_links2(name, url, iconimage, description): #256
    hdrs = {'Referer': AN1ME,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('\s+<source src="(.+?)"').findall(p)
    for url in m:
        name = '[B][COLOR=lime]Play now... [/COLOR][/B]'
        addDir(name, url, 100, '', '', '')


def an1me_alphabet(url): #257
    hdrs = {'Referer': AN1ME,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<img src='(.+?)' class='absolute inset-0 object-cover w-full h-full rounded shadow' alt='(.+?)'  decoding='async'>.+?data-tippy-trigger data-tippy-content-to=.+?  href="(.+?)"''', re.DOTALL).findall(p)
    for icon, name, url in m:
        name = name.replace(' thumbnail', '')
        name = clear_Title(name)
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 259, icon, '', '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 254, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def an1me_genre(name, url, iconimage, description): #259
    hdrs = {'Referer': AN1ME,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<div class="swiper-slide">.+?<a href="(.+?)" class="\s+.+?>\s+<div class=.+?>\s+(.+?)</div>\s+<div class=.+? style=', re.DOTALL).findall(p)
    for url, season in m2:
        season = season.replace('Season', '[B][COLOR=lime] Σεζόν[/COLOR][/B]')
    #    url = url.replace('anime', 'watch')
        addDir(season, url, 259, 'http://i.imgur.com/ypLPk5x.png', '', '')

    try:
        m = re.compile('<div class="swiper-slide">.+?<a href="(.+?)".+?<span class=.+?>\s+(.+?)</.+?>', re.DOTALL).findall(p)
        for url, epi in m:
            if 'navigate_before' in epi: continue
            epi = epi.replace('Episode', '[B][COLOR=white]Επισόδειο[/COLOR][/B]')
            addDir(epi, url, 258, iconimage, '', '')

    except BaseException:
        pass

    views.selectView('movies', 'movie-view')



def get_links(name, url, iconimage, description): #253
    hdrs = {'Referer': AN1ME,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    if 'movie' in url or 'ona' in url or 'ova' in url or 'special' in url:
        m = re.compile('\s+<source src="(.+?)"').findall(p)
        for url in m:
            addDir(name, url, 100, iconimage, FANART, '')
    else:
        m2 = re.compile('<option class=.+? data-limit=.+? value=.+? data-redirect="(.+?)".+?(.+?)</option>').findall(p)
        for url, epi in m2:
            epi = epi.replace('Episode','Επισόδειο').replace('selected="selected">','')
            if 'dub' in url:
                epi = epi + ' | [COLOR lime](Μεταγλωττισμένo)[/COLOR]'
                addDir('[B][COLOR=white]%s[/COLOR][/B]' % epi, url, 256, iconimage, FANART, '')
            else:
                addDir('[B][COLOR=white]%s[/COLOR][/B]' % epi, url, 256, iconimage, FANART, '')




def search(url): #250
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://an1me.to/?s=' + search
        an1me(url)


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
