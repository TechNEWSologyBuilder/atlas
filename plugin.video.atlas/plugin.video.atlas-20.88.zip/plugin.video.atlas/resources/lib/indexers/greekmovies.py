# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_greekmovies = ART + 'greekmovies.png'
GREEKMOVIES = 'https://greek-movies.com/'

######################################################MAIN MENU#####################################################

def Greekmovies_menu(): #178
    addDir('[B][COLOR white]Ταινίες[/COLOR][/B]', '', 180, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Σειρές[/COLOR][/B]', '', 179, icon_greekmovies, FANART, '')
#    addDir('[B][COLOR white]Εκπομπές[/COLOR][/B]', '', 186, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Θέατρο[/COLOR][/B]', '', 196, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Αθλήματα[/COLOR][/B]', '', 201, icon_greekmovies, FANART, '')

######################################################MAIN MOVIES#####################################################

def Greekmovies_Movie_menu(): #180
    addDir('[B][COLOR white]Ελληνικές & Μεταγλωτισμένες[/COLOR][/B]', '', 188, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Μικρού μήκους[/COLOR][/B]', '', 189, icon_greekmovies, FANART, '')

def Greekmovies_greek(): #188
    addDir('[B][COLOR white]Έτος[/COLOR][/B]', '', 183, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Πρόσφατες καταχωρήσεις[/COLOR][/B]', GREEKMOVIES + 'movies', 186, icon_greekmovies, FANART, '')

def Greekmovies_small(): #189
    addDir('[B][COLOR white]Έτος[/COLOR][/B]', '', 190, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Πρόσφατες καταχωρήσεις[/COLOR][/B]', GREEKMOVIES + 'shortfilm', 186, icon_greekmovies, FANART, '')

def movie_menu_year_grek(): #183
    addDir('[COLOR white]2020-σήμερα[/COLOR]', GREEKMOVIES + 'movies.php?y=9&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2010-19[/COLOR]', GREEKMOVIES + 'movies.php?y=8&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2000-09[/COLOR]', GREEKMOVIES + 'movies.php?y=7&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1990-99[/COLOR]', GREEKMOVIES + 'movies.php?y=6&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1980-89[/COLOR]', GREEKMOVIES + 'movies.php?y=5&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1970-79[/COLOR]', GREEKMOVIES + 'movies.php?y=4&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1960-69[/COLOR]', GREEKMOVIES + 'movies.php?y=3&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1950-59[/COLOR]', GREEKMOVIES + 'movies.php?y=2&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]πριν το 1950[/COLOR]', GREEKMOVIES + 'movies.php?y=1&l=&g=&p=', 186, icon_greekmovies, FANART, '')

def movie_menu_year_small(): #190
    addDir('[COLOR white]2020-σήμερα[/COLOR]', GREEKMOVIES + 'shortfilm.php?y=5&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2010-19[/COLOR]', GREEKMOVIES + 'shortfilm.php?y=4&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2000-09[/COLOR]', GREEKMOVIES + 'shortfilm.php?y=3&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1990-99[/COLOR]', GREEKMOVIES + 'shortfilm.php?y=2&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]πριν το 1990[/COLOR]', GREEKMOVIES + 'shortfilm.php?y=1&l=&g=&p=', 186, icon_greekmovies, FANART, '')

######################################################MAIN THEATER#####################################################

def Greekmovies_theater(): #196
    addDir('[B][COLOR white]Έτος[/COLOR][/B]', '', 197, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Πρόσφατες καταχωρήσεις[/COLOR][/B]', GREEKMOVIES + 'theater', 186, icon_greekmovies, FANART, '')

def menu_year_theater(): #197
    addDir('[COLOR white]2020-σήμερα[/COLOR]', GREEKMOVIES + 'theater.php?y=7&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2010-19[/COLOR]', GREEKMOVIES + 'theater.php?y=6&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2000-09[/COLOR]', GREEKMOVIES + 'theater.php?y=5&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1990-99[/COLOR]', GREEKMOVIES + 'theater.php?y=4&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1980-89[/COLOR]', GREEKMOVIES + 'theater.php?y=3&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1970-79[/COLOR]', GREEKMOVIES + 'theater.php?y=2&l=&g=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]πριν το 1970[/COLOR]', GREEKMOVIES + 'theater.php?y=1&l=&g=&p=', 186, icon_greekmovies, FANART, '')

######################################################MAIN SPORTS#####################################################

def Sports(): #177
    addDir('[B][COLOR white]Ποδόσφαιρο[/COLOR][/B]', GREEKMOVIES + 'sports.php?s=1&y=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Καλαθοσφαίριση[/COLOR][/B]', GREEKMOVIES + 'sports.php?s=2&y=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Μηχανοκίνητος Αθλητισμός[/COLOR][/B]', GREEKMOVIES + 'sports.php?s=3&y=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Χειροσφαίριση[/COLOR][/B]', GREEKMOVIES + 'sports.php?s=4&y=', 198, icon_greekmovies, FANART, '')

def Greekmovies_sports(): #201
    addDir('[B][COLOR white]Όλα[/COLOR][/B]', GREEKMOVIES + 'sports', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Έτος[/COLOR][/B]', '', 202, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Αθλήματα[/COLOR][/B]', '', 177, icon_greekmovies, FANART, '')

def menu_year_sports(): #202
    addDir('[B][COLOR white]2023-24[/COLOR][/B]', GREEKMOVIES + 'sports.php?y=1&s=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]2022-23[/COLOR][/B]', GREEKMOVIES + 'sports.php?y=2&s=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]2021-22[/COLOR][/B]', GREEKMOVIES + 'sports.php?y=3&s=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]2020-21[/COLOR][/B]', GREEKMOVIES + 'sports.php?y=4&s=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]2019-20[/COLOR][/B]', GREEKMOVIES + 'sports.php?y=5&s=', 198, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]πριν το 2019-20[/COLOR][/B]', GREEKMOVIES + 'sports.php?y=6&s=', 198, icon_greekmovies, FANART, '')

##########################################################MAIN SERIES###################################################

def Greekmovies_Series_menu(): #179
    addDir('[B][COLOR white]Ελληνικές & Μεταγλωτισμένες[/COLOR][/B]', '', 191, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Κινουμένων Σχεδίων[/COLOR][/B]', '', 192, icon_greekmovies, FANART, '')

def Greekmovies_series_greek(): #191
    addDir('[B][COLOR white]Έτος[/COLOR][/B]', '', 183, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Πρόσφατες καταχωρήσεις[/COLOR][/B]', GREEKMOVIES + 'series', 193, icon_greekmovies, FANART, '')

def Greekmovies_series_small(): #192
    addDir('[B][COLOR white]Έτος[/COLOR][/B]', '', 190, icon_greekmovies, FANART, '')
    addDir('[B][COLOR white]Πρόσφατες καταχωρήσεις[/COLOR][/B]', GREEKMOVIES + 'animation', 193, icon_greekmovies, FANART, '')

#########################################################################################################################

def Greekmovies_year_kids():
    addDir('[COLOR white]2020-σήμερα[/COLOR]', GREEKMOVIES + 'movies.php?g=8&y=&l=&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2010-19[/COLOR]', GREEKMOVIES + 'movies.php?y=8&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]2000-09[/COLOR]', GREEKMOVIES + 'movies.php?y=7&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1990-99[/COLOR]', GREEKMOVIES + 'movies.php?y=6&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1980-89[/COLOR]', GREEKMOVIES + 'movies.php?y=5&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1970-79[/COLOR]', GREEKMOVIES + 'movies.php?y=4&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1960-69[/COLOR]', GREEKMOVIES + 'movies.php?y=3&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]1950-59[/COLOR]', GREEKMOVIES + 'movies.php?y=2&l=&g=8&p=', 186, icon_greekmovies, FANART, '')
    addDir('[COLOR white]πριν το 1950[/COLOR]', GREEKMOVIES + 'movies.php?y=1&l=&g=8&p=', 186, icon_greekmovies, FANART, '')

#########################################################################################################################


def greekmovies(url): #186
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<div class='col-xs-6 col-sm-4 col-md-3'><a class='thumbnail' href='(.+?)'><div class='image-frame'><img src='(.+?)'></div><div class='caption-frame'><h4 class='text-center'>(.+?)</h4>''', re.DOTALL).findall(p)
    for url, icon, name in m:
        url = GREEKMOVIES + url
        icon = GREEKMOVIES + icon
        name = clear_Title(name)
        fanart = icon
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 185, icon, fanart, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 186, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #185
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<a class='btn btn-primary' role='button' href='(.+?)' target='_blank'>(.+?)</a>''').findall(p)
    for url, link in m:
            url = GREEKMOVIES + url
            name = clear_Title(name)
            addDir(link, url, 187, iconimage, '', '')


def get_links2(name, url, iconimage, description): #187
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<div class='col-sm-6'><h3>(.+?)</h3><h4>(.+?)</h4>.+?<a class='btn btn-primary' role='button' href='(.+?)'>(.+?)</a>''').findall(p)
    for name, year, url, link in m:
            year = year.replace('Έτος:', '')
            link = ' | ' + link
            name = name + year
            name = clear_Title(name)
            addDir(name, url, 100, iconimage, '', '')


def greekmovies_series(url): #193
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<p class=.+?><a href="(.+?)">(.+?)</a>(.+?)<p class=.+?>''', re.DOTALL).findall(p)
    for url, name, epi in m:
        url = GREEKMOVIES + url
        addDir(('[B][COLOR=white]%s[/COLOR][/B]' % name + '[COLOR=lime]%s[/COLOR]' % epi), url, 194, '', '', '')
    views.selectView('movies', 'movie-view')


def get_links_s(name, url, iconimage, description): #194
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<a class='btn btn-primary' role='button' href='(.+?)' target='_blank'>(.+?)</a>''').findall(p)
    for url, link in m:
            url = GREEKMOVIES + url
            link = ' | ' + link
            name = clear_Title(name)
            addDir((name+link), url, 195, iconimage, '', '')


def get_links_s2(name, url, iconimage, description): #195
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<a class='btn btn-primary' role='button' href='(.+?)'>(.+?)</a>''').findall(p)
    for url, link in m:
            link = ' | ' + link
            name = clear_Title(name)
            addDir((name+link), url, 100, iconimage, '', '')


def greekmovies_spors(url): #198
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<div class='col-xs-6 col-sm-4 col-md-3'><a class='thumbnail' href='(.+?)'><div class='image-frame'><img src='(.+?)'></div><div class='caption-frame'><h4 class='text-center'>(.+?)</h4>''', re.DOTALL).findall(p)
    for url, icon, name in m:
        url = GREEKMOVIES + url
        icon = GREEKMOVIES + icon
        name = clear_Title(name)
        fanart = icon
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 199, icon, fanart, '')


def get_links_sports(name, url, iconimage, description): #199
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<span class='pull-right'>(.+?)</span></div>.+?<a class='btn btn-default' role='button' href='(.+?)' target='_blank'>(.+?)</a></div>''').findall(p)
    for title, url, name in m:
            url = GREEKMOVIES + url
            title = '[B][COLOR=white]%s[/COLOR][/B]' % title + ' | '
            name = '[B][COLOR=lime]%s[/COLOR][/B]' % name
            addDir((title+name), url, 200, iconimage, '', '')


def get_links_sports2(name, url, iconimage, description): #200
    hdrs = {'Referer': GREEKMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('''<div class='col-sm-6'><h3>(.+?)</h3><h4>(.+?)</h4>.+?<a class='btn btn-primary' role='button' href='(.+?)'>(.+?)</a>''').findall(p)
    for name, year, url, link in m:
            year = year.replace('Έτος:', '')
            link = ' | ' + link
            name = name + year
            name = clear_Title(name)
            addDir(name, url, 100, iconimage, '', '')


def search(url): #182
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = GREEKMOVIES + '?s=' + search
        greekmovies(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
