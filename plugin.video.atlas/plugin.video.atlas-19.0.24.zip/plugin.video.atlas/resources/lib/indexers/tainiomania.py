# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
TAINIOMANIA = control.setting('tainio-mania') or 'https://tainio-mania.online/'



def menu_genre(): #87
    addDir('[COLOR white]Ελλ-ταινίες[/COLOR]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Κωμωδίες[/COLOR]', TAINIOMANIA + 'load/komodia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Δράμα[/COLOR]', TAINIOMANIA + 'load/drama/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Αισθηματικές[/COLOR]', TAINIOMANIA + 'load/aisthhmatik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Οικογενειακές[/COLOR]', 'load/oikogeneiak/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Χριστουγιεννιάτικες[/COLOR]', TAINIOMANIA + 'collections/2-hristoygenniatikes-tainies-online', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Μεταγλωτισμένα Παιδικά[/COLOR]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Κινούμενα Σχέδια[/COLOR]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Animation[/COLOR]', TAINIOMANIA + 'xfsearch/genre/Animation/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Δράση[/COLOR]', TAINIOMANIA + 'load/dr_sh/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Έγκλημα[/COLOR]', TAINIOMANIA + 'load/egkl_mato/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Περιπέτεια[/COLOR]', TAINIOMANIA + 'load/perip_teia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Πολέμου[/COLOR]', TAINIOMANIA + 'load/polemik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Ιστορικές[/COLOR]', TAINIOMANIA + 'load/istorik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Τρόμου[/COLOR]', TAINIOMANIA + 'load/tr_moy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Μυστήριο[/COLOR]', TAINIOMANIA + 'load/mysthr_oy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Θρίλερ[/COLOR]', TAINIOMANIA + 'load/thr_ler/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Φαντασίας[/COLOR]', TAINIOMANIA + 'load/fantas_a/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Ντοκιμαντέρ[/COLOR]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Βιογραφίες[/COLOR]', TAINIOMANIA + 'load/biograf_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Μιούζικαλ[/COLOR]', TAINIOMANIA + 'load/mio_zikal/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Αθλητικά[/COLOR]', TAINIOMANIA + 'load/athlhtik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Θέατρο[/COLOR]', TAINIOMANIA + 'load/th_atro/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Μουσική[/COLOR]', TAINIOMANIA + 'load/moysik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Σειρές[/COLOR]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Ολοκληρωμένες Σειρές[/COLOR]', TAINIOMANIA + 'load/oloklhrwmenes_seires/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]Γουέστερν[/COLOR]', TAINIOMANIA + 'load/goy_stern_western/', 89, ART + 'tainiomania.png', FANART, '')


def menu_year(): #86
    addDir('[COLOR white]2022[/COLOR]', TAINIOMANIA + 'load/tainies-2022/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]2021[/COLOR]', TAINIOMANIA + 'load/tainies-tou-2021/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]2020[/COLOR]', TAINIOMANIA + 'load/-2020/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]2019[/COLOR]', TAINIOMANIA + 'load/tain_e_toy_2019/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]2018[/COLOR]', TAINIOMANIA + 'load/tainies-online-2018/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]2017[/COLOR]', TAINIOMANIA + 'load/tainies-2017-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[COLOR white]2016[/COLOR]', TAINIOMANIA + 'load/tainies-2016-online/', 89, ART + 'tainiomania.png', FANART, '')


def tainiomania(url): #89
    hdrs = {'Referer': TAINIOMANIA,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    try:
        m = re.compile('<h4><a href="(.+?)" class="entryLink">(.+?)</a></h4>.+?<img src="(.+?)"', re.DOTALL).findall(p)
    except IndexError:
        m = re.compile('<h4><a href="(.+?)" class="entryLink">(.+?)</a></h4>.+?<img src="(.+?)"', re.DOTALL).findall(p)
    for url, name, icon in m:
        name = clear_Title(name)
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 88, (TAINIOMANIA + icon) , FANART, '')
    try:
        m = re.compile('</span> <a href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 89, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links(name, url, iconimage, description): #88
    hdrs = {'Referer': TAINIOMANIA,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('file:"(.+?)"').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    else:
        m = re.compile('<iframe width="720" height="480" src="(.+?)"').findall(p)
        for url in m:
            addDir(name, url, 100, iconimage, FANART, str(description))


def search(url): #85
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://tainio-mania.online/?story=' + search + '&titleonly=3&do=search&subaction=search'
        tainiomania(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
