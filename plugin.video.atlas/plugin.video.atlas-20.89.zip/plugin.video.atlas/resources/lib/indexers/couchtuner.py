# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
COUCHTUNER = 'https://www.couchtuner.show/'


def couchtuner(url): #164
    hdrs = {'Referer': COUCHTUNER,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="movie-poster">.+?<img src="(.+?)" alt="">.+?<h5 class="title" title="(.+?)">.+?<a href="(.+?)" class="btn">', re.DOTALL).findall(p)
    for icon, name, url in m:
        fanart = icon
        name = clear_Title(name)
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 165, icon , fanart, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 164, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
#    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #165
    hdrs = {'Referer': COUCHTUNER,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<iframe width=.+? height=.+? src="(.+?)"').findall(p)
    t = re.compile('<p>(.+?)</p>\s+.+?<p><em>').findall(p)
    for url in m:
        for name in t:
            name = name.replace('Watch Series ','').replace(' online on Couchtuner streaming free.','')
            if 'sblona' in url:
                link = ' | sblona'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            elif 'streamtape' in url:
                link = ' | streamtape'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            elif 'doodstream' in url:
                link = ' | doodstream'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            elif 'likessb' in url:
                link = ' | likessb'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            else:
                link = ' | link'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))


def couchtuner_2(url): #161
    hdrs = {'Referer': COUCHTUNER,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="(.+?)" title="(.+?)" >', re.DOTALL).findall(p)
    for url, name in m:
        name = name.replace('View all posts in ',' ')
        name = clear_Title(name)
        icon = ART + 'couchtuner.png'
        addDir(name, url, 162, icon , '', '')

    views.selectView('movies', 'movie-view')


def get_links_2(name, url, iconimage, description): #162
    hdrs = {'Referer': COUCHTUNER,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<iframe width=.+? height=.+? src="(.+?)"').findall(p)
    t = re.compile('<p>(.+?)</p>\s+.+?<p><em>').findall(p)
    for url in m:
        for name in t:
            name = name.replace('Watch Series ','').replace(' online on Couchtuner streaming free.','')
            if 'sblona' in url:
                link = ' | sblona'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            elif 'streamtape' in url:
                link = ' | streamtape'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            elif 'doodstream' in url:
                link = ' | doodstream'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))
            else:
                link = ' | link'
                name = name + link
                addDir(name, url, 100, iconimage, FANART, str(description))

def search(url): #163
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://www.couchtuner.show/?s=' + search
        couchtuner(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
