# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
subs4free = 'https://www.subs4free.club'



def coverapi_menu(): #261
    addDir('[B][COLOR coral]2024[/COLOR][/B]', subs4free, 89, ART + 's4f.png', FANART, '')


def coverapi(url): #262
    hdrs = {'Referer': subs4free,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<img src=.+? class=".+? data-src="(.+?)" alt="(.+?)".+?<a class="headinglink" href="(.+?)">.+? </span><span>(.+?)</span></p> </div>', re.DOTALL).findall(p)
    for icon, name, url, imdb in m:
        name = clear_Title(name)
        url = subs4free + url
        fanart = icon
        imdb = ' | ' + '[B][COLOR blue]%s [/COLOR][/B]' % imdb
        addDir(('[B][COLOR=white]%s[/COLOR][/B]' % name + imdb), url, 263, icon , fanart, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 262, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #263
    hdrs = {'Referer': subs4free,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<iframe width="100%" height="100%" data-src="(.+?)" ').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    try:
        m = re.compile('<a class="movie-inner-last-link" href="(.+?)" ').findall(p)
        for url in m:
            url = url.replace('https://www.imdb.com/title/', 'https://coverapi.store/embed/')
            addDir(name, url, 100, iconimage, FANART, str(description))
    except BaseException:
        pass


def coverapi_search(url): #265
    hdrs = {'Referer': subs4free,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<li><a href="(.+?)"><img src=.+? class="lozad" data-src="(.+?)" alt="(.+?)"').findall(p)
    for url, icon, name in m:
        url = subs4free + url
        name = clear_Title(name)
        fanart = icon
   #     imdb = ' | ' + '[B][COLOR blue]%s [/COLOR][/B]' % imdb
        addDir('[B][COLOR=white]%s[/COLOR][/B]' % name, url, 263, icon , fanart, '')
    try:
        m = re.compile('<link rel="next" href="(.+?)">').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 262, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def search(url): #264
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας - Τήλ.Σειράς')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = subs4free + '/search_report.php?search=' + search
        coverapi_search(url)


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
