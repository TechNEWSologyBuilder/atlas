# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_GAMATOMOVIES = ART + 'gamatomovies.png'
GAMATOMOVIES = control.setting('gamatomovies') or 'https://gamatomovies1.gr/'


def GamatoMovies_menu(): #131
    addDir('[B][COLOR deeppink]2024[/COLOR][/B]', GAMATOMOVIES + 'years/2024/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR deeppink]2023[/COLOR][/B]', GAMATOMOVIES + 'years/2023/', 122, ART + 'gamatomovies.png', FANART, '')
#    addDir('[B][COLOR deeppink]2022[/COLOR][/B]', GAMATOMOVIES + 'years/2022/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR deeppink]Νέες (Δημοφιλείς)[/COLOR][/B]', GAMATOMOVIES + 'tainies/slider/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR deeppink]Τελευταίες Προσθήκες[/COLOR][/B]', GAMATOMOVIES + 'tainies/online/', 122, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR deeppink]Έτος[/COLOR][/B]', GAMATOMOVIES + 'tainies/online/', 124, ART + 'gamatomovies.png', FANART, '')
    addDir('[B][COLOR deeppink]Κατηγορίες[/COLOR][/B]', GAMATOMOVIES + 'movies/', 125, ART + 'gamatomovies.png', FANART, '')

def menu_year(): #124
    addDir('[B][COLOR deeppink]2024[/COLOR][/B]', GAMATOMOVIES + 'years/2024', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2023[/COLOR][/B]', GAMATOMOVIES + 'years/2023', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2022[/COLOR][/B]', GAMATOMOVIES + 'years/2022', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2021[/COLOR][/B]', GAMATOMOVIES + 'years/2021', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2020[/COLOR][/B]', GAMATOMOVIES + 'years/2020', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2019[/COLOR][/B]', GAMATOMOVIES + 'years/2019', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2018[/COLOR][/B]', GAMATOMOVIES + 'years/2018', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2017[/COLOR][/B]', GAMATOMOVIES + 'years/2017', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2016[/COLOR][/B]', GAMATOMOVIES + 'years/2016', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2015[/COLOR][/B]', GAMATOMOVIES + 'years/2015', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2014[/COLOR][/B]', GAMATOMOVIES + 'years/2014', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2013[/COLOR][/B]', GAMATOMOVIES + 'years/2013', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2012[/COLOR][/B]', GAMATOMOVIES + 'years/2012', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2011[/COLOR][/B]', GAMATOMOVIES + 'years/2011', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2010[/COLOR][/B]', GAMATOMOVIES + 'years/2010', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2009[/COLOR][/B]', GAMATOMOVIES + 'years/2009', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2008[/COLOR][/B]', GAMATOMOVIES + 'years/2008', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2007[/COLOR][/B]', GAMATOMOVIES + 'years/2007', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2006[/COLOR][/B]', GAMATOMOVIES + 'years/2006', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2005[/COLOR][/B]', GAMATOMOVIES + 'years/2005', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2004[/COLOR][/B]', GAMATOMOVIES + 'years/2004', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2003[/COLOR][/B]', GAMATOMOVIES + 'years/2003', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2002[/COLOR][/B]', GAMATOMOVIES + 'years/2002', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2001[/COLOR][/B]', GAMATOMOVIES + 'years/2001', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]2000[/COLOR][/B]', GAMATOMOVIES + 'years/2000', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1999[/COLOR][/B]', GAMATOMOVIES + 'years/1999', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1998[/COLOR][/B]', GAMATOMOVIES + 'years/1998', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1997[/COLOR][/B]', GAMATOMOVIES + 'years/1997', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1996[/COLOR][/B]', GAMATOMOVIES + 'years/1996', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1995[/COLOR][/B]', GAMATOMOVIES + 'years/1995', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1994[/COLOR][/B]', GAMATOMOVIES + 'years/1994', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1993[/COLOR][/B]', GAMATOMOVIES + 'years/1993', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1992[/COLOR][/B]', GAMATOMOVIES + 'years/1992', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1991[/COLOR][/B]', GAMATOMOVIES + 'years/1991', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1990[/COLOR][/B]', GAMATOMOVIES + 'years/1990', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1989[/COLOR][/B]', GAMATOMOVIES + 'years/1989', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1988[/COLOR][/B]', GAMATOMOVIES + 'years/1988', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1987[/COLOR][/B]', GAMATOMOVIES + 'years/1987', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1986[/COLOR][/B]', GAMATOMOVIES + 'years/1986', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1985[/COLOR][/B]', GAMATOMOVIES + 'years/1985', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1984[/COLOR][/B]', GAMATOMOVIES + 'years/1984', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1983[/COLOR][/B]', GAMATOMOVIES + 'years/1983', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1982[/COLOR][/B]', GAMATOMOVIES + 'years/1982', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1981[/COLOR][/B]', GAMATOMOVIES + 'years/1981', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1980[/COLOR][/B]', GAMATOMOVIES + 'years/1980', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1979[/COLOR][/B]', GAMATOMOVIES + 'years/1979', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1978[/COLOR][/B]', GAMATOMOVIES + 'years/1978', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1977[/COLOR][/B]', GAMATOMOVIES + 'years/1977', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1976[/COLOR][/B]', GAMATOMOVIES + 'years/1976', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1975[/COLOR][/B]', GAMATOMOVIES + 'years/1975', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1974[/COLOR][/B]', GAMATOMOVIES + 'years/1974', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1973[/COLOR][/B]', GAMATOMOVIES + 'years/1973', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1972[/COLOR][/B]', GAMATOMOVIES + 'years/1972', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1971[/COLOR][/B]', GAMATOMOVIES + 'years/1971', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1970[/COLOR][/B]', GAMATOMOVIES + 'years/1970', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1969[/COLOR][/B]', GAMATOMOVIES + 'years/1969', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1968[/COLOR][/B]', GAMATOMOVIES + 'years/1968', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1967[/COLOR][/B]', GAMATOMOVIES + 'years/1967', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1966[/COLOR][/B]', GAMATOMOVIES + 'years/1966', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1965[/COLOR][/B]', GAMATOMOVIES + 'years/1965', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1964[/COLOR][/B]', GAMATOMOVIES + 'years/1964', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1963[/COLOR][/B]', GAMATOMOVIES + 'years/1963', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]1962[/COLOR][/B]', GAMATOMOVIES + 'years/1962', 122, icon_GAMATOMOVIES, FANART, '')


def menu_genre(): #125
    addDir('[B][COLOR deeppink]Αστυνομική[/COLOR][/B]', GAMATOMOVIES + 'tainies/crime/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Βιογραφία[/COLOR][/B]', GAMATOMOVIES + 'tainies/biography/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Δράμα[/COLOR][/B]', GAMATOMOVIES + 'tainies/drama/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Επ. Φαντασίας[/COLOR][/B]', GAMATOMOVIES + 'tainies/sci-fi/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Θρίλερ[/COLOR][/B]', GAMATOMOVIES + 'tainies/thriller/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Ιστορική[/COLOR][/B]', GAMATOMOVIES + 'tainies/history/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Κινούμενα Σχέδια[/COLOR][/B]', GAMATOMOVIES + 'tainies/animation/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Κωμωδία[/COLOR][/B]', GAMATOMOVIES + 'tainies/comedy/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Μουσική[/COLOR][/B]', GAMATOMOVIES + 'tainies/music/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Μυστηρίου[/COLOR][/B]', GAMATOMOVIES + 'tainies/mystery/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Ντοκιμαντέρ[/COLOR][/B]', GAMATOMOVIES + 'tainies/documentary/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Οικογενειακή[/COLOR][/B]', GAMATOMOVIES + 'tainies/family/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Περιπέτεια[/COLOR][/B]', GAMATOMOVIES + 'tainies/adventure/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Πολεμική[/COLOR][/B]', GAMATOMOVIES + 'tainies/war/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Ρομαντική[/COLOR][/B]', GAMATOMOVIES + 'tainies/romance/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Τρόμου[/COLOR][/B]', GAMATOMOVIES + 'tainies/horror/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Φαντασίας[/COLOR][/B]', GAMATOMOVIES + 'tainies/fantasy/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Western[/COLOR][/B]', GAMATOMOVIES + 'tainies/western/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Bollywood[/COLOR][/B]', GAMATOMOVIES + 'tainies/bollywood/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Ελληνική Ταινία[/COLOR][/B]', GAMATOMOVIES + 'tainies/elliniki-tainia/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Πασχαλινή[/COLOR][/B]', GAMATOMOVIES + 'tainies/easter/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Χριστουγεννιάτικη[/COLOR][/B]', GAMATOMOVIES + 'tainies/χριστουγεννιάτικη/', 122, icon_GAMATOMOVIES, FANART, '')
    addDir('[B][COLOR deeppink]Αγίου Βαλεντίνου[/COLOR][/B]', GAMATOMOVIES + 'tainies/valentinesday/', 122, icon_GAMATOMOVIES, FANART, '')


def gamatomovies(url): #122
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<div class="gp-image-align-left">\s*<a href="(.+?)" title="(.+?)">\s*<img src="(.+?)".+?\s*<p>(.+?)"', re.DOTALL).findall(p)
    for url, name, icon, description in m:
        description = description.replace('</div>', '').replace('<div class=', '').replace('...</p>', '')
        description = description.replace('Σκηνοθεσία:', '[COLOR=lime]Σκηνοθεσία[/COLOR][COLOR=white]: [/COLOR]')
        description = description.replace('Σενάριο:', '[COLOR=lime]Σενάριο[/COLOR][COLOR=white]: [/COLOR]')
        description = description.replace('Ηθοποιοί:', '[COLOR=lime]Ηθοποιοί[/COLOR][COLOR=white]: [/COLOR]')
        description = description.replace('Κυκλοφορία:', '[COLOR=lime]Κυκλοφορία[/COLOR][COLOR=white]: [/COLOR]')
        description = description.replace('Χώρα:', '[COLOR=lime]Χώρα[/COLOR]COLOR=white]: [/COLOR]')
        name = clear_Title(name)
        fanart = icon
        addDir(name, url, 123, icon , fanart, description)
    try:
        m = re.compile('<link rel="next" href="(.+?)" />').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', m, 122, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass
    views.selectView('movies', 'movie-view')


def get_links(name, url, iconimage, description): #123
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m2 = re.compile('<a href="(.+?)">').findall(p)
    for url in m2:
        if 'youtube' in url:
            Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
            addDir(Trailer, url, 100, ART + 'youtube.png', FANART, str(description))
    try:
        m = re.compile('<a href="(.+?)" target="_blank" rel="nofollow noopener noreferrer">(.+?)</a></td>').findall(p)
        t = re.compile('<div class="gp-entry-title">(.+?)</div>').findall(p)
    #    link_list = ['HDVID', 'STREAMTAPE']
    #    link_list_Out = ['NETU', 'ΕΛΛΗΝΙΚΟΙ ΕΞΩΤΕΡΙΚΟΙ']
        for url, link in m:
            for name in t:
        #        if any(x in link for x in link_list):
        #        if not any(x in link for x in link_list_Out):
                link = ' | ' + link
                name = clear_Title(name)
                url = url.replace('http', 'https').replace('httpss', 'https')
                addDir((name+link), url, 100, iconimage, FANART, str(description))
    except BaseException:
        pass
    else:
        m = re.compile('<div class=.+? ><a class=.+? href="(.+?)" .+?>(.+?)</a><', re.DOTALL).findall(p)
    #    img = re.compile('<meta property="og:image" content="(.+?)" />\s<meta property="og:image:width" content=".+?" />', re.DOTALL).findall(p)
        for url, season in m:
    #        for icon in img:
        #    season = '[COLOR=white]Λίστα όλων των επεισοδίων [COLOR lime]-->[/COLOR]'
            addDir((name+' '+season), url, 129, iconimage , FANART, '')


def epi_tv(name, url, iconimage, description): #129
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
                   
    m = re.compile('<h4 class="media-heading"><a href="(.+?)">(.+?)</a></h4>', re.DOTALL).findall(p)
  #  n = re.compile('<h1><a href=.+?>(.+?)</a></h1>', re.DOTALL).findall(p)
    for url, epi in m:
    #    name = url
    #    if not 'Επεισόδιο' in epi:
    #        epi = 'Επεισόδιο ' + epi
    #        addDir(epi, url, 130, icon, FANART, '')
    #    else:
    #    name = '[B][COLOR=white]Λίστα όλων των επεισοδίων [COLOR lime]-->[/COLOR][/B]'
        name = name.replace('Σεζόν ', 'S0')
        epi = epi.replace('Επεισόδιο ', 'E0')
        addDir((name+' '+epi), url, 130, iconimage, FANART, '')


def get_links_tv(name, url, iconimage, description): #130
    hdrs = {'Referer': GAMATOMOVIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
 #   m = re.compile('<td class="name hover" data-bind="click: playVideo.bind($data, '').findall(p)
    m = re.compile('''\s+<td class=.+? data-bind=.+? '(.+?)'.+? ><.+? rel=.+?>(.+?)<''').findall(p)

#    m = re.compile('{"id":.+?,"url":"(.+?)",.+?"season":(.+?),"episode":(.+?)').findall(p)
 #   t = re.compile('<title>(.+?)</title>').findall(p)
    for url, link in m:
   #     for name in t:
    #        name = name.replace(' Greek subs ταινίες online | gamato-movies.com', '').replace(',', '').replace('Season ', 'S0').replace('Επεισόδιο ', 'E0')
        url = url.replace('http', 'https').replace('httpss', 'https').replace('\/', '/')
    #    name = url
        link = ' | ' + link
        addDir((name+link), url, 100, '', '', '')


def search(url): #121
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = GAMATOMOVIES + '?s=' + search
        gamatomovies(url)

def search_tv(url): #131
    keyb = xbmc.Keyboard('', 'Αναζήτηση Τήλ.Σειράς...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = GAMATOMOVIES + '?s=' + search
        gamatomovies(url)

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
