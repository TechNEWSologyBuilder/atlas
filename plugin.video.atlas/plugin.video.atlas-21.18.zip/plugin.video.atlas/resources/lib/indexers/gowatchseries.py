# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
icon_GOWATCHSERIES = ART + 'thewatchseries.png'
GOWATCHSERIES = 'https://www5.gowatchseries.tv/'


def gowatchseries_menu(): #170
    addDir('[B][COLOR orangered]2023[/COLOR][/B]', GOWATCHSERIES + 'list?year=2023&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]2022[/COLOR][/B]', GOWATCHSERIES + 'list?year=2022&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Έτος[/COLOR][/B]', '', 216, ART + 'thewatchseries.png', FANART, '')
    addDir('[B][COLOR orangered]Αλφαβητικά[/COLOR][/B]', '', 210, ART + 'thewatchseries.png', FANART, '')
    addDir('[B][B][COLOR orangered]Κατηγορία[/COLOR][/B]', '', 217, ART + 'thewatchseries.png', FANART, '')
#    addDir('[B][COLOR orangered]Movies[/COLOR][/B]', GOWATCHSERIES + 'movies', 221, ART + 'thewatchseries.png', FANART, '')
    addDir('[B][COLOR orangered]New Release[/COLOR][/B]', GOWATCHSERIES + 'new-release', 221, ART + 'thewatchseries.png', FANART, '')
    addDir('[B][COLOR orangered]Cinema Movies[/COLOR][/B]', GOWATCHSERIES + 'cinema-movies', 214, ART + 'thewatchseries.png', FANART, '')


def gowatchseries_menu_tv(): #169
    addDir('[B][COLOR orangered]2023[/COLOR][/B]', GOWATCHSERIES + 'list?year=2023&type=2', 224, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]2022[/COLOR][/B]', GOWATCHSERIES + 'list?year=2022&type=2', 224, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Έτος[/COLOR][/B]', '', 219, ART + 'thewatchseries.png', FANART, '')


def gowatchseries_menu_a(): #210
    addDir('[B][COLOR orangered]A[/COLOR][/B]', GOWATCHSERIES + 'list?key=A&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]B[/COLOR][/B]', GOWATCHSERIES + 'list?key=B&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]C[/COLOR][/B]', GOWATCHSERIES + 'list?key=C&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]D[/COLOR][/B]', GOWATCHSERIES + 'list?key=D&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]E[/COLOR][/B]', GOWATCHSERIES + 'list?key=E&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]F[/COLOR][/B]', GOWATCHSERIES + 'list?key=F&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]G[/COLOR][/B]', GOWATCHSERIES + 'list?key=G&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]H[/COLOR][/B]', GOWATCHSERIES + 'list?key=H&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]I[/COLOR][/B]', GOWATCHSERIES + 'list?key=I&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]J[/COLOR][/B]', GOWATCHSERIES + 'list?key=J&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]K[/COLOR][/B]', GOWATCHSERIES + 'list?key=K&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]L[/COLOR][/B]', GOWATCHSERIES + 'list?key=L&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]M[/COLOR][/B]', GOWATCHSERIES + 'list?key=M&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]N[/COLOR][/B]', GOWATCHSERIES + 'list?key=N&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]O[/COLOR][/B]', GOWATCHSERIES + 'list?key=O&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]P[/COLOR][/B]', GOWATCHSERIES + 'list?key=P&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Q[/COLOR][/B]', GOWATCHSERIES + 'list?key=Q&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]R[/COLOR][/B]', GOWATCHSERIES + 'list?key=R&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]S[/COLOR][/B]', GOWATCHSERIES + 'list?key=S&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]T[/COLOR][/B]', GOWATCHSERIES + 'list?key=T&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]U[/COLOR][/B]', GOWATCHSERIES + 'list?key=U&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]V[/COLOR][/B]', GOWATCHSERIES + 'list?key=V&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]W[/COLOR][/B]', GOWATCHSERIES + 'list?key=W&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]X[/COLOR][/B]', GOWATCHSERIES + 'list?key=X&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Y[/COLOR][/B]', GOWATCHSERIES + 'list?key=Y&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Z[/COLOR][/B]', GOWATCHSERIES + 'list?key=Z&type=1', 214, icon_GOWATCHSERIES, FANART, '')



def menu_year(): #216
    years = []
    for i in range(1924, 2023):
        i += 1
        title = '[B][COLOR orangered]{}[/COLOR][/B]'.format(str(i))
        link = GOWATCHSERIES + 'list?year={}&type=1'.format(str(i))
        years.append((title, link))
    for title, link in sorted(years, reverse=True):
        addDir(title, link, 214, icon_GOWATCHSERIES, FANART, '')


def menu_year_tv(): #219
    years = []
    for i in range(1924, 2023):
        i += 1
        title = '[B][COLOR orangered]{}[/COLOR][/B]'.format(str(i))
        link = GOWATCHSERIES + 'list?year={}&type=2'.format(str(i))
        years.append((title, link))
    for title, link in sorted(years, reverse=True):
        addDir(title, link, 214, icon_GOWATCHSERIES, FANART, '')


def menu_genre(): #217
    addDir('[B][COLOR orangered]Δράσης[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Action&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Περιπέτεια[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Adventure&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Κινούμενα Σχέδια[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Animation&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Βιογραφία[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Biography&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Κωμωδία[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Comedy&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Costume[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Costume&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Εγκλήματος[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Crime&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Ντοκιμαντέρ[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Documentary&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Δράμα[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Drama&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Οικογενειακή[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Family&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Φαντασίας[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Fantasy&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Film-Noir[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Film-Noir&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Ιστορική[/COLOR][/B]', GOWATCHSERIES + 'list?genre=History&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Τρόμου[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Horror&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Kungfu[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Kungfu&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Μουσική[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Music&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Musical[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Musical&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Μυστηρίου[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Mystery&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Μυθολογία[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Mythological&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Ψυχολογία[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Psychological&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Reality TV[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Reality-TV&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Ρομαντική[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Romance&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Επ. Φαντασίας[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Sci-Fi&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Short[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Short&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Sitcom[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Sitcom&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Αθλητική[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Sport&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Θρίλερ[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Thriller&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]TV Show[/COLOR][/B]', GOWATCHSERIES + 'list?genre=TV+Show&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Πολεμική[/COLOR][/B]', GOWATCHSERIES + 'list?genre=War&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Western[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Western&type=1', 214, icon_GOWATCHSERIES, FANART, '')
    addDir('[B][COLOR orangered]Xmas[/COLOR][/B]', GOWATCHSERIES + 'list?genre=Xmas&type=1', 214, icon_GOWATCHSERIES, FANART, '')


def gowatchseries(url): #214
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="(.+?)" title="(.+?)">.+?</a>\s+<span>(.+?)</span>', re.DOTALL).findall(p)
    for url, name, year in m:
        if 'login' in name:
            continue
        url = 'https://www5.gowatchseries.tv' + url
        year = ' ' + '(' + year + ')'
        name = name + year
        addDir(name, url, 215, '' , '', '')
    try:
        m = re.compile('''<li class='next'><a href='(.+?)' data-page=''').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (GOWATCHSERIES+'list'+m+'&type=1'), 214, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass

def get_links(name, url, iconimage, description): #215
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    u = re.compile('<img src="(.+?)" onerror=.+?>').findall(p)
    m = re.compile('<a href="(.+?)" title=.+? class="">').findall(p)
    for iconimage in u:
        for url in m:
            url = 'https://www5.gowatchseries.tv' + url
            addDir(name, url, 218, iconimage, '', '')


def gowatchseries_type2(url): #224
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="(.+?)" title="(.+?)">.+?</a>\s+<span>(.+?)</span>', re.DOTALL).findall(p)
    for url, name, year in m:
        if 'login' in name:
            continue
        url = 'https://www5.gowatchseries.tv' + url
        year = ' ' + '(' + year + ')'
        name = name + year
        addDir(name, url, 223, '' , '', '')
    try:
        m = re.compile('''<li class='next'><a href='(.+?)' data-page=''').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (GOWATCHSERIES+'list'+m+'&type=2'), 224, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass

def get_links_type2(name, url, iconimage, description): #223
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="(.+?)" title="(.+?)" class="">').findall(p)
    for url, title in m:
        url = 'https://www5.gowatchseries.tv' + url
        addDir(title, url, 218, '', '', '')


def get_links_s(name, url, iconimage, description): #218
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<.+? rel=.+? data-video="(.+?)">.+?</i>(.+?)<span>').findall(p)
    for url, link in m:
        if not 'movembed' in url:
            link = ' | ' + link
            addDir((name+link), url, 100, iconimage, '', '')


def search(url): #213
    keyb = xbmc.Keyboard('', 'Αναζήτηση Ταινίας...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText().replace(' ', '+')
        url = 'https://www5.gowatchseries.tv/search.html?keyword=' + search
        gowatchseries_s(url)


def gowatchseries_s(url): #220
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<li.+?\s+<a href="/(.+?)">\s+<img src="(.+?)" alt="(.+?)" />', re.DOTALL).findall(p)
#    m = re.compile('<li>\s+<a href="(.+?)">\s+<img src="(.+?)" alt="(.+?)" />', re.DOTALL).findall(p)
    for url, icon, name in m:
        url = 'https://www5.gowatchseries.tv' + url
        addDir(name, url, 222, icon , '', '')
    try:
        m = re.compile('''<li class='next'><a href='(.+?)' data-page=''').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (GOWATCHSERIES+'search.html'+m), 220, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def get_links_ss(name, url, iconimage, description): #222
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<a href="(.+?)" title="(.+?)"').findall(p)
    for url, title in m:
        url = 'https://www5.gowatchseries.tv' + url
        addDir((name+' '+title), url, 218, '', '', '')


def gowatchseries_m(url): #221
    hdrs = {'Referer': GOWATCHSERIES,
            'User-Agent': client.agent()}
    p = requests.get(url, headers=hdrs).text
    m = re.compile('<li.+?\s+<a href="/(.+?)">\s+<img src="(.+?)" alt="(.+?)" />', re.DOTALL).findall(p)
#    m = re.compile('<li>\s+<a href="(.+?)">\s+<img src="(.+?)" alt="(.+?)" />', re.DOTALL).findall(p)
    for url, icon, name in m:
        url = 'https://www5.gowatchseries.tv' + url
        addDir(name, url, 218, icon , '', '')
    try:
        m = re.compile('''<li class='next'><a href='(.+?)' data-page=''').findall(p)[0]
        addDir('[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]', (GOWATCHSERIES+'new-release'+m), 221, 'http://i.imgur.com/rKSs0yq.png', FANART, '')
    except BaseException:
        pass


def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt
